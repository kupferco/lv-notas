--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18
-- Dumped by pg_dump version 14.15 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: event_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.event_type AS ENUM (
    'new',
    'update',
    'cancel'
);


ALTER TYPE public.event_type OWNER TO postgres;

--
-- Name: invitation_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.invitation_status AS ENUM (
    'pending',
    'accepted',
    'declined',
    'expired'
);


ALTER TYPE public.invitation_status OWNER TO postgres;

--
-- Name: session_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.session_status AS ENUM (
    'agendada',
    'compareceu',
    'cancelada'
);


ALTER TYPE public.session_status OWNER TO postgres;

--
-- Name: session_status_auth; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.session_status_auth AS ENUM (
    'active',
    'expired',
    'terminated'
);


ALTER TYPE public.session_status_auth OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'owner',
    'manager',
    'viewer',
    'super_admin'
);


ALTER TYPE public.user_role OWNER TO postgres;

--
-- Name: can_void_billing_period(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_void_billing_period(period_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM monthly_billing_periods 
        WHERE id = period_id 
        AND status != 'void' 
        AND can_be_voided = true
    );
END;
$$;


ALTER FUNCTION public.can_void_billing_period(period_id integer) OWNER TO postgres;

--
-- Name: change_patient_billing_cycle(integer, character varying, numeric, date, text, character varying, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text DEFAULT NULL::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_history_id INTEGER;
    patient_therapist_id INTEGER;
BEGIN
    -- Get therapist_id for this patient
    SELECT therapist_id INTO patient_therapist_id FROM patients WHERE id = p_patient_id;
    
    -- Close current patient billing override (if any)
    UPDATE patient_billing_history
    SET effective_until_date = p_effective_from_date - INTERVAL '1 day'
    WHERE patient_id = p_patient_id
        AND effective_until_date IS NULL;
    
    -- Insert new patient billing history
    INSERT INTO patient_billing_history (
        patient_id,
        therapist_id,
        billing_cycle,
        session_price,
        effective_from_date,
        reason_for_change,
        created_by,
        notes
    ) VALUES (
        p_patient_id,
        patient_therapist_id,
        p_new_billing_cycle,
        p_new_session_price,
        p_effective_from_date,
        p_reason,
        p_created_by,
        p_notes
    ) RETURNING id INTO new_history_id;
    
    -- Update patient table with current values (for quick access)
    UPDATE patients
    SET session_price = p_new_session_price
    WHERE id = p_patient_id;
    
    RETURN new_history_id;
END;
$$;


ALTER FUNCTION public.change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) OWNER TO postgres;

--
-- Name: FUNCTION change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) IS 'Change patient-specific billing with history tracking';


--
-- Name: change_therapist_billing_cycle(integer, character varying, numeric, date, text, character varying, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text DEFAULT NULL::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_history_id INTEGER;
BEGIN
    -- Close current billing cycle (set effective_until_date)
    UPDATE therapist_billing_history
    SET effective_until_date = p_effective_from_date - INTERVAL '1 day'
    WHERE therapist_id = p_therapist_id
        AND effective_until_date IS NULL;
    
    -- Insert new billing cycle history
    INSERT INTO therapist_billing_history (
        therapist_id,
        billing_cycle,
        default_session_price,
        effective_from_date,
        reason_for_change,
        created_by,
        notes
    ) VALUES (
        p_therapist_id,
        p_new_billing_cycle,
        p_new_default_price,
        p_effective_from_date,
        p_reason,
        p_created_by,
        p_notes
    ) RETURNING id INTO new_history_id;
    
    -- Update therapist table with current values (for quick access)
    UPDATE therapists
    SET 
        billing_cycle = p_new_billing_cycle,
        default_session_price = p_new_default_price
    WHERE id = p_therapist_id;
    
    RETURN new_history_id;
END;
$$;


ALTER FUNCTION public.change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) OWNER TO postgres;

--
-- Name: FUNCTION change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) IS 'Change therapist billing cycle with history tracking';


--
-- Name: cleanup_expired_sessions(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_expired_sessions() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    expired_count INTEGER;
BEGIN
    -- Terminate expired sessions
    UPDATE user_sessions 
    SET 
        status = 'expired',
        terminated_at = CURRENT_TIMESTAMP,
        termination_reason = 'timeout'
    WHERE status = 'active' 
    AND (
        expires_at < CURRENT_TIMESTAMP 
        OR last_activity_at < CURRENT_TIMESTAMP - INTERVAL '1 minute' * inactive_timeout_minutes
    );
    
    GET DIAGNOSTICS expired_count = ROW_COUNT;
    
    -- Log cleanup activity
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    )
    SELECT 
        us.id, us.user_id, 'cleanup_expired',
        JSON_BUILD_OBJECT('expired_count', expired_count, 'cleanup_time', CURRENT_TIMESTAMP)
    FROM user_sessions us 
    WHERE us.status = 'expired' 
    AND us.terminated_at >= CURRENT_TIMESTAMP - INTERVAL '1 minute'
    LIMIT 1; -- Just log once per cleanup
    
    RETURN expired_count;
END;
$$;


ALTER FUNCTION public.cleanup_expired_sessions() OWNER TO postgres;

--
-- Name: FUNCTION cleanup_expired_sessions(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.cleanup_expired_sessions() IS 'Background job to clean up expired sessions';


--
-- Name: disable_super_admin(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.disable_super_admin() RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE app_configuration 
    SET value = 'false', updated_at = CURRENT_TIMESTAMP 
    WHERE key = 'auth_super_admin_enabled';
    
    -- Deactivate existing super admin permissions (don't delete for audit)
    UPDATE user_permissions 
    SET is_active = false 
    WHERE role = 'super_admin';
    
    -- Log the change
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    ) VALUES (
        NULL, NULL, 'super_admin_disabled',
        JSON_BUILD_OBJECT(
            'disabled_at', CURRENT_TIMESTAMP,
            'reason', 'production_security'
        )
    );
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.disable_super_admin() OWNER TO postgres;

--
-- Name: FUNCTION disable_super_admin(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.disable_super_admin() IS 'Disable super admin role for production security';


--
-- Name: enable_dev_mode(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.enable_dev_mode() RETURNS TABLE(setting character varying, production_value character varying, development_value character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Set environment to development
    PERFORM set_auth_environment('development');
    
    -- Return comparison of settings
    RETURN QUERY
    SELECT 
        config.key as setting,
        config.value as production_value,
        get_auth_config(config.key) as development_value
    FROM app_configuration config
    WHERE config.key LIKE 'auth_%'
    AND config.key != 'auth_environment'
    ORDER BY config.key;
END;
$$;


ALTER FUNCTION public.enable_dev_mode() OWNER TO postgres;

--
-- Name: FUNCTION enable_dev_mode(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.enable_dev_mode() IS 'Quick switch to development mode with shorter timeouts';


--
-- Name: enable_prod_mode(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.enable_prod_mode() RETURNS TABLE(setting character varying, current_value character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Set environment to production
    PERFORM set_auth_environment('production');
    
    -- Return current settings
    RETURN QUERY
    SELECT 
        config.key as setting,
        get_auth_config(config.key) as current_value
    FROM app_configuration config
    WHERE config.key LIKE 'auth_%'
    AND config.key != 'auth_environment'
    ORDER BY config.key;
END;
$$;


ALTER FUNCTION public.enable_prod_mode() OWNER TO postgres;

--
-- Name: FUNCTION enable_prod_mode(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.enable_prod_mode() IS 'Quick switch to production mode with full timeouts';


--
-- Name: extend_user_session(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.extend_user_session(p_session_token character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    session_record RECORD;
BEGIN
    -- Get session details
    SELECT * INTO session_record
    FROM user_sessions 
    WHERE session_token = p_session_token 
    AND status = 'active'
    AND expires_at > CURRENT_TIMESTAMP;
    
    IF NOT FOUND THEN
        RETURN false;
    END IF;
    
    -- Update session activity and extend expiration
    UPDATE user_sessions 
    SET 
        last_activity_at = CURRENT_TIMESTAMP,
        expires_at = CURRENT_TIMESTAMP + INTERVAL '1 hour' * session_record.max_session_hours
    WHERE id = session_record.id;
    
    -- Log the session extension
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    ) VALUES (
        session_record.id, session_record.user_id, 'session_extended',
        JSON_BUILD_OBJECT('extended_at', CURRENT_TIMESTAMP)
    );
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.extend_user_session(p_session_token character varying) OWNER TO postgres;

--
-- Name: FUNCTION extend_user_session(p_session_token character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.extend_user_session(p_session_token character varying) IS 'Extend session when user chooses to continue';


--
-- Name: extract_patient_name_from_summary(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.extract_patient_name_from_summary(summary text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- Handle "Sessão - Patient Name" format
    IF summary ~* '^sessão\s*-\s*(.+)$' THEN
        RETURN TRIM(REGEXP_REPLACE(summary, '^sessão\s*-\s*', '', 'i'));
    END IF;
    
    -- Handle "Patient Name - Sessão" format
    IF summary ~* '^(.+)\s*-\s*sessão$' THEN
        RETURN TRIM(REGEXP_REPLACE(summary, '\s*-\s*sessão$', '', 'i'));
    END IF;
    
    -- Handle just patient name (if marked as therapy session)
    RETURN TRIM(summary);
END;
$_$;


ALTER FUNCTION public.extract_patient_name_from_summary(summary text) OWNER TO postgres;

--
-- Name: FUNCTION extract_patient_name_from_summary(summary text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.extract_patient_name_from_summary(summary text) IS 'Extract patient name from calendar event summary text';


--
-- Name: get_auth_config(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_auth_config(config_key character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    config_value VARCHAR(255);
    environment VARCHAR(255);
BEGIN
    -- Get current environment
    SELECT value INTO environment 
    FROM app_configuration 
    WHERE key = 'auth_environment';
    
    -- Get base configuration value
    SELECT value INTO config_value 
    FROM app_configuration 
    WHERE key = config_key;
    
    -- Apply environment-specific overrides for development/testing
    IF environment IN ('development', 'testing') THEN
        CASE config_key
            WHEN 'auth_inactive_timeout_minutes' THEN
                config_value := '2'; -- 2 minutes instead of 10 for dev
            WHEN 'auth_warning_timeout_minutes' THEN
                config_value := '0.17'; -- 10 seconds instead of 1 minute for dev  
            WHEN 'auth_max_session_hours' THEN
                config_value := '1'; -- 1 hour instead of 8 for dev
            WHEN 'auth_token_refresh_minutes' THEN
                config_value := '5'; -- 5 minutes instead of 55 for dev
            WHEN 'auth_session_cleanup_interval_minutes' THEN
                config_value := '2'; -- 2 minutes instead of 15 for dev
            ELSE
                -- Keep production value for other settings
                NULL;
        END CASE;
    END IF;
    
    RETURN config_value;
END;
$$;


ALTER FUNCTION public.get_auth_config(config_key character varying) OWNER TO postgres;

--
-- Name: FUNCTION get_auth_config(config_key character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_auth_config(config_key character varying) IS 'Get authentication config with environment-specific overrides';


--
-- Name: get_billing_sessions_count(integer, integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date DEFAULT NULL::date, p_end_date date DEFAULT NULL::date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    session_count INTEGER;
BEGIN
    SELECT COUNT(*)
    INTO session_count
    FROM billable_sessions bs
    WHERE bs.therapist_id = p_therapist_id
        AND bs.patient_id = p_patient_id
        AND bs.counts_for_billing = true
        AND bs.status = 'compareceu'
        AND (p_start_date IS NULL OR bs.date::date >= p_start_date)
        AND (p_end_date IS NULL OR bs.date::date <= p_end_date);
    
    RETURN COALESCE(session_count, 0);
END;
$$;


ALTER FUNCTION public.get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date, p_end_date date) OWNER TO postgres;

--
-- Name: FUNCTION get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date, p_end_date date); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date, p_end_date date) IS 'Calculate billable sessions count for a patient within date range';


--
-- Name: get_monthly_billing_summary(character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_monthly_billing_summary(therapist_email character varying, summary_year integer DEFAULT EXTRACT(year FROM CURRENT_DATE), summary_month integer DEFAULT EXTRACT(month FROM CURRENT_DATE)) RETURNS TABLE(patient_name character varying, patient_id integer, billing_period_id integer, session_count integer, total_amount numeric, status character varying, has_payment boolean, processed_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.nome as patient_name,
        p.id as patient_id,
        bp.id as billing_period_id,
        bp.session_count,
        bp.total_amount,
        bp.status,
        EXISTS(SELECT 1 FROM monthly_billing_payments pay WHERE pay.billing_period_id = bp.id) as has_payment,
        bp.processed_at
    FROM monthly_billing_periods bp
    JOIN patients p ON bp.patient_id = p.id
    JOIN therapists t ON bp.therapist_id = t.id
    WHERE t.email = therapist_email
    AND bp.billing_year = summary_year
    AND bp.billing_month = summary_month
    AND bp.status != 'void'
    ORDER BY p.nome;
END;
$$;


ALTER FUNCTION public.get_monthly_billing_summary(therapist_email character varying, summary_year integer, summary_month integer) OWNER TO postgres;

--
-- Name: FUNCTION get_monthly_billing_summary(therapist_email character varying, summary_year integer, summary_month integer); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_monthly_billing_summary(therapist_email character varying, summary_year integer, summary_month integer) IS 'Get billing overview for therapist for specific month';


--
-- Name: get_patient_billing_cycle(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_patient_billing_cycle(p_patient_id integer, p_date date DEFAULT CURRENT_DATE) RETURNS TABLE(billing_cycle character varying, session_price numeric, effective_from_date date, is_override boolean)
    LANGUAGE plpgsql
    AS $$
DECLARE
    patient_therapist_id INTEGER;
BEGIN
    -- Get the therapist for this patient
    SELECT therapist_id INTO patient_therapist_id FROM patients WHERE id = p_patient_id;
    
    -- First check for patient-specific overrides
    RETURN QUERY
    SELECT 
        pbh.billing_cycle,
        pbh.session_price,
        pbh.effective_from_date,
        true as is_override
    FROM patient_billing_history pbh
    WHERE pbh.patient_id = p_patient_id
        AND pbh.effective_from_date <= p_date
        AND (pbh.effective_until_date IS NULL OR pbh.effective_until_date >= p_date)
    ORDER BY pbh.effective_from_date DESC
    LIMIT 1;
    
    -- If no patient override, use therapist default
    IF NOT FOUND THEN
        RETURN QUERY
        SELECT 
            therapy_cycle.billing_cycle,
            therapy_cycle.default_session_price,
            therapy_cycle.effective_from_date,
            false as is_override
        FROM get_therapist_billing_cycle(patient_therapist_id, p_date) therapy_cycle;
    END IF;
END;
$$;


ALTER FUNCTION public.get_patient_billing_cycle(p_patient_id integer, p_date date) OWNER TO postgres;

--
-- Name: FUNCTION get_patient_billing_cycle(p_patient_id integer, p_date date); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_patient_billing_cycle(p_patient_id integer, p_date date) IS 'Get billing cycle for patient with override support';


--
-- Name: get_session_timeouts(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_session_timeouts() RETURNS TABLE(inactive_timeout_minutes integer, warning_timeout_minutes numeric, max_session_hours integer, token_refresh_minutes integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        get_auth_config('auth_inactive_timeout_minutes')::INTEGER,
        get_auth_config('auth_warning_timeout_minutes')::NUMERIC,
        get_auth_config('auth_max_session_hours')::INTEGER,
        get_auth_config('auth_token_refresh_minutes')::INTEGER;
END;
$$;


ALTER FUNCTION public.get_session_timeouts() OWNER TO postgres;

--
-- Name: FUNCTION get_session_timeouts(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_session_timeouts() IS 'Get current timeout values for session creation';


--
-- Name: get_therapist_billing_cycle(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_therapist_billing_cycle(p_therapist_id integer, p_date date DEFAULT CURRENT_DATE) RETURNS TABLE(billing_cycle character varying, default_session_price numeric, effective_from_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tbh.billing_cycle,
        tbh.default_session_price,
        tbh.effective_from_date
    FROM therapist_billing_history tbh
    WHERE tbh.therapist_id = p_therapist_id
        AND tbh.effective_from_date <= p_date
        AND (tbh.effective_until_date IS NULL OR tbh.effective_until_date >= p_date)
    ORDER BY tbh.effective_from_date DESC
    LIMIT 1;
    
    -- If no history record exists, return the default from therapists table
    IF NOT FOUND THEN
        RETURN QUERY
        SELECT 
            t.billing_cycle,
            t.default_session_price,
            CURRENT_DATE as effective_from_date
        FROM therapists t
        WHERE t.id = p_therapist_id;
    END IF;
END;
$$;


ALTER FUNCTION public.get_therapist_billing_cycle(p_therapist_id integer, p_date date) OWNER TO postgres;

--
-- Name: FUNCTION get_therapist_billing_cycle(p_therapist_id integer, p_date date); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_therapist_billing_cycle(p_therapist_id integer, p_date date) IS 'Get current billing cycle configuration for therapist';


--
-- Name: get_therapist_setting(integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying DEFAULT NULL::character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    setting_value VARCHAR(255);
BEGIN
    SELECT ts.setting_value
    INTO setting_value
    FROM therapist_settings ts
    WHERE ts.therapist_id = p_therapist_id
        AND ts.setting_key = p_setting_key;
    
    RETURN COALESCE(setting_value, p_default_value);
END;
$$;


ALTER FUNCTION public.get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying) OWNER TO postgres;

--
-- Name: FUNCTION get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying) IS 'Get therapist UI setting with default fallback';


--
-- Name: get_user_practices(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_practices(p_user_id integer) RETURNS TABLE(therapist_id integer, therapist_name character varying, therapist_email character varying, user_role public.user_role, granted_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id as therapist_id,
        t.nome as therapist_name,
        t.email as therapist_email,
        up.role as user_role,
        up.granted_at
    FROM user_permissions up
    JOIN therapists t ON up.therapist_id = t.id
    WHERE up.user_id = p_user_id
    AND up.is_active = true
    AND (up.expires_at IS NULL OR up.expires_at > CURRENT_TIMESTAMP)
    ORDER BY up.granted_at ASC;
END;
$$;


ALTER FUNCTION public.get_user_practices(p_user_id integer) OWNER TO postgres;

--
-- Name: FUNCTION get_user_practices(p_user_id integer); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_user_practices(p_user_id integer) IS 'Get all practices user has access to with their roles';


--
-- Name: grant_super_admin(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.grant_super_admin(p_user_email character varying, p_granted_by_email character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    target_user_id INTEGER;
    granting_user_id INTEGER;
    super_admin_enabled BOOLEAN;
BEGIN
    -- Check if super admin is enabled
    SELECT get_auth_config('auth_super_admin_enabled')::BOOLEAN INTO super_admin_enabled;
    
    IF NOT super_admin_enabled THEN
        RAISE EXCEPTION 'Super admin role is disabled for security';
    END IF;
    
    -- Get user IDs
    SELECT id INTO target_user_id FROM user_credentials WHERE email = p_user_email;
    SELECT id INTO granting_user_id FROM user_credentials WHERE email = p_granted_by_email;
    
    IF target_user_id IS NULL THEN
        RAISE EXCEPTION 'Target user not found: %', p_user_email;
    END IF;
    
    IF granting_user_id IS NULL THEN
        RAISE EXCEPTION 'Granting user not found: %', p_granted_by_email;
    END IF;
    
    -- Grant super admin to any practice (we'll use therapist_id = 1 as placeholder)
    INSERT INTO user_permissions (
        user_id, therapist_id, role, granted_by, notes
    ) VALUES (
        target_user_id,
        (SELECT MIN(id) FROM therapists), -- Use first therapist as placeholder
        'super_admin',
        granting_user_id,
        'Super admin access granted - can access all practices'
    )
    ON CONFLICT (user_id, therapist_id) DO UPDATE SET
        role = 'super_admin',
        is_active = true,
        granted_by = granting_user_id,
        granted_at = CURRENT_TIMESTAMP,
        notes = EXCLUDED.notes;
    
    -- Log the grant
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    ) VALUES (
        NULL, granting_user_id, 'super_admin_granted',
        JSON_BUILD_OBJECT(
            'target_user', p_user_email,
            'granted_by', p_granted_by_email,
            'granted_at', CURRENT_TIMESTAMP
        )
    );
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.grant_super_admin(p_user_email character varying, p_granted_by_email character varying) OWNER TO postgres;

--
-- Name: FUNCTION grant_super_admin(p_user_email character varying, p_granted_by_email character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.grant_super_admin(p_user_email character varying, p_granted_by_email character varying) IS 'Grant super admin access (only when enabled)';


--
-- Name: migrate_existing_therapists_to_auth(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.migrate_existing_therapists_to_auth() RETURNS TABLE(therapist_id integer, therapist_email character varying, created_user_id integer, migration_status character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    therapist_record RECORD;
    new_user_id_var INTEGER;
    temp_password VARCHAR(255);
    permission_exists BOOLEAN;
BEGIN
    -- Iterate through existing therapists who don't have user credentials yet
    FOR therapist_record IN 
        SELECT t.id, t.email, t.nome 
        FROM therapists t 
        WHERE t.email IS NOT NULL 
        AND NOT EXISTS (
            SELECT 1 FROM user_permissions up 
            JOIN user_credentials uc ON up.user_id = uc.id 
            WHERE up.therapist_id = t.id AND uc.email = t.email
        )
    LOOP
        -- Generate temporary password (they'll need to reset it)
        temp_password := 'temp_' || EXTRACT(EPOCH FROM CURRENT_TIMESTAMP)::TEXT || '_' || RANDOM()::TEXT;
        
        -- Create user credential (or get existing)
        INSERT INTO user_credentials (
            email, password_hash, display_name, is_active, email_verified
        ) VALUES (
            therapist_record.email, 
            temp_password, -- They'll need to set real password via reset flow
            therapist_record.nome,
            true,
            false -- Require email verification
        )
        ON CONFLICT (email) DO UPDATE SET
            display_name = EXCLUDED.display_name
        RETURNING id INTO new_user_id_var;
        
        -- If no new user was created, get existing one
        IF new_user_id_var IS NULL THEN
            SELECT id INTO new_user_id_var 
            FROM user_credentials 
            WHERE email = therapist_record.email;
        END IF;
        
        -- Check if permission already exists using table alias
        SELECT EXISTS(
            SELECT 1 FROM user_permissions up
            WHERE up.user_id = new_user_id_var AND up.therapist_id = therapist_record.id
        ) INTO permission_exists;
        
        -- Grant owner permissions only if they don't exist
        IF NOT permission_exists THEN
            INSERT INTO user_permissions (
                user_id, therapist_id, role, granted_by, notes
            ) VALUES (
                new_user_id_var,
                therapist_record.id,
                'owner',
                new_user_id_var, -- Self-granted during migration
                'Migrated from existing therapist account'
            );
        END IF;
        
        -- Return migration result
        RETURN QUERY SELECT 
            therapist_record.id,
            therapist_record.email,
            new_user_id_var,
            'migrated'::VARCHAR(50);
    END LOOP;
END;
$$;


ALTER FUNCTION public.migrate_existing_therapists_to_auth() OWNER TO postgres;

--
-- Name: FUNCTION migrate_existing_therapists_to_auth(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.migrate_existing_therapists_to_auth() IS 'SAFE migration for existing therapists';


--
-- Name: set_auth_environment(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_auth_environment(env character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate environment
    IF env NOT IN ('production', 'development', 'testing') THEN
        RAISE EXCEPTION 'Invalid environment. Must be: production, development, or testing';
    END IF;
    
    -- Update environment setting
    UPDATE app_configuration 
    SET value = env, updated_at = CURRENT_TIMESTAMP 
    WHERE key = 'auth_environment';
    
    -- Log the environment change
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    ) VALUES (
        NULL, NULL, 'environment_change',
        JSON_BUILD_OBJECT(
            'new_environment', env,
            'changed_at', CURRENT_TIMESTAMP,
            'changed_by', 'system'
        )
    );
END;
$$;


ALTER FUNCTION public.set_auth_environment(env character varying) OWNER TO postgres;

--
-- Name: FUNCTION set_auth_environment(env character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.set_auth_environment(env character varying) IS 'Switch between production/development/testing modes';


--
-- Name: set_therapist_setting(integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO therapist_settings (therapist_id, setting_key, setting_value, updated_at)
    VALUES (p_therapist_id, p_setting_key, p_setting_value, CURRENT_TIMESTAMP)
    ON CONFLICT (therapist_id, setting_key)
    DO UPDATE SET 
        setting_value = EXCLUDED.setting_value,
        updated_at = CURRENT_TIMESTAMP;
END;
$$;


ALTER FUNCTION public.set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying) OWNER TO postgres;

--
-- Name: FUNCTION set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying) IS 'Set or update therapist UI setting (upsert)';


--
-- Name: show_auth_config(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.show_auth_config() RETURNS TABLE(environment character varying, setting character varying, current_value character varying, description text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_env VARCHAR(255);
BEGIN
    -- Get current environment
    SELECT get_auth_config('auth_environment') INTO current_env;
    
    -- Return all auth settings with current values
    RETURN QUERY
    SELECT 
        current_env as environment,
        config.key as setting,
        get_auth_config(config.key) as current_value,
        config.description
    FROM app_configuration config
    WHERE config.key LIKE 'auth_%'
    OR config.key LIKE 'google_%'
    ORDER BY config.key;
END;
$$;


ALTER FUNCTION public.show_auth_config() OWNER TO postgres;

--
-- Name: FUNCTION show_auth_config(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.show_auth_config() IS 'Display current authentication configuration';


--
-- Name: update_billing_period_status(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_billing_period_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        -- Payment added: mark period as paid and prevent voiding
        UPDATE monthly_billing_periods 
        SET 
            status = 'paid',
            can_be_voided = false
        WHERE id = NEW.billing_period_id;
        
    ELSIF TG_OP = 'DELETE' THEN
        -- Payment deleted: check if any payments remain
        IF NOT EXISTS (
            SELECT 1 FROM monthly_billing_payments 
            WHERE billing_period_id = OLD.billing_period_id
        ) THEN
            -- No payments left: allow voiding again
            UPDATE monthly_billing_periods 
            SET 
                status = 'processed',
                can_be_voided = true
            WHERE id = OLD.billing_period_id;
        END IF;
    END IF;
    
    RETURN COALESCE(NEW, OLD);
END;
$$;


ALTER FUNCTION public.update_billing_period_status() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: user_has_permission(integer, integer, public.user_role); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role DEFAULT 'viewer'::public.user_role) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    user_role_level INTEGER;
    required_role_level INTEGER;
BEGIN
    -- Define role hierarchy (higher number = more permissions)
    SELECT CASE 
        WHEN up.role = 'super_admin' THEN 4
        WHEN up.role = 'owner' THEN 3
        WHEN up.role = 'manager' THEN 2
        WHEN up.role = 'viewer' THEN 1
        ELSE 0
    END INTO user_role_level
    FROM user_permissions up
    WHERE up.user_id = p_user_id 
    AND up.therapist_id = p_therapist_id
    AND up.is_active = true
    AND (up.expires_at IS NULL OR up.expires_at > CURRENT_TIMESTAMP);
    
    -- If user not found, check for super_admin on any practice
    IF user_role_level IS NULL THEN
        SELECT CASE 
            WHEN up.role = 'super_admin' THEN 4
            ELSE 0
        END INTO user_role_level
        FROM user_permissions up
        WHERE up.user_id = p_user_id 
        AND up.role = 'super_admin'
        AND up.is_active = true
        AND (up.expires_at IS NULL OR up.expires_at > CURRENT_TIMESTAMP)
        LIMIT 1;
    END IF;
    
    -- Get required role level
    required_role_level := CASE 
        WHEN p_required_role = 'super_admin' THEN 4
        WHEN p_required_role = 'owner' THEN 3
        WHEN p_required_role = 'manager' THEN 2
        WHEN p_required_role = 'viewer' THEN 1
        ELSE 0
    END;
    
    RETURN COALESCE(user_role_level, 0) >= required_role_level;
END;
$$;


ALTER FUNCTION public.user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role) OWNER TO postgres;

--
-- Name: FUNCTION user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role) IS 'Check if user has required role for practice (supports super_admin)';


--
-- Name: void_billing_period(integer, character varying, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.void_billing_period(period_id integer, voided_by_email character varying, reason text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if period can be voided
    IF NOT can_void_billing_period(period_id) THEN
        RETURN false;
    END IF;
    
    -- Void the period
    UPDATE monthly_billing_periods 
    SET 
        status = 'void',
        can_be_voided = false,
        voided_at = CURRENT_TIMESTAMP,
        voided_by = voided_by_email,
        void_reason = reason
    WHERE id = period_id;
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.void_billing_period(period_id integer, voided_by_email character varying, reason text) OWNER TO postgres;

--
-- Name: FUNCTION void_billing_period(period_id integer, voided_by_email character varying, reason text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.void_billing_period(period_id integer, voided_by_email character varying, reason text) IS 'Safely void a billing period with audit trail (only if no payments exist)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_configuration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_configuration (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.app_configuration OWNER TO postgres;

--
-- Name: TABLE app_configuration; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.app_configuration IS 'Global application configuration settings';


--
-- Name: COLUMN app_configuration.key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_configuration.key IS 'Global setting key: calendar_mode, app_version, etc.';


--
-- Name: COLUMN app_configuration.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.app_configuration.value IS 'Global setting value stored as string';


--
-- Name: app_configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.app_configuration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.app_configuration_id_seq OWNER TO postgres;

--
-- Name: app_configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.app_configuration_id_seq OWNED BY public.app_configuration.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    email character varying(255),
    telefone character varying(20),
    cpf character varying(14),
    nota boolean DEFAULT false,
    preco numeric(10,2),
    therapist_id integer,
    therapy_start_date date,
    lv_notas_billing_start_date date,
    session_price numeric(10,2),
    recurring_pattern character varying(50),
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patients OWNER TO postgres;

--
-- Name: TABLE patients; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.patients IS 'Patient records with dual date system for therapy vs billing tracking and CPF support';


--
-- Name: COLUMN patients.cpf; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patients.cpf IS 'Brazilian CPF (Cadastro de Pessoas Físicas) - format XXX.XXX.XXX-XX';


--
-- Name: COLUMN patients.therapy_start_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patients.therapy_start_date IS 'Historical date when therapy actually began (optional, for context only)';


--
-- Name: COLUMN patients.lv_notas_billing_start_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patients.lv_notas_billing_start_date IS 'Date when LV Notas billing begins (required, affects billing calculations)';


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    google_calendar_event_id character varying(255),
    patient_id integer,
    therapist_id integer,
    status public.session_status DEFAULT 'agendada'::public.session_status,
    billable boolean DEFAULT true,
    billing_period character varying(20),
    session_price numeric(10,2),
    billing_cycle_used character varying(20),
    created_during_onboarding boolean DEFAULT false,
    import_batch_id character varying(255),
    payment_requested boolean DEFAULT false,
    payment_request_date timestamp with time zone,
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    paid_date timestamp with time zone,
    billing_period_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.sessions IS 'Therapy sessions with billing and payment tracking';


--
-- Name: COLUMN sessions.billable; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.billable IS 'Whether this session counts toward billing (based on billing start date)';


--
-- Name: COLUMN sessions.created_during_onboarding; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.created_during_onboarding IS 'Was this session created during the onboarding import process';


--
-- Name: COLUMN sessions.payment_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.payment_status IS 'Current payment status: pending, paid, overdue, etc.';


--
-- Name: billable_sessions; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.billable_sessions AS
 SELECT s.id,
    s.date,
    s.google_calendar_event_id,
    s.patient_id,
    s.therapist_id,
    s.status,
    s.billable,
    s.billing_period,
    s.session_price,
    s.billing_cycle_used,
    s.created_during_onboarding,
    s.import_batch_id,
    s.payment_requested,
    s.payment_request_date,
    s.payment_status,
    s.paid_date,
    s.billing_period_id,
    s.created_at,
    p.lv_notas_billing_start_date,
        CASE
            WHEN ((s.date)::date >= p.lv_notas_billing_start_date) THEN true
            ELSE false
        END AS counts_for_billing
   FROM (public.sessions s
     JOIN public.patients p ON ((s.patient_id = p.id)))
  WHERE (s.billable = true);


ALTER TABLE public.billable_sessions OWNER TO postgres;

--
-- Name: VIEW billable_sessions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.billable_sessions IS 'Sessions that count for billing based on LV Notas billing start date';


--
-- Name: patient_billing_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_billing_history (
    id integer NOT NULL,
    patient_id integer,
    therapist_id integer,
    billing_cycle character varying(20) NOT NULL,
    session_price numeric(10,2),
    effective_from_date date NOT NULL,
    effective_until_date date,
    reason_for_change text,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


ALTER TABLE public.patient_billing_history OWNER TO postgres;

--
-- Name: TABLE patient_billing_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.patient_billing_history IS 'Patient-specific billing overrides with full history';


--
-- Name: COLUMN patient_billing_history.effective_until_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_billing_history.effective_until_date IS 'NULL means this is the current active override';


--
-- Name: therapist_billing_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.therapist_billing_history (
    id integer NOT NULL,
    therapist_id integer,
    billing_cycle character varying(20) NOT NULL,
    default_session_price numeric(10,2),
    effective_from_date date NOT NULL,
    effective_until_date date,
    reason_for_change text,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


ALTER TABLE public.therapist_billing_history OWNER TO postgres;

--
-- Name: TABLE therapist_billing_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.therapist_billing_history IS 'Complete history of billing cycle changes for therapists';


--
-- Name: COLUMN therapist_billing_history.effective_until_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.therapist_billing_history.effective_until_date IS 'NULL means this is the current active billing cycle';


--
-- Name: therapists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.therapists (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    email character varying(255),
    telefone character varying(20),
    google_calendar_id character varying(255),
    billing_cycle character varying(20) DEFAULT 'monthly'::character varying,
    default_session_price numeric(10,2),
    onboarding_completed boolean DEFAULT false,
    onboarding_started_at timestamp with time zone,
    onboarding_completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.therapists OWNER TO postgres;

--
-- Name: TABLE therapists; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.therapists IS 'Core therapist accounts with billing and onboarding configuration';


--
-- Name: billing_change_history; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.billing_change_history AS
 SELECT 'therapist'::text AS change_type,
    tbh.id AS history_id,
    tbh.therapist_id,
    NULL::integer AS patient_id,
    t.nome AS therapist_name,
    NULL::character varying AS patient_name,
    tbh.billing_cycle,
    tbh.default_session_price AS price,
    tbh.effective_from_date,
    tbh.effective_until_date,
    tbh.reason_for_change,
    tbh.created_by,
    tbh.created_at,
    tbh.notes
   FROM (public.therapist_billing_history tbh
     JOIN public.therapists t ON ((tbh.therapist_id = t.id)))
UNION ALL
 SELECT 'patient'::text AS change_type,
    pbh.id AS history_id,
    pbh.therapist_id,
    pbh.patient_id,
    t.nome AS therapist_name,
    p.nome AS patient_name,
    pbh.billing_cycle,
    pbh.session_price AS price,
    pbh.effective_from_date,
    pbh.effective_until_date,
    pbh.reason_for_change,
    pbh.created_by,
    pbh.created_at,
    pbh.notes
   FROM ((public.patient_billing_history pbh
     JOIN public.therapists t ON ((pbh.therapist_id = t.id)))
     JOIN public.patients p ON ((pbh.patient_id = p.id)))
  ORDER BY 13 DESC;


ALTER TABLE public.billing_change_history OWNER TO postgres;

--
-- Name: VIEW billing_change_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.billing_change_history IS 'Complete history of all billing changes for therapists and patients';


--
-- Name: billing_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.billing_periods (
    id integer NOT NULL,
    therapist_id integer,
    patient_id integer,
    billing_cycle character varying(20) NOT NULL,
    period_start_date date NOT NULL,
    period_end_date date NOT NULL,
    total_sessions integer DEFAULT 0,
    billable_sessions integer DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0.00,
    invoice_generated boolean DEFAULT false,
    invoice_sent boolean DEFAULT false,
    invoice_paid boolean DEFAULT false,
    invoice_date date,
    payment_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_periods OWNER TO postgres;

--
-- Name: TABLE billing_periods; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.billing_periods IS 'Actual billing periods and invoice tracking';


--
-- Name: COLUMN billing_periods.billable_sessions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.billing_periods.billable_sessions IS 'Sessions that count for billing (after LV Notas start date)';


--
-- Name: billing_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.billing_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billing_periods_id_seq OWNER TO postgres;

--
-- Name: billing_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.billing_periods_id_seq OWNED BY public.billing_periods.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calendar_events (
    id integer NOT NULL,
    event_type public.event_type NOT NULL,
    google_event_id character varying(255) NOT NULL,
    session_date timestamp with time zone NOT NULL,
    email character varying(255),
    date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendar_events OWNER TO postgres;

--
-- Name: TABLE calendar_events; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.calendar_events IS 'Log of calendar events for sync tracking';


--
-- Name: calendar_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calendar_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calendar_events_id_seq OWNER TO postgres;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calendar_events_id_seq OWNED BY public.calendar_events.id;


--
-- Name: calendar_webhooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calendar_webhooks (
    id integer NOT NULL,
    channel_id character varying(255) NOT NULL,
    resource_id character varying(255) NOT NULL,
    expiration timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendar_webhooks OWNER TO postgres;

--
-- Name: TABLE calendar_webhooks; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.calendar_webhooks IS 'Active Google Calendar webhook subscriptions';


--
-- Name: calendar_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calendar_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calendar_webhooks_id_seq OWNER TO postgres;

--
-- Name: calendar_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calendar_webhooks_id_seq OWNED BY public.calendar_webhooks.id;


--
-- Name: check_ins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.check_ins (
    id integer NOT NULL,
    patient_id integer,
    session_id integer,
    session_date timestamp with time zone,
    created_by character varying(255) NOT NULL,
    date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(10) DEFAULT 'compareceu'::character varying
);


ALTER TABLE public.check_ins OWNER TO postgres;

--
-- Name: TABLE check_ins; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.check_ins IS 'Patient attendance records';


--
-- Name: check_ins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.check_ins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.check_ins_id_seq OWNER TO postgres;

--
-- Name: check_ins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.check_ins_id_seq OWNED BY public.check_ins.id;


--
-- Name: current_billing_settings; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.current_billing_settings AS
 SELECT p.id AS patient_id,
    p.nome AS patient_name,
    p.therapist_id,
    t.nome AS therapist_name,
    t.email AS therapist_email,
    t.billing_cycle AS current_billing_cycle,
    COALESCE(p.session_price, t.default_session_price) AS current_session_price,
        CASE
            WHEN (p.session_price IS NOT NULL) THEN true
            ELSE false
        END AS has_patient_override,
    p.lv_notas_billing_start_date,
    ( SELECT count(*) AS count
           FROM public.sessions s
          WHERE ((s.patient_id = p.id) AND (s.billable = true) AND (s.status = 'compareceu'::public.session_status) AND (p.lv_notas_billing_start_date IS NOT NULL) AND ((s.date)::date >= p.lv_notas_billing_start_date))) AS total_billable_sessions
   FROM (public.patients p
     JOIN public.therapists t ON ((p.therapist_id = t.id)));


ALTER TABLE public.current_billing_settings OWNER TO postgres;

--
-- Name: VIEW current_billing_settings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.current_billing_settings IS 'Current billing configuration for all patients with session counts';


--
-- Name: imported_calendar_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imported_calendar_events (
    id integer NOT NULL,
    therapist_id integer,
    google_event_id character varying(255) NOT NULL,
    original_summary character varying(500),
    description text,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    attendees_emails text[],
    is_therapy_session boolean DEFAULT false,
    is_recurring boolean DEFAULT false,
    recurring_rule text,
    linked_patient_id integer,
    matched_patient_name character varying(255),
    processed boolean DEFAULT false,
    import_batch_id character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp with time zone
);


ALTER TABLE public.imported_calendar_events OWNER TO postgres;

--
-- Name: TABLE imported_calendar_events; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.imported_calendar_events IS 'Calendar events imported during onboarding for processing';


--
-- Name: imported_calendar_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.imported_calendar_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.imported_calendar_events_id_seq OWNER TO postgres;

--
-- Name: imported_calendar_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.imported_calendar_events_id_seq OWNED BY public.imported_calendar_events.id;


--
-- Name: monthly_billing_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monthly_billing_payments (
    id integer NOT NULL,
    billing_period_id integer,
    therapist_id integer,
    patient_id integer,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(50),
    payment_date timestamp with time zone NOT NULL,
    reference_number character varying(255),
    recorded_by character varying(255) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.monthly_billing_payments OWNER TO postgres;

--
-- Name: TABLE monthly_billing_payments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.monthly_billing_payments IS 'Actual payments received for billing periods';


--
-- Name: monthly_billing_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monthly_billing_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monthly_billing_payments_id_seq OWNER TO postgres;

--
-- Name: monthly_billing_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monthly_billing_payments_id_seq OWNED BY public.monthly_billing_payments.id;


--
-- Name: monthly_billing_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monthly_billing_periods (
    id integer NOT NULL,
    therapist_id integer,
    patient_id integer,
    billing_year integer NOT NULL,
    billing_month integer NOT NULL,
    session_count integer DEFAULT 0 NOT NULL,
    total_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    session_snapshots jsonb DEFAULT '[]'::jsonb NOT NULL,
    processed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    processed_by character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'processed'::character varying,
    can_be_voided boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    voided_at timestamp with time zone,
    voided_by character varying(255),
    void_reason text
);


ALTER TABLE public.monthly_billing_periods OWNER TO postgres;

--
-- Name: TABLE monthly_billing_periods; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.monthly_billing_periods IS 'Monthly billing periods with immutable session snapshots from Google Calendar';


--
-- Name: COLUMN monthly_billing_periods.session_snapshots; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.monthly_billing_periods.session_snapshots IS 'JSON array of session details from Google Calendar at processing time';


--
-- Name: COLUMN monthly_billing_periods.can_be_voided; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.monthly_billing_periods.can_be_voided IS 'False once any payment exists - prevents accidental voiding of paid periods';


--
-- Name: monthly_billing_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monthly_billing_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monthly_billing_periods_id_seq OWNER TO postgres;

--
-- Name: monthly_billing_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monthly_billing_periods_id_seq OWNED BY public.monthly_billing_periods.id;


--
-- Name: patient_billing_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patient_billing_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patient_billing_history_id_seq OWNER TO postgres;

--
-- Name: patient_billing_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patient_billing_history_id_seq OWNED BY public.patient_billing_history.id;


--
-- Name: patient_matching_candidates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_matching_candidates (
    id integer NOT NULL,
    therapist_id integer,
    import_batch_id character varying(255) NOT NULL,
    extracted_name character varying(255) NOT NULL,
    name_variations text[],
    email_addresses text[],
    event_count integer DEFAULT 0,
    first_session_date date,
    latest_session_date date,
    suggested_therapy_start_date date,
    suggested_billing_start_date date,
    confidence_score numeric(3,2) DEFAULT 0.0,
    manual_review_needed boolean DEFAULT false,
    created_patient_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_matching_candidates OWNER TO postgres;

--
-- Name: TABLE patient_matching_candidates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.patient_matching_candidates IS 'Smart patient detection and matching from calendar events';


--
-- Name: COLUMN patient_matching_candidates.suggested_therapy_start_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_matching_candidates.suggested_therapy_start_date IS 'AI-suggested historical therapy start date based on calendar history';


--
-- Name: COLUMN patient_matching_candidates.suggested_billing_start_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_matching_candidates.suggested_billing_start_date IS 'Default LV Notas billing start date (usually today)';


--
-- Name: patient_matching_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patient_matching_candidates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patient_matching_candidates_id_seq OWNER TO postgres;

--
-- Name: patient_matching_candidates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patient_matching_candidates_id_seq OWNED BY public.patient_matching_candidates.id;


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patients_id_seq OWNER TO postgres;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_transactions (
    id integer NOT NULL,
    session_id integer,
    patient_id integer,
    therapist_id integer,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(50),
    payment_date timestamp with time zone NOT NULL,
    reference_number character varying(255),
    notes text,
    created_by character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payment_transactions OWNER TO postgres;

--
-- Name: TABLE payment_transactions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.payment_transactions IS 'Records of actual payments received from patients';


--
-- Name: COLUMN payment_transactions.payment_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.payment_transactions.payment_method IS 'PIX, bank transfer, cash, credit card, etc.';


--
-- Name: payment_overview; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.payment_overview AS
 SELECT s.id AS session_id,
    s.date AS session_date,
    s.session_price,
    s.payment_status,
    s.payment_requested,
    s.payment_request_date,
    s.paid_date,
    p.id AS patient_id,
    p.nome AS patient_name,
    p.telefone AS patient_phone,
    t.id AS therapist_id,
    t.nome AS therapist_name,
    t.email AS therapist_email,
    pt.id AS payment_transaction_id,
    pt.amount AS paid_amount,
    pt.payment_method,
    pt.payment_date,
    pt.reference_number,
    (CURRENT_DATE - (s.date)::date) AS days_since_session,
        CASE
            WHEN (s.payment_request_date IS NOT NULL) THEN (CURRENT_DATE - (s.payment_request_date)::date)
            ELSE NULL::integer
        END AS days_since_request,
        CASE
            WHEN ((s.payment_status)::text = 'paid'::text) THEN 'pago'::text
            WHEN (s.payment_requested = false) THEN 'nao_cobrado'::text
            WHEN ((s.payment_requested = true) AND (s.payment_request_date > (CURRENT_DATE - '7 days'::interval))) THEN 'aguardando_pagamento'::text
            WHEN ((s.payment_requested = true) AND (s.payment_request_date <= (CURRENT_DATE - '7 days'::interval))) THEN 'pendente'::text
            ELSE 'nao_cobrado'::text
        END AS payment_state
   FROM (((public.sessions s
     JOIN public.patients p ON ((s.patient_id = p.id)))
     JOIN public.therapists t ON ((s.therapist_id = t.id)))
     LEFT JOIN public.payment_transactions pt ON ((s.id = pt.session_id)))
  WHERE ((s.status = 'compareceu'::public.session_status) AND ((s.date)::date >= p.lv_notas_billing_start_date));


ALTER TABLE public.payment_overview OWNER TO postgres;

--
-- Name: VIEW payment_overview; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.payment_overview IS 'Complete payment status overview with calculated payment states';


--
-- Name: payment_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_requests (
    id integer NOT NULL,
    patient_id integer,
    therapist_id integer,
    session_ids integer[],
    total_amount numeric(10,2) NOT NULL,
    request_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    request_type character varying(20) DEFAULT 'invoice'::character varying,
    whatsapp_sent boolean DEFAULT false,
    whatsapp_message text,
    response_received boolean DEFAULT false,
    response_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payment_requests OWNER TO postgres;

--
-- Name: TABLE payment_requests; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.payment_requests IS 'Log of payment communications sent to patients (WhatsApp, email, etc.)';


--
-- Name: COLUMN payment_requests.session_ids; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.payment_requests.session_ids IS 'Array of session IDs included in this payment request';


--
-- Name: COLUMN payment_requests.whatsapp_message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.payment_requests.whatsapp_message IS 'The actual message content sent via WhatsApp';


--
-- Name: payment_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_requests_id_seq OWNER TO postgres;

--
-- Name: payment_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_requests_id_seq OWNED BY public.payment_requests.id;


--
-- Name: payment_status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_status_history (
    id integer NOT NULL,
    session_id integer,
    old_status character varying(50),
    new_status character varying(50),
    changed_by character varying(255),
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    reason text,
    payment_transaction_id integer
);


ALTER TABLE public.payment_status_history OWNER TO postgres;

--
-- Name: TABLE payment_status_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.payment_status_history IS 'Complete audit trail of payment status changes';


--
-- Name: payment_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_status_history_id_seq OWNER TO postgres;

--
-- Name: payment_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_status_history_id_seq OWNED BY public.payment_status_history.id;


--
-- Name: payment_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_transactions_id_seq OWNER TO postgres;

--
-- Name: payment_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_transactions_id_seq OWNED BY public.payment_transactions.id;


--
-- Name: practice_invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.practice_invitations (
    id integer NOT NULL,
    therapist_id integer,
    invited_by integer,
    invited_email character varying(255) NOT NULL,
    invited_role public.user_role NOT NULL,
    invitation_token character varying(255) NOT NULL,
    personal_message text,
    permissions_description text,
    status public.invitation_status DEFAULT 'pending'::public.invitation_status,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '7 days'::interval),
    responded_at timestamp with time zone,
    accepted_by integer,
    decline_reason text
);


ALTER TABLE public.practice_invitations OWNER TO postgres;

--
-- Name: TABLE practice_invitations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.practice_invitations IS 'Invitation system for adding users to practices';


--
-- Name: practice_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.practice_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.practice_invitations_id_seq OWNER TO postgres;

--
-- Name: practice_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.practice_invitations_id_seq OWNED BY public.practice_invitations.id;


--
-- Name: recurring_session_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurring_session_templates (
    id integer NOT NULL,
    therapist_id integer,
    patient_id integer,
    day_of_week integer,
    start_time time without time zone NOT NULL,
    duration_minutes integer DEFAULT 60,
    frequency character varying(20) DEFAULT 'weekly'::character varying,
    effective_from date NOT NULL,
    effective_until date,
    status character varying(20) DEFAULT 'active'::character varying,
    created_from_import boolean DEFAULT false,
    import_batch_id character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.recurring_session_templates OWNER TO postgres;

--
-- Name: TABLE recurring_session_templates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.recurring_session_templates IS 'Detected recurring appointment patterns for automation';


--
-- Name: recurring_session_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recurring_session_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recurring_session_templates_id_seq OWNER TO postgres;

--
-- Name: recurring_session_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recurring_session_templates_id_seq OWNED BY public.recurring_session_templates.id;


--
-- Name: session_activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session_activity_log (
    id integer NOT NULL,
    session_id integer,
    user_id integer,
    activity_type character varying(50) NOT NULL,
    endpoint character varying(255),
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.session_activity_log OWNER TO postgres;

--
-- Name: TABLE session_activity_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.session_activity_log IS 'Security and activity tracking for sessions';


--
-- Name: session_activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.session_activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.session_activity_log_id_seq OWNER TO postgres;

--
-- Name: session_activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.session_activity_log_id_seq OWNED BY public.session_activity_log.id;


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sessions_id_seq OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: therapist_billing_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.therapist_billing_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapist_billing_history_id_seq OWNER TO postgres;

--
-- Name: therapist_billing_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.therapist_billing_history_id_seq OWNED BY public.therapist_billing_history.id;


--
-- Name: therapist_onboarding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.therapist_onboarding (
    id integer NOT NULL,
    therapist_id integer,
    step character varying(50) NOT NULL,
    completed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    data jsonb,
    notes text
);


ALTER TABLE public.therapist_onboarding OWNER TO postgres;

--
-- Name: TABLE therapist_onboarding; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.therapist_onboarding IS 'Step-by-step tracking of therapist onboarding process';


--
-- Name: therapist_onboarding_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.therapist_onboarding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapist_onboarding_id_seq OWNER TO postgres;

--
-- Name: therapist_onboarding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.therapist_onboarding_id_seq OWNED BY public.therapist_onboarding.id;


--
-- Name: therapist_onboarding_progress; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.therapist_onboarding_progress AS
 SELECT t.id AS therapist_id,
    t.email,
    t.onboarding_completed,
    t.onboarding_started_at,
    t.onboarding_completed_at,
    COALESCE(json_agg(json_build_object('step', tog.step, 'completed_at', tog.completed_at, 'data', tog.data, 'notes', tog.notes) ORDER BY tog.completed_at) FILTER (WHERE (tog.step IS NOT NULL)), '[]'::json) AS completed_steps,
        CASE
            WHEN t.onboarding_completed THEN 'completed'::text
            WHEN (count(tog.step) = 0) THEN 'not_started'::text
            ELSE 'in_progress'::text
        END AS status
   FROM (public.therapists t
     LEFT JOIN public.therapist_onboarding tog ON ((t.id = tog.therapist_id)))
  GROUP BY t.id, t.email, t.onboarding_completed, t.onboarding_started_at, t.onboarding_completed_at;


ALTER TABLE public.therapist_onboarding_progress OWNER TO postgres;

--
-- Name: VIEW therapist_onboarding_progress; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.therapist_onboarding_progress IS 'Complete onboarding status and progress for each therapist';


--
-- Name: therapist_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.therapist_settings (
    id integer NOT NULL,
    therapist_id integer,
    setting_key character varying(50) NOT NULL,
    setting_value character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.therapist_settings OWNER TO postgres;

--
-- Name: TABLE therapist_settings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.therapist_settings IS 'Stores persistent UI preferences for each therapist';


--
-- Name: COLUMN therapist_settings.setting_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.therapist_settings.setting_key IS 'Setting name: payment_mode, view_mode, auto_check_in_mode, etc.';


--
-- Name: COLUMN therapist_settings.setting_value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.therapist_settings.setting_value IS 'Setting value stored as string (parse as needed)';


--
-- Name: therapist_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.therapist_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapist_settings_id_seq OWNER TO postgres;

--
-- Name: therapist_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.therapist_settings_id_seq OWNED BY public.therapist_settings.id;


--
-- Name: therapists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.therapists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapists_id_seq OWNER TO postgres;

--
-- Name: therapists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.therapists_id_seq OWNED BY public.therapists.id;


--
-- Name: user_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_credentials (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    google_permissions_granted boolean DEFAULT false,
    google_access_token text,
    google_refresh_token text,
    google_token_expires_at timestamp with time zone,
    google_permissions_granted_at timestamp with time zone,
    is_active boolean DEFAULT true,
    email_verified boolean DEFAULT false,
    email_verification_token character varying(255),
    email_verified_at timestamp with time zone,
    password_reset_token character varying(255),
    password_reset_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_login_at timestamp with time zone
);


ALTER TABLE public.user_credentials OWNER TO postgres;

--
-- Name: TABLE user_credentials; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_credentials IS 'User authentication with email/password and Google permissions';


--
-- Name: user_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_credentials_id_seq OWNER TO postgres;

--
-- Name: user_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_credentials_id_seq OWNED BY public.user_credentials.id;


--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_permissions (
    id integer NOT NULL,
    user_id integer,
    therapist_id integer,
    role public.user_role NOT NULL,
    granted_by integer,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    notes text
);


ALTER TABLE public.user_permissions OWNER TO postgres;

--
-- Name: TABLE user_permissions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_permissions IS 'Role-based access control for practices';


--
-- Name: user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_permissions_id_seq OWNER TO postgres;

--
-- Name: user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_permissions_id_seq OWNED BY public.user_permissions.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer,
    session_token character varying(255) NOT NULL,
    inactive_timeout_minutes integer DEFAULT 30,
    warning_timeout_minutes integer DEFAULT 2,
    max_session_hours integer DEFAULT 8,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_activity_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    status public.session_status_auth DEFAULT 'active'::public.session_status_auth,
    terminated_at timestamp with time zone,
    termination_reason character varying(100),
    ip_address inet,
    user_agent text,
    device_fingerprint character varying(255)
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_sessions IS 'Active user sessions with configurable timeouts';


--
-- Name: COLUMN user_sessions.inactive_timeout_minutes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_sessions.inactive_timeout_minutes IS 'Configurable: 10 min prod, 2 min dev';


--
-- Name: COLUMN user_sessions.warning_timeout_minutes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_sessions.warning_timeout_minutes IS 'Configurable: 1 min prod, 10 sec dev';


--
-- Name: COLUMN user_sessions.max_session_hours; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_sessions.max_session_hours IS 'Configurable: 8 hrs prod, 1 hr dev';


--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_sessions_id_seq OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: app_configuration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_configuration ALTER COLUMN id SET DEFAULT nextval('public.app_configuration_id_seq'::regclass);


--
-- Name: billing_periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_periods ALTER COLUMN id SET DEFAULT nextval('public.billing_periods_id_seq'::regclass);


--
-- Name: calendar_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_events ALTER COLUMN id SET DEFAULT nextval('public.calendar_events_id_seq'::regclass);


--
-- Name: calendar_webhooks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_webhooks ALTER COLUMN id SET DEFAULT nextval('public.calendar_webhooks_id_seq'::regclass);


--
-- Name: check_ins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_ins ALTER COLUMN id SET DEFAULT nextval('public.check_ins_id_seq'::regclass);


--
-- Name: imported_calendar_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_calendar_events ALTER COLUMN id SET DEFAULT nextval('public.imported_calendar_events_id_seq'::regclass);


--
-- Name: monthly_billing_payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_payments ALTER COLUMN id SET DEFAULT nextval('public.monthly_billing_payments_id_seq'::regclass);


--
-- Name: monthly_billing_periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_periods ALTER COLUMN id SET DEFAULT nextval('public.monthly_billing_periods_id_seq'::regclass);


--
-- Name: patient_billing_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_billing_history ALTER COLUMN id SET DEFAULT nextval('public.patient_billing_history_id_seq'::regclass);


--
-- Name: patient_matching_candidates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_matching_candidates ALTER COLUMN id SET DEFAULT nextval('public.patient_matching_candidates_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: payment_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_requests ALTER COLUMN id SET DEFAULT nextval('public.payment_requests_id_seq'::regclass);


--
-- Name: payment_status_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_status_history ALTER COLUMN id SET DEFAULT nextval('public.payment_status_history_id_seq'::regclass);


--
-- Name: payment_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions ALTER COLUMN id SET DEFAULT nextval('public.payment_transactions_id_seq'::regclass);


--
-- Name: practice_invitations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.practice_invitations ALTER COLUMN id SET DEFAULT nextval('public.practice_invitations_id_seq'::regclass);


--
-- Name: recurring_session_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_session_templates ALTER COLUMN id SET DEFAULT nextval('public.recurring_session_templates_id_seq'::regclass);


--
-- Name: session_activity_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activity_log ALTER COLUMN id SET DEFAULT nextval('public.session_activity_log_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: therapist_billing_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_billing_history ALTER COLUMN id SET DEFAULT nextval('public.therapist_billing_history_id_seq'::regclass);


--
-- Name: therapist_onboarding id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_onboarding ALTER COLUMN id SET DEFAULT nextval('public.therapist_onboarding_id_seq'::regclass);


--
-- Name: therapist_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_settings ALTER COLUMN id SET DEFAULT nextval('public.therapist_settings_id_seq'::regclass);


--
-- Name: therapists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapists ALTER COLUMN id SET DEFAULT nextval('public.therapists_id_seq'::regclass);


--
-- Name: user_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials ALTER COLUMN id SET DEFAULT nextval('public.user_credentials_id_seq'::regclass);


--
-- Name: user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions ALTER COLUMN id SET DEFAULT nextval('public.user_permissions_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Data for Name: app_configuration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_configuration (id, key, value, description, created_at, updated_at) FROM stdin;
1	calendar_mode	read_only	Calendar integration mode: read_only or read_write	2025-07-20 10:49:22.700982+00	2025-07-20 10:49:22.700982+00
2	app_version	1.0.0	Current application version	2025-07-20 10:49:22.700982+00	2025-07-20 10:49:22.700982+00
3	default_session_duration	60	Default session duration in minutes	2025-07-20 10:49:22.700982+00	2025-07-20 10:49:22.700982+00
4	calendar_sync_enabled	true	Whether calendar synchronization is enabled globally	2025-07-20 10:49:22.700982+00	2025-07-20 10:49:22.700982+00
7	auth_max_session_hours	8	Maximum session duration in hours (PROD: 8, DEV: 1)	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
8	auth_token_refresh_minutes	55	Minutes before token expiry to refresh (PROD: 55, DEV: 5)	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
9	auth_environment	production	Current environment: production, development, testing	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
10	auth_super_admin_enabled	true	Whether super admin role is enabled (can be disabled for security)	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
11	auth_password_reset_expires_hours	24	Hours before password reset token expires	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
12	auth_invitation_expires_days	7	Days before practice invitation expires	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
13	auth_require_email_verification	true	Whether email verification is required for new accounts	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
14	auth_session_cleanup_interval_minutes	15	How often to run expired session cleanup (background job)	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
15	google_permissions_scopes	https://www.googleapis.com/auth/calendar.readonly,email,profile	Google OAuth scopes requested during setup	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
5	auth_inactive_timeout_minutes	60	Minutes of inactivity before showing warning modal (PROD: 10, DEV: 2)	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
6	auth_warning_timeout_minutes	5	Minutes to show in warning countdown before auto-logout (PROD: 1, DEV: 0.17 = 10sec)	2025-07-27 11:29:01.681516+00	2025-07-27 11:29:01.681516+00
\.


--
-- Data for Name: billing_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.billing_periods (id, therapist_id, patient_id, billing_cycle, period_start_date, period_end_date, total_sessions, billable_sessions, total_amount, invoice_generated, invoice_sent, invoice_paid, invoice_date, payment_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calendar_events (id, event_type, google_event_id, session_date, email, date) FROM stdin;
\.


--
-- Data for Name: calendar_webhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calendar_webhooks (id, channel_id, resource_id, expiration, created_at) FROM stdin;
\.


--
-- Data for Name: check_ins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.check_ins (id, patient_id, session_id, session_date, created_by, date, status) FROM stdin;
\.


--
-- Data for Name: imported_calendar_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imported_calendar_events (id, therapist_id, google_event_id, original_summary, description, start_time, end_time, attendees_emails, is_therapy_session, is_recurring, recurring_rule, linked_patient_id, matched_patient_name, processed, import_batch_id, created_at, processed_at) FROM stdin;
\.


--
-- Data for Name: monthly_billing_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monthly_billing_payments (id, billing_period_id, therapist_id, patient_id, amount, payment_method, payment_date, reference_number, recorded_by, notes, created_at, updated_at) FROM stdin;
3	6	1	1	44400.00	pix	2025-07-21 00:00:00+00	Opcional	dnkupfer@gmail.com	\N	2025-07-21 17:11:49.393455+00	2025-07-21 17:11:49.393455+00
\.


--
-- Data for Name: monthly_billing_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monthly_billing_periods (id, therapist_id, patient_id, billing_year, billing_month, session_count, total_amount, session_snapshots, processed_at, processed_by, status, can_be_voided, created_at, voided_at, voided_by, void_reason) FROM stdin;
6	1	1	2025	5	4	44400.00	[{"date": "2025-05-05", "time": "09:00", "duration": 60, "patientName": "Maria Santos", "googleEventId": "be525nb938vi65fnfq30oa53ro"}, {"date": "2025-05-12", "time": "09:00", "duration": 60, "patientName": "Maria Santos", "googleEventId": "46ltqavit5frr24ujpeql0ki60"}, {"date": "2025-05-19", "time": "09:00", "duration": 60, "patientName": "Maria Santos", "googleEventId": "u9ur8n0cllq3kfnis3p4nrirf8"}, {"date": "2025-05-26", "time": "09:00", "duration": 60, "patientName": "Maria Santos", "googleEventId": "c0tvh7io6v5t1s39qoioqkg2bo"}]	2025-07-21 17:09:39.350715+00	dnkupfer@gmail.com	paid	f	2025-07-21 17:09:39.350715+00	\N	\N	\N
\.


--
-- Data for Name: patient_billing_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_billing_history (id, patient_id, therapist_id, billing_cycle, session_price, effective_from_date, effective_until_date, reason_for_change, created_by, created_at, notes) FROM stdin;
\.


--
-- Data for Name: patient_matching_candidates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_matching_candidates (id, therapist_id, import_batch_id, extracted_name, name_variations, email_addresses, event_count, first_session_date, latest_session_date, suggested_therapy_start_date, suggested_billing_start_date, confidence_score, manual_review_needed, created_patient_id, created_at) FROM stdin;
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patients (id, nome, email, telefone, cpf, nota, preco, therapist_id, therapy_start_date, lv_notas_billing_start_date, session_price, recurring_pattern, notes, created_at) FROM stdin;
1	Maria Santos	maria.santos@hotmail.com	1234567890	123.456.789-09	f	11100.00	1	1976-12-05	2025-02-01	\N	\N	\N	2025-07-20 10:53:53.221996+00
8	sara citron	sarinhacitron@hotmail.com	11999397168	\N	f	45000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-24 13:52:41.948905+00
4	Carlos Alberto de Mattos Scaramuzza	cscaramuzza@gmail.com	11995081003	\N	f	35000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-22 18:51:58.433271+00
6	Fabio Bezerra	fabio@mfvchapas.com.br	996494187	\N	f	40000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-23 14:06:08.470337+00
7	Gabriela Schiavoni	valschiavoni@gmail.com	41995858885	\N	f	40000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-23 22:07:19.535285+00
5	Carol Wigman	carolinawigman@gmail.com	11966407792	\N	f	30000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-22 18:58:31.534689+00
9	Alexandre Pellaes	alexandrepellaes@exboss.com.br	11966501919	\N	f	33000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-25 18:01:10.241629+00
10	Aline de Melo Alves	alinedmeloalves@gmail.com	11976135115	\N	f	20000.00	2	\N	2023-07-01	\N	\N	\N	2025-07-25 18:05:31.030976+00
11	Andrea Quijo	andrea@espacopartager.com.br	11998114443	\N	f	25000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-25 18:14:49.035511+00
12	Carol Blois	carolblois@gmail.com	11973057399	\N	f	22000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-28 12:03:54.98439+00
13	Carolina Gubeissi	carolgubeissi@gmail.com	11973798004	\N	f	27000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-28 17:05:37.768097+00
14	catarina sarcedo	catarinasarcedo@gmail.com	11991826036	\N	f	27000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-28 17:11:00.186143+00
15	Cristiane Palmeira	crispalmeira@uol.com.br	11996005857	\N	f	30000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-28 17:15:25.040329+00
16	Daniele Curvacho	daniellecurvacho@gmail.com	21976808862	\N	f	20000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-28 17:21:34.786444+00
17	Danilo Ide	idedaniloide@gmail.com	11991267299	\N	f	35000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-28 20:52:02.222186+00
18	Diego Andrade H	francinivenanciodeoliveira@gmail.com	11998345678	\N	f	20000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-29 16:47:23.736238+00
19	Diego de Andrade B	dias@usp.br	11976721608	\N	f	20000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-29 16:53:49.51826+00
20	Guilherme Braga	carina.braga@gmail.com	11999826766	\N	f	40000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-29 20:19:44.547846+00
21	Fernando Martinez	mauro.martinez@safra.com.br	11996754173	\N	f	35000.00	2	\N	2025-07-01	\N	\N	\N	2025-07-29 20:43:09.064804+00
\.


--
-- Data for Name: payment_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_requests (id, patient_id, therapist_id, session_ids, total_amount, request_date, request_type, whatsapp_sent, whatsapp_message, response_received, response_date, created_at) FROM stdin;
\.


--
-- Data for Name: payment_status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_status_history (id, session_id, old_status, new_status, changed_by, changed_at, reason, payment_transaction_id) FROM stdin;
\.


--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_transactions (id, session_id, patient_id, therapist_id, amount, payment_method, payment_date, reference_number, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: practice_invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.practice_invitations (id, therapist_id, invited_by, invited_email, invited_role, invitation_token, personal_message, permissions_description, status, created_at, expires_at, responded_at, accepted_by, decline_reason) FROM stdin;
\.


--
-- Data for Name: recurring_session_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurring_session_templates (id, therapist_id, patient_id, day_of_week, start_time, duration_minutes, frequency, effective_from, effective_until, status, created_from_import, import_batch_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session_activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session_activity_log (id, session_id, user_id, activity_type, endpoint, ip_address, user_agent, "timestamp", metadata) FROM stdin;
1	1	1	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 15:18:42.82241+00	{}
2	1	\N	logout	\N	\N	\N	2025-07-27 15:18:55.540259+00	{"reason": "logout", "terminated_at": "2025-07-27T15:18:55.540Z"}
3	2	2	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 15:19:28.501008+00	{}
4	3	2	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 15:19:51.523934+00	{}
5	4	2	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 15:20:11.277552+00	{}
6	5	2	login	\N	2a00:23c8:16b2:8301:e958:b3cd:6a2a:1be6	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-07-27 15:21:49.064441+00	{}
7	5	\N	logout	\N	\N	\N	2025-07-27 15:24:28.932543+00	{"reason": "logout", "terminated_at": "2025-07-27T15:24:28.932Z"}
8	6	1	login	\N	2a00:23c8:16b2:8301:e958:b3cd:6a2a:1be6	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-07-27 15:24:45.598371+00	{}
9	7	1	login	\N	2a00:23ee:2158:2f4b:90b0:fe36:6956:8609	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-07-27 18:07:00.194348+00	{}
10	8	1	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 18:32:13.579041+00	{}
11	9	1	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 19:03:27.226058+00	{}
12	10	1	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 19:22:39.213636+00	{}
13	11	1	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 19:39:32.428705+00	{}
14	12	1	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 21:35:08.129194+00	{}
15	13	1	login	\N	2a00:23c8:16b2:8301:7c4e:e78d:7a36:3b0	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-07-27 22:23:55.929091+00	{}
16	13	\N	logout	\N	\N	\N	2025-07-27 22:24:58.083273+00	{"reason": "logout", "terminated_at": "2025-07-27T22:24:58.083Z"}
17	14	1	login	\N	2a00:23c8:16b2:8301:7c4e:e78d:7a36:3b0	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-07-27 22:25:04.280771+00	{}
18	15	1	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-28 08:23:03.711005+00	{}
19	15	\N	logout	\N	\N	\N	2025-07-28 08:33:00.678907+00	{"reason": "logout", "terminated_at": "2025-07-28T08:33:00.679Z"}
20	16	2	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-28 08:33:04.805784+00	{}
21	16	\N	logout	\N	\N	\N	2025-07-28 08:33:18.135415+00	{"reason": "logout", "terminated_at": "2025-07-28T08:33:18.135Z"}
22	17	2	login	\N	2804:214:8135:fed:f904:a592:7e44:e8d5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	2025-07-28 11:53:00.274347+00	{}
23	18	2	login	\N	2804:1b3:a880:fd59:588a:27d0:9d91:1d44	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	2025-07-28 17:00:11.65336+00	{}
24	19	2	login	\N	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-28 18:52:40.81389+00	{}
25	20	2	login	\N	2804:1b3:a880:fd59:ec4c:9d8:62f:9ad5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	2025-07-28 20:06:25.621112+00	{}
26	21	1	login	\N	2a00:23c8:16b2:8301:390b:4aa8:7a6:cb1f	Mozilla/5.0 (iPad; CPU OS 18_3_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-07-28 20:28:04.230228+00	{}
27	22	2	login	\N	2804:1b3:a880:fd59:ec4c:9d8:62f:9ad5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	2025-07-28 20:49:02.953343+00	{}
28	23	2	login	\N	2804:1b3:a880:fd59:39cc:faf5:79be:1374	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	2025-07-29 16:41:52.437424+00	{}
29	24	2	login	\N	2804:1b3:a880:fd59:39cc:faf5:79be:1374	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	2025-07-29 20:16:43.252604+00	{}
30	25	2	login	\N	2a00:23c8:16b2:8301:c951:ec49:3f3:284	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 20:50:38.122866+00	{}
31	26	2	login	\N	2a00:23c8:16b2:8301:c951:ec49:3f3:284	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 10:53:42.676673+00	{}
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, date, google_calendar_event_id, patient_id, therapist_id, status, billable, billing_period, session_price, billing_cycle_used, created_during_onboarding, import_batch_id, payment_requested, payment_request_date, payment_status, paid_date, billing_period_id, created_at) FROM stdin;
\.


--
-- Data for Name: therapist_billing_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.therapist_billing_history (id, therapist_id, billing_cycle, default_session_price, effective_from_date, effective_until_date, reason_for_change, created_by, created_at, notes) FROM stdin;
\.


--
-- Data for Name: therapist_onboarding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.therapist_onboarding (id, therapist_id, step, completed_at, data, notes) FROM stdin;
\.


--
-- Data for Name: therapist_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.therapist_settings (id, therapist_id, setting_key, setting_value, created_at, updated_at) FROM stdin;
1	1	payment_mode	simple	2025-07-21 20:52:31.527833+00	2025-07-21 20:52:31.527833+00
2	1	view_mode	list	2025-07-21 20:52:31.536236+00	2025-07-21 20:52:31.536236+00
3	1	auto_check_in_mode	false	2025-07-21 20:52:31.53993+00	2025-07-21 20:52:31.53993+00
\.


--
-- Data for Name: therapists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.therapists (id, nome, email, telefone, google_calendar_id, billing_cycle, default_session_price, onboarding_completed, onboarding_started_at, onboarding_completed_at, created_at) FROM stdin;
2	Cristina Kupfer	mcmkupfer@gmail.com	\N	mcmkupfer@gmail.com	monthly	\N	f	\N	\N	2025-07-21 13:24:01.28545+00
1	Daniel Kupfer	dnkupfer@gmail.com	\N	6f3842a5e7b8b63095e840cc28684fd52e17ff25ef173e49b2e5219ed676f652@group.calendar.google.com	monthly	\N	f	\N	\N	2025-07-20 10:53:04.540266+00
\.


--
-- Data for Name: user_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_credentials (id, email, password_hash, display_name, google_permissions_granted, google_access_token, google_refresh_token, google_token_expires_at, google_permissions_granted_at, is_active, email_verified, email_verification_token, email_verified_at, password_reset_token, password_reset_expires_at, created_at, updated_at, last_login_at) FROM stdin;
3	dan@kupfer.co	temp_1753615744.050920_0.45714460249064004	Dan Kupfer (Super Admin)	f	\N	\N	\N	\N	t	t	\N	\N	\N	\N	2025-07-27 11:29:04.05092+00	2025-07-27 11:29:04.05092+00	\N
1	dnkupfer@gmail.com	$2b$12$y4W/qzMWqIiiBDLxK.K7n.D7Nic3rIZKzdEdOrQMU/hX69R39zWRS	Daniel Kupfer	f	\N	\N	\N	\N	t	t	\N	\N	\N	\N	2025-07-27 11:29:03.80144+00	2025-07-28 20:28:04.234809+00	2025-07-28 20:28:04.234809+00
4	amkupfer@gmail.com	$2b$12$ZOR1zaULVjkaYHC81qC/SO88Oy2V0xf03p6HNg.1Xv2lJNmO2HkM2	Andre Kupfer	f	\N	\N	\N	\N	t	f	d990474a8dd545224d24575f25701508300f932fba6b24a39f5f2c2afcd65019	\N	\N	\N	2025-07-29 21:19:52.415028+00	2025-07-29 21:19:52.415028+00	\N
2	mcmkupfer@gmail.com	$2b$12$5wyPxhMsXFZ3G63RfYmeA.2Z9cWAOKwuebYDANTxf0ECpJgih2CQi	Cristina Kupfer	f	\N	\N	\N	\N	t	t	\N	\N	\N	\N	2025-07-27 11:29:03.80144+00	2025-07-30 10:53:42.680531+00	2025-07-30 10:53:42.680531+00
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_permissions (id, user_id, therapist_id, role, granted_by, granted_at, expires_at, is_active, notes) FROM stdin;
1	1	1	owner	1	2025-07-27 11:29:03.80144+00	\N	t	Migrated from existing therapist account
2	2	2	owner	2	2025-07-27 11:29:03.80144+00	\N	t	Migrated from existing therapist account
3	3	1	super_admin	3	2025-07-27 11:29:04.05092+00	\N	t	Initial super admin setup for system owner
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, session_token, inactive_timeout_minutes, warning_timeout_minutes, max_session_hours, created_at, last_activity_at, expires_at, status, terminated_at, termination_reason, ip_address, user_agent, device_fingerprint) FROM stdin;
26	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MjYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzODcyODIyLCJleHAiOjE3NTM4NzY0MjJ9.X9gIgujJbP4RddkTJcVoD1j-eScMNfgyKLQDbDr5y0A	30	2	8	2025-07-30 10:53:42.665274+00	2025-07-30 10:53:42.665274+00	2025-07-30 18:53:42.664+00	active	\N	\N	2a00:23c8:16b2:8301:c951:ec49:3f3:284	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
1	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MSwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2Mjk1MjIsImV4cCI6MTc1MzYzMzEyMn0.-iVwIn2YP4dCKHXd8gA5v8Vi8aL0FKMJsX0stF2uDgo	30	2	8	2025-07-27 15:18:42.811723+00	2025-07-27 15:18:46.028803+00	2025-07-27 23:18:42.812+00	terminated	2025-07-27 15:18:55.537471+00	logout	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
9	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6OSwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2NDMwMDcsImV4cCI6MTc1MzY0NjYwN30.o5WvlQhwYzEDc7XDUxrpcreKcLlz6tR1VgDue8P6sn8	30	2	8	2025-07-27 19:03:27.210355+00	2025-07-27 19:05:04.869136+00	2025-07-28 03:03:27.21+00	expired	2025-07-27 19:37:39.000288+00	automatic_expiry	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
10	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MTAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNjQ0MTU5LCJleHAiOjE3NTM2NDc3NTl9.GT6LGDlBpDV2ewJVvxugjdOqGhVXmPlXlNx6U83rM80	30	2	8	2025-07-27 19:22:39.205311+00	2025-07-27 19:39:09.103199+00	2025-07-28 03:22:39.205+00	expired	2025-07-27 21:35:16.170199+00	automatic_expiry	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
11	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MTEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNjQ1MTcyLCJleHAiOjE3NTM2NDg3NzJ9.xe9HbPtor1pybnH-FeoGoA8uW30MwEhp5CtnbAWIzJ8	30	2	8	2025-07-27 19:39:32.418429+00	2025-07-27 19:39:32.418429+00	2025-07-28 03:39:32.419+00	expired	2025-07-27 21:35:16.170199+00	automatic_expiry	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
8	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6OCwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2NDExMzMsImV4cCI6MTc1MzY0NDczM30.cDsTcog7Gwx86cArKNxagnvqg0DSQHgBcQ3pMR9c6xk	30	2	8	2025-07-27 18:32:13.567928+00	2025-07-27 19:22:26.83806+00	2025-07-28 02:32:13.567+00	expired	2025-07-27 21:35:16.170199+00	automatic_expiry	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
5	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6NSwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2Mjk3MDksImV4cCI6MTc1MzYzMzMwOX0.2D8WEHO7Qa-61fERDu11jky6RtVdvESMUAOF5Y2svNk	30	2	8	2025-07-27 15:21:49.056651+00	2025-07-27 15:24:27.484177+00	2025-07-27 23:21:49.056+00	terminated	2025-07-27 15:24:28.929766+00	logout	2a00:23c8:16b2:8301:e958:b3cd:6a2a:1be6	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	\N
4	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6NCwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2Mjk2MTEsImV4cCI6MTc1MzYzMzIxMX0.UPtMHGWktVtQLEdLVWB2TC7ovw32JD_mtTUvyFcyDhE	30	2	8	2025-07-27 15:20:11.269287+00	2025-07-27 15:22:54.473752+00	2025-07-27 23:20:11.269+00	expired	2025-07-27 16:15:47.262475+00	inactivity_timeout	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
2	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MiwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2Mjk1NjgsImV4cCI6MTc1MzYzMzE2OH0.-y9zA682aQUMiDFJRjnHJc8JwRby_T5vVi9S31RWoR0	30	2	8	2025-07-27 15:19:28.492886+00	2025-07-27 15:19:47.454454+00	2025-07-27 23:19:28.493+00	expired	2025-07-27 18:07:09.48649+00	automatic_expiry	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
3	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MywidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2Mjk1OTEsImV4cCI6MTc1MzYzMzE5MX0.mmJfZC0D-AMZMeIKbXUvmJuXpqHvE5-dbgbuDwS-OOk	30	2	8	2025-07-27 15:19:51.517377+00	2025-07-27 15:20:03.865491+00	2025-07-27 23:19:51.517+00	expired	2025-07-27 18:07:09.48649+00	automatic_expiry	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
6	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6NiwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2Mjk4ODUsImV4cCI6MTc1MzYzMzQ4NX0.8NyNti6ourdkbf05ZKVF5RTqxDNmoYTMpN5MKEEb3dI	30	2	8	2025-07-27 15:24:45.591082+00	2025-07-27 15:24:46.193609+00	2025-07-27 23:24:45.59+00	expired	2025-07-27 18:07:09.48649+00	automatic_expiry	2a00:23c8:16b2:8301:e958:b3cd:6a2a:1be6	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	\N
7	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6NywidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM2Mzk2MjAsImV4cCI6MTc1MzY0MzIyMH0.I1qAdjoy2_eoCkjy-1z_Cm7yTQkFV2VGOkhrGuChQSQ	30	2	8	2025-07-27 18:07:00.14914+00	2025-07-27 18:07:00.14914+00	2025-07-28 02:07:00.147+00	expired	2025-07-27 18:38:22.999082+00	automatic_expiry	2a00:23ee:2158:2f4b:90b0:fe36:6956:8609	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	\N
13	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MTMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNjU1MDM1LCJleHAiOjE3NTM2NTg2MzV9.OM55h1e29DOa1pXvNbOmoXPeqoeNgP1xoXnXZMHMkf8	30	2	8	2025-07-27 22:23:55.916009+00	2025-07-27 22:24:56.883531+00	2025-07-28 06:23:55.915+00	terminated	2025-07-27 22:24:58.080092+00	logout	2a00:23c8:16b2:8301:7c4e:e78d:7a36:3b0	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	\N
12	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MTIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNjUyMTA4LCJleHAiOjE3NTM2NTU3MDh9.Sit0sLf9Z9z0QMToIAD-lC_NiwZnwCcmGtnaainvFqo	30	2	8	2025-07-27 21:35:08.116381+00	2025-07-27 21:56:08.055871+00	2025-07-28 05:35:08.115+00	expired	2025-07-28 08:23:12.383683+00	automatic_expiry	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
14	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MTQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNjU1MTA0LCJleHAiOjE3NTM2NTg3MDR9.Uta2XgLCYxrniwjif1DkvraXrGZu3gzazkoGYvHk4Y0	30	2	8	2025-07-27 22:25:04.272191+00	2025-07-27 22:25:04.272191+00	2025-07-28 06:25:04.272+00	expired	2025-07-28 08:23:12.383683+00	automatic_expiry	2a00:23c8:16b2:8301:7c4e:e78d:7a36:3b0	Mozilla/5.0 (iPhone; CPU iPhone OS 18_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	\N
15	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MTUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNjkwOTgzLCJleHAiOjE3NTM2OTQ1ODN9.9AS-TWAKo85WKyyzquB1eMDmKO9mhO2ll8poi-4fLWs	30	2	8	2025-07-28 08:23:03.699119+00	2025-07-28 08:32:59.880748+00	2025-07-28 16:23:03.698+00	terminated	2025-07-28 08:33:00.675546+00	logout	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
16	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNjkxNTg0LCJleHAiOjE3NTM2OTUxODR9.UhQtfcElXW0j2C0h6QtRyZlWR7rPWi3xhZA1stujP9E	30	2	8	2025-07-28 08:33:04.796959+00	2025-07-28 08:33:11.493022+00	2025-07-28 16:33:04.797+00	terminated	2025-07-28 08:33:18.130397+00	logout	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
25	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MjUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzODIyMjM4LCJleHAiOjE3NTM4MjU4Mzh9.6v0o6CR6OoA87i2ahkbCywIOL7F_v1z0sI2FATiHKCs	30	2	8	2025-07-29 20:50:38.112126+00	2025-07-29 21:03:16.064969+00	2025-07-30 04:50:38.111+00	expired	2025-07-30 10:53:49.043369+00	automatic_expiry	2a00:23c8:16b2:8301:c951:ec49:3f3:284	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
17	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNzAzNTgwLCJleHAiOjE3NTM3MDcxODB9.gauGif2-O38fXhfe5tndesALA1FXlMOdMNGuEFVUWlw	30	2	8	2025-07-28 11:53:00.259802+00	2025-07-28 12:06:16.910965+00	2025-07-28 19:53:00.259+00	expired	2025-07-28 12:39:17.732684+00	inactivity_timeout	2804:214:8135:fed:f904:a592:7e44:e8d5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	\N
18	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNzIyMDExLCJleHAiOjE3NTM3MjU2MTF9.u1v7QLayKG4B1WRpTZM_Up9_KxuHYRnDvZxpM6cJw3U	30	2	8	2025-07-28 17:00:11.636014+00	2025-07-28 17:00:11.636014+00	2025-07-29 01:00:11.635+00	expired	2025-07-28 17:33:58.29368+00	inactivity_timeout	2804:1b3:a880:fd59:588a:27d0:9d91:1d44	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	\N
19	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNzI4NzYwLCJleHAiOjE3NTM3MzIzNjB9.kDTWmsXrbJIR4VmVPeMJjw7buEwAgLS08lbyOhlxrBA	30	2	8	2025-07-28 18:52:40.799194+00	2025-07-28 18:59:18.622517+00	2025-07-29 02:52:40.798+00	expired	2025-07-28 19:48:50.911595+00	inactivity_timeout	2a00:23c8:16b2:8301:51e6:2557:2530:4e6c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
20	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MjAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNzMzMTg1LCJleHAiOjE3NTM3MzY3ODV9.6-N2LIrNlnLLJm3ptSnpzTUoA7RN6Wxils1mD1DYkGg	30	2	8	2025-07-28 20:06:25.605347+00	2025-07-28 20:06:25.605347+00	2025-07-29 04:06:25.605+00	expired	2025-07-28 20:36:31.219122+00	inactivity_timeout	2804:1b3:a880:fd59:ec4c:9d8:62f:9ad5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	\N
22	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MjIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNzM1NzQyLCJleHAiOjE3NTM3MzkzNDJ9.EF39_NbCxRnK2EBJrTLDR0n5rVaqPBCw8K8RTsMn_3I	30	2	8	2025-07-28 20:49:02.940531+00	2025-07-28 20:49:02.940531+00	2025-07-29 04:49:02.94+00	expired	2025-07-28 21:19:03.803319+00	inactivity_timeout	2804:1b3:a880:fd59:ec4c:9d8:62f:9ad5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	\N
21	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInNlc3Npb25JZCI6MjEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNzM0NDg0LCJleHAiOjE3NTM3MzgwODR9.O7jpnx-KmGUX5nsZm8xjMO--2mJpyRZjz_Ki9-VFNSA	30	2	8	2025-07-28 20:28:04.210833+00	2025-07-28 20:30:04.547322+00	2025-07-29 04:28:04.21+00	expired	2025-07-28 21:19:10.393812+00	inactivity_timeout	2a00:23c8:16b2:8301:390b:4aa8:7a6:cb1f	Mozilla/5.0 (iPad; CPU OS 18_3_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	\N
23	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MjMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzODA3MzEyLCJleHAiOjE3NTM4MTA5MTJ9.OkVenvB1hnQgg1Ft2MYBxn-Jvl92xyd0p-TGuVFizRY	30	2	8	2025-07-29 16:41:52.421873+00	2025-07-29 16:41:52.421873+00	2025-07-30 00:41:52.422+00	expired	2025-07-29 20:18:01.778251+00	automatic_expiry	2804:1b3:a880:fd59:39cc:faf5:79be:1374	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	\N
24	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MjQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzODIwMjAzLCJleHAiOjE3NTM4MjM4MDN9.UuCWV_dgBs5qq_GIAI8YJf4marhu38TPmUrH1oxZLLM	30	2	8	2025-07-29 20:16:43.235564+00	2025-07-29 20:16:43.235564+00	2025-07-30 04:16:43.234+00	expired	2025-07-29 20:46:49.454437+00	inactivity_timeout	2804:1b3:a880:fd59:39cc:faf5:79be:1374	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	\N
\.


--
-- Name: app_configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.app_configuration_id_seq', 15, true);


--
-- Name: billing_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.billing_periods_id_seq', 1, false);


--
-- Name: calendar_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calendar_events_id_seq', 1, false);


--
-- Name: calendar_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calendar_webhooks_id_seq', 1, false);


--
-- Name: check_ins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.check_ins_id_seq', 1, false);


--
-- Name: imported_calendar_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.imported_calendar_events_id_seq', 1, false);


--
-- Name: monthly_billing_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monthly_billing_payments_id_seq', 5, true);


--
-- Name: monthly_billing_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monthly_billing_periods_id_seq', 21, true);


--
-- Name: patient_billing_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patient_billing_history_id_seq', 1, false);


--
-- Name: patient_matching_candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patient_matching_candidates_id_seq', 1, false);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patients_id_seq', 21, true);


--
-- Name: payment_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_requests_id_seq', 1, false);


--
-- Name: payment_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_status_history_id_seq', 1, false);


--
-- Name: payment_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_transactions_id_seq', 1, false);


--
-- Name: practice_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.practice_invitations_id_seq', 1, false);


--
-- Name: recurring_session_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recurring_session_templates_id_seq', 1, false);


--
-- Name: session_activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.session_activity_log_id_seq', 31, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- Name: therapist_billing_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.therapist_billing_history_id_seq', 1, false);


--
-- Name: therapist_onboarding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.therapist_onboarding_id_seq', 1, false);


--
-- Name: therapist_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.therapist_settings_id_seq', 3, true);


--
-- Name: therapists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.therapists_id_seq', 2, true);


--
-- Name: user_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_credentials_id_seq', 4, true);


--
-- Name: user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_permissions_id_seq', 3, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 26, true);


--
-- Name: app_configuration app_configuration_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_configuration
    ADD CONSTRAINT app_configuration_key_key UNIQUE (key);


--
-- Name: app_configuration app_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_configuration
    ADD CONSTRAINT app_configuration_pkey PRIMARY KEY (id);


--
-- Name: billing_periods billing_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_pkey PRIMARY KEY (id);


--
-- Name: billing_periods billing_periods_therapist_id_patient_id_period_start_date_p_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_therapist_id_patient_id_period_start_date_p_key UNIQUE (therapist_id, patient_id, period_start_date, period_end_date);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: calendar_webhooks calendar_webhooks_channel_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_webhooks
    ADD CONSTRAINT calendar_webhooks_channel_id_key UNIQUE (channel_id);


--
-- Name: calendar_webhooks calendar_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_webhooks
    ADD CONSTRAINT calendar_webhooks_pkey PRIMARY KEY (id);


--
-- Name: check_ins check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_pkey PRIMARY KEY (id);


--
-- Name: imported_calendar_events imported_calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_calendar_events
    ADD CONSTRAINT imported_calendar_events_pkey PRIMARY KEY (id);


--
-- Name: monthly_billing_payments monthly_billing_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_pkey PRIMARY KEY (id);


--
-- Name: monthly_billing_periods monthly_billing_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_pkey PRIMARY KEY (id);


--
-- Name: monthly_billing_periods monthly_billing_periods_therapist_id_patient_id_billing_yea_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_therapist_id_patient_id_billing_yea_key UNIQUE (therapist_id, patient_id, billing_year, billing_month);


--
-- Name: patient_billing_history patient_billing_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_billing_history
    ADD CONSTRAINT patient_billing_history_pkey PRIMARY KEY (id);


--
-- Name: patient_matching_candidates patient_matching_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_matching_candidates
    ADD CONSTRAINT patient_matching_candidates_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payment_requests payment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_pkey PRIMARY KEY (id);


--
-- Name: payment_status_history payment_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: practice_invitations practice_invitations_invitation_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_invitation_token_key UNIQUE (invitation_token);


--
-- Name: practice_invitations practice_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_pkey PRIMARY KEY (id);


--
-- Name: recurring_session_templates recurring_session_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_session_templates
    ADD CONSTRAINT recurring_session_templates_pkey PRIMARY KEY (id);


--
-- Name: session_activity_log session_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activity_log
    ADD CONSTRAINT session_activity_log_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: therapist_billing_history therapist_billing_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_billing_history
    ADD CONSTRAINT therapist_billing_history_pkey PRIMARY KEY (id);


--
-- Name: therapist_onboarding therapist_onboarding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_onboarding
    ADD CONSTRAINT therapist_onboarding_pkey PRIMARY KEY (id);


--
-- Name: therapist_onboarding therapist_onboarding_therapist_id_step_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_onboarding
    ADD CONSTRAINT therapist_onboarding_therapist_id_step_key UNIQUE (therapist_id, step);


--
-- Name: therapist_settings therapist_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_settings
    ADD CONSTRAINT therapist_settings_pkey PRIMARY KEY (id);


--
-- Name: therapist_settings therapist_settings_therapist_id_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_settings
    ADD CONSTRAINT therapist_settings_therapist_id_setting_key_key UNIQUE (therapist_id, setting_key);


--
-- Name: therapists therapists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapists
    ADD CONSTRAINT therapists_pkey PRIMARY KEY (id);


--
-- Name: user_credentials user_credentials_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_email_key UNIQUE (email);


--
-- Name: user_credentials user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_user_id_therapist_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_therapist_id_key UNIQUE (user_id, therapist_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_key UNIQUE (session_token);


--
-- Name: idx_app_configuration_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_configuration_key ON public.app_configuration USING btree (key);


--
-- Name: idx_billing_periods_patient_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_billing_periods_patient_dates ON public.billing_periods USING btree (patient_id, period_start_date, period_end_date);


--
-- Name: idx_billing_periods_therapist_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_billing_periods_therapist_dates ON public.billing_periods USING btree (therapist_id, period_start_date, period_end_date);


--
-- Name: idx_imported_events_google_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_imported_events_google_id ON public.imported_calendar_events USING btree (google_event_id);


--
-- Name: idx_imported_events_therapist_batch; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_imported_events_therapist_batch ON public.imported_calendar_events USING btree (therapist_id, import_batch_id);


--
-- Name: idx_imported_events_therapy_sessions; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_imported_events_therapy_sessions ON public.imported_calendar_events USING btree (therapist_id, is_therapy_session);


--
-- Name: idx_matching_candidates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_matching_candidates_name ON public.patient_matching_candidates USING btree (extracted_name);


--
-- Name: idx_matching_candidates_therapist_batch; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_matching_candidates_therapist_batch ON public.patient_matching_candidates USING btree (therapist_id, import_batch_id);


--
-- Name: idx_monthly_billing_payments_billing_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_billing_payments_billing_period ON public.monthly_billing_payments USING btree (billing_period_id);


--
-- Name: idx_monthly_billing_payments_payment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_billing_payments_payment_date ON public.monthly_billing_payments USING btree (payment_date);


--
-- Name: idx_monthly_billing_payments_therapist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_billing_payments_therapist ON public.monthly_billing_payments USING btree (therapist_id);


--
-- Name: idx_monthly_billing_periods_month; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_billing_periods_month ON public.monthly_billing_periods USING btree (billing_year, billing_month);


--
-- Name: idx_monthly_billing_periods_patient; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_billing_periods_patient ON public.monthly_billing_periods USING btree (patient_id);


--
-- Name: idx_monthly_billing_periods_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_billing_periods_status ON public.monthly_billing_periods USING btree (therapist_id, status);


--
-- Name: idx_monthly_billing_periods_therapist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_billing_periods_therapist ON public.monthly_billing_periods USING btree (therapist_id);


--
-- Name: idx_patient_billing_history_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_billing_history_dates ON public.patient_billing_history USING btree (patient_id, effective_from_date, effective_until_date);


--
-- Name: idx_patients_cpf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_patients_cpf ON public.patients USING btree (cpf) WHERE (cpf IS NOT NULL);


--
-- Name: idx_patients_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patients_email ON public.patients USING btree (email);


--
-- Name: idx_patients_therapist_billing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patients_therapist_billing ON public.patients USING btree (therapist_id, lv_notas_billing_start_date);


--
-- Name: idx_patients_therapist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patients_therapist_id ON public.patients USING btree (therapist_id);


--
-- Name: idx_payment_requests_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_requests_patient_id ON public.payment_requests USING btree (patient_id);


--
-- Name: idx_payment_requests_request_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_requests_request_date ON public.payment_requests USING btree (request_date);


--
-- Name: idx_payment_requests_therapist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_requests_therapist_id ON public.payment_requests USING btree (therapist_id);


--
-- Name: idx_payment_status_history_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_status_history_session_id ON public.payment_status_history USING btree (session_id);


--
-- Name: idx_payment_transactions_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_transactions_patient_id ON public.payment_transactions USING btree (patient_id);


--
-- Name: idx_payment_transactions_payment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_transactions_payment_date ON public.payment_transactions USING btree (payment_date);


--
-- Name: idx_payment_transactions_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_transactions_session_id ON public.payment_transactions USING btree (session_id);


--
-- Name: idx_payment_transactions_therapist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_transactions_therapist_id ON public.payment_transactions USING btree (therapist_id);


--
-- Name: idx_practice_invitations_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_practice_invitations_email ON public.practice_invitations USING btree (invited_email);


--
-- Name: idx_practice_invitations_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_practice_invitations_status ON public.practice_invitations USING btree (status, expires_at);


--
-- Name: idx_practice_invitations_therapist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_practice_invitations_therapist ON public.practice_invitations USING btree (therapist_id);


--
-- Name: idx_practice_invitations_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_practice_invitations_token ON public.practice_invitations USING btree (invitation_token);


--
-- Name: idx_recurring_templates_schedule; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurring_templates_schedule ON public.recurring_session_templates USING btree (day_of_week, start_time);


--
-- Name: idx_recurring_templates_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurring_templates_status ON public.recurring_session_templates USING btree (therapist_id, status);


--
-- Name: idx_recurring_templates_therapist_patient; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurring_templates_therapist_patient ON public.recurring_session_templates USING btree (therapist_id, patient_id);


--
-- Name: idx_session_activity_log_activity_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_activity_log_activity_type ON public.session_activity_log USING btree (activity_type);


--
-- Name: idx_session_activity_log_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_activity_log_session ON public.session_activity_log USING btree (session_id);


--
-- Name: idx_session_activity_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_activity_log_timestamp ON public.session_activity_log USING btree ("timestamp");


--
-- Name: idx_session_activity_log_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_activity_log_user ON public.session_activity_log USING btree (user_id);


--
-- Name: idx_sessions_billable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_billable ON public.sessions USING btree (therapist_id, billable, date);


--
-- Name: idx_sessions_billing_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_billing_period ON public.sessions USING btree (therapist_id, billing_period);


--
-- Name: idx_sessions_billing_period_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_billing_period_id ON public.sessions USING btree (billing_period_id);


--
-- Name: idx_sessions_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_patient_id ON public.sessions USING btree (patient_id);


--
-- Name: idx_sessions_payment_requested; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_payment_requested ON public.sessions USING btree (therapist_id, payment_requested, payment_request_date);


--
-- Name: idx_sessions_payment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_payment_status ON public.sessions USING btree (therapist_id, payment_status);


--
-- Name: idx_sessions_therapist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_therapist_id ON public.sessions USING btree (therapist_id);


--
-- Name: idx_therapist_billing_history_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_therapist_billing_history_dates ON public.therapist_billing_history USING btree (therapist_id, effective_from_date, effective_until_date);


--
-- Name: idx_therapist_settings_therapist_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_therapist_settings_therapist_key ON public.therapist_settings USING btree (therapist_id, setting_key);


--
-- Name: idx_therapists_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_therapists_email ON public.therapists USING btree (email);


--
-- Name: idx_user_credentials_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_credentials_active ON public.user_credentials USING btree (is_active);


--
-- Name: idx_user_credentials_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_credentials_email ON public.user_credentials USING btree (email);


--
-- Name: idx_user_credentials_password_reset; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_credentials_password_reset ON public.user_credentials USING btree (password_reset_token);


--
-- Name: idx_user_credentials_verification; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_credentials_verification ON public.user_credentials USING btree (email_verification_token);


--
-- Name: idx_user_permissions_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_permissions_active ON public.user_permissions USING btree (user_id, is_active);


--
-- Name: idx_user_permissions_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_permissions_role ON public.user_permissions USING btree (therapist_id, role, is_active);


--
-- Name: idx_user_permissions_therapist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_permissions_therapist_id ON public.user_permissions USING btree (therapist_id);


--
-- Name: idx_user_permissions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_permissions_user_id ON public.user_permissions USING btree (user_id);


--
-- Name: idx_user_sessions_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_active ON public.user_sessions USING btree (user_id, status);


--
-- Name: idx_user_sessions_activity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_activity ON public.user_sessions USING btree (last_activity_at);


--
-- Name: idx_user_sessions_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_expires ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_token ON public.user_sessions USING btree (session_token);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: monthly_billing_payments trigger_update_billing_status_on_payment_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_billing_status_on_payment_delete AFTER DELETE ON public.monthly_billing_payments FOR EACH ROW EXECUTE FUNCTION public.update_billing_period_status();


--
-- Name: monthly_billing_payments trigger_update_billing_status_on_payment_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_billing_status_on_payment_insert AFTER INSERT ON public.monthly_billing_payments FOR EACH ROW EXECUTE FUNCTION public.update_billing_period_status();


--
-- Name: user_credentials update_user_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_credentials_updated_at BEFORE UPDATE ON public.user_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: billing_periods billing_periods_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: billing_periods billing_periods_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: check_ins check_ins_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: check_ins check_ins_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: imported_calendar_events imported_calendar_events_linked_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_calendar_events
    ADD CONSTRAINT imported_calendar_events_linked_patient_id_fkey FOREIGN KEY (linked_patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: imported_calendar_events imported_calendar_events_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imported_calendar_events
    ADD CONSTRAINT imported_calendar_events_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_payments monthly_billing_payments_billing_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_billing_period_id_fkey FOREIGN KEY (billing_period_id) REFERENCES public.monthly_billing_periods(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_payments monthly_billing_payments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_payments monthly_billing_payments_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_periods monthly_billing_periods_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_periods monthly_billing_periods_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: patient_billing_history patient_billing_history_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_billing_history
    ADD CONSTRAINT patient_billing_history_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: patient_billing_history patient_billing_history_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_billing_history
    ADD CONSTRAINT patient_billing_history_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: patient_matching_candidates patient_matching_candidates_created_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_matching_candidates
    ADD CONSTRAINT patient_matching_candidates_created_patient_id_fkey FOREIGN KEY (created_patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: patient_matching_candidates patient_matching_candidates_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_matching_candidates
    ADD CONSTRAINT patient_matching_candidates_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: patients patients_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: payment_requests payment_requests_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: payment_requests payment_requests_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: payment_status_history payment_status_history_payment_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_payment_transaction_id_fkey FOREIGN KEY (payment_transaction_id) REFERENCES public.payment_transactions(id) ON DELETE SET NULL;


--
-- Name: payment_status_history payment_status_history_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: practice_invitations practice_invitations_accepted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_accepted_by_fkey FOREIGN KEY (accepted_by) REFERENCES public.user_credentials(id) ON DELETE SET NULL;


--
-- Name: practice_invitations practice_invitations_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- Name: practice_invitations practice_invitations_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: recurring_session_templates recurring_session_templates_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_session_templates
    ADD CONSTRAINT recurring_session_templates_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: recurring_session_templates recurring_session_templates_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_session_templates
    ADD CONSTRAINT recurring_session_templates_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: session_activity_log session_activity_log_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activity_log
    ADD CONSTRAINT session_activity_log_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.user_sessions(id) ON DELETE CASCADE;


--
-- Name: session_activity_log session_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_activity_log
    ADD CONSTRAINT session_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: therapist_billing_history therapist_billing_history_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_billing_history
    ADD CONSTRAINT therapist_billing_history_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: therapist_onboarding therapist_onboarding_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_onboarding
    ADD CONSTRAINT therapist_onboarding_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: therapist_settings therapist_settings_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.therapist_settings
    ADD CONSTRAINT therapist_settings_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.user_credentials(id) ON DELETE SET NULL;


--
-- Name: user_permissions user_permissions_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: cloudsqlsuperuser
--

REVOKE ALL ON SCHEMA public FROM cloudsqladmin;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO cloudsqlsuperuser;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

