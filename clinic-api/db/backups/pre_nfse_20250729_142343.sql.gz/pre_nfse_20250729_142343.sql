--
-- PostgreSQL database dump
--

-- Dumped from database version 14.15 (Homebrew)
-- Dumped by pg_dump version 14.15 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: event_type; Type: TYPE; Schema: public; Owner: dankupfer
--

CREATE TYPE public.event_type AS ENUM (
    'new',
    'update',
    'cancel'
);


ALTER TYPE public.event_type OWNER TO dankupfer;

--
-- Name: invitation_status; Type: TYPE; Schema: public; Owner: dankupfer
--

CREATE TYPE public.invitation_status AS ENUM (
    'pending',
    'accepted',
    'declined',
    'expired'
);


ALTER TYPE public.invitation_status OWNER TO dankupfer;

--
-- Name: session_status; Type: TYPE; Schema: public; Owner: dankupfer
--

CREATE TYPE public.session_status AS ENUM (
    'agendada',
    'compareceu',
    'cancelada'
);


ALTER TYPE public.session_status OWNER TO dankupfer;

--
-- Name: session_status_auth; Type: TYPE; Schema: public; Owner: dankupfer
--

CREATE TYPE public.session_status_auth AS ENUM (
    'active',
    'expired',
    'terminated'
);


ALTER TYPE public.session_status_auth OWNER TO dankupfer;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: dankupfer
--

CREATE TYPE public.user_role AS ENUM (
    'owner',
    'manager',
    'viewer',
    'super_admin'
);


ALTER TYPE public.user_role OWNER TO dankupfer;

--
-- Name: can_void_billing_period(integer); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.can_void_billing_period(period_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM monthly_billing_periods 
        WHERE id = period_id 
        AND status != 'void' 
        AND can_be_voided = true
    );
END;
$$;


ALTER FUNCTION public.can_void_billing_period(period_id integer) OWNER TO dankupfer;

--
-- Name: change_patient_billing_cycle(integer, character varying, numeric, date, text, character varying, text); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text DEFAULT NULL::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_history_id INTEGER;
    patient_therapist_id INTEGER;
BEGIN
    -- Get therapist_id for this patient
    SELECT therapist_id INTO patient_therapist_id FROM patients WHERE id = p_patient_id;
    
    -- Close current patient billing override (if any)
    UPDATE patient_billing_history
    SET effective_until_date = p_effective_from_date - INTERVAL '1 day'
    WHERE patient_id = p_patient_id
        AND effective_until_date IS NULL;
    
    -- Insert new patient billing history
    INSERT INTO patient_billing_history (
        patient_id,
        therapist_id,
        billing_cycle,
        session_price,
        effective_from_date,
        reason_for_change,
        created_by,
        notes
    ) VALUES (
        p_patient_id,
        patient_therapist_id,
        p_new_billing_cycle,
        p_new_session_price,
        p_effective_from_date,
        p_reason,
        p_created_by,
        p_notes
    ) RETURNING id INTO new_history_id;
    
    -- Update patient table with current values (for quick access)
    UPDATE patients
    SET session_price = p_new_session_price
    WHERE id = p_patient_id;
    
    RETURN new_history_id;
END;
$$;


ALTER FUNCTION public.change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) OWNER TO dankupfer;

--
-- Name: FUNCTION change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.change_patient_billing_cycle(p_patient_id integer, p_new_billing_cycle character varying, p_new_session_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) IS 'Change patient-specific billing with history tracking';


--
-- Name: change_therapist_billing_cycle(integer, character varying, numeric, date, text, character varying, text); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text DEFAULT NULL::text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_history_id INTEGER;
BEGIN
    -- Close current billing cycle (set effective_until_date)
    UPDATE therapist_billing_history
    SET effective_until_date = p_effective_from_date - INTERVAL '1 day'
    WHERE therapist_id = p_therapist_id
        AND effective_until_date IS NULL;
    
    -- Insert new billing cycle history
    INSERT INTO therapist_billing_history (
        therapist_id,
        billing_cycle,
        default_session_price,
        effective_from_date,
        reason_for_change,
        created_by,
        notes
    ) VALUES (
        p_therapist_id,
        p_new_billing_cycle,
        p_new_default_price,
        p_effective_from_date,
        p_reason,
        p_created_by,
        p_notes
    ) RETURNING id INTO new_history_id;
    
    -- Update therapist table with current values (for quick access)
    UPDATE therapists
    SET 
        billing_cycle = p_new_billing_cycle,
        default_session_price = p_new_default_price
    WHERE id = p_therapist_id;
    
    RETURN new_history_id;
END;
$$;


ALTER FUNCTION public.change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) OWNER TO dankupfer;

--
-- Name: FUNCTION change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.change_therapist_billing_cycle(p_therapist_id integer, p_new_billing_cycle character varying, p_new_default_price numeric, p_effective_from_date date, p_reason text, p_created_by character varying, p_notes text) IS 'Change therapist billing cycle with history tracking';


--
-- Name: cleanup_expired_sessions(); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.cleanup_expired_sessions() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    expired_count INTEGER;
BEGIN
    -- Terminate expired sessions
    UPDATE user_sessions 
    SET 
        status = 'expired',
        terminated_at = CURRENT_TIMESTAMP,
        termination_reason = 'timeout'
    WHERE status = 'active' 
    AND (
        expires_at < CURRENT_TIMESTAMP 
        OR last_activity_at < CURRENT_TIMESTAMP - INTERVAL '1 minute' * inactive_timeout_minutes
    );
    
    GET DIAGNOSTICS expired_count = ROW_COUNT;
    
    -- Log cleanup activity
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    )
    SELECT 
        us.id, us.user_id, 'cleanup_expired',
        JSON_BUILD_OBJECT('expired_count', expired_count, 'cleanup_time', CURRENT_TIMESTAMP)
    FROM user_sessions us 
    WHERE us.status = 'expired' 
    AND us.terminated_at >= CURRENT_TIMESTAMP - INTERVAL '1 minute'
    LIMIT 1; -- Just log once per cleanup
    
    RETURN expired_count;
END;
$$;


ALTER FUNCTION public.cleanup_expired_sessions() OWNER TO dankupfer;

--
-- Name: FUNCTION cleanup_expired_sessions(); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.cleanup_expired_sessions() IS 'Background job to clean up expired sessions';


--
-- Name: disable_super_admin(); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.disable_super_admin() RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE app_configuration 
    SET value = 'false', updated_at = CURRENT_TIMESTAMP 
    WHERE key = 'auth_super_admin_enabled';
    
    -- Deactivate existing super admin permissions (don't delete for audit)
    UPDATE user_permissions 
    SET is_active = false 
    WHERE role = 'super_admin';
    
    -- Log the change
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    ) VALUES (
        NULL, NULL, 'super_admin_disabled',
        JSON_BUILD_OBJECT(
            'disabled_at', CURRENT_TIMESTAMP,
            'reason', 'production_security'
        )
    );
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.disable_super_admin() OWNER TO dankupfer;

--
-- Name: FUNCTION disable_super_admin(); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.disable_super_admin() IS 'Disable super admin role for production security';


--
-- Name: extend_user_session(character varying); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.extend_user_session(p_session_token character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    session_record RECORD;
BEGIN
    -- Get session details
    SELECT * INTO session_record
    FROM user_sessions 
    WHERE session_token = p_session_token 
    AND status = 'active'
    AND expires_at > CURRENT_TIMESTAMP;
    
    IF NOT FOUND THEN
        RETURN false;
    END IF;
    
    -- Update session activity and extend expiration
    UPDATE user_sessions 
    SET 
        last_activity_at = CURRENT_TIMESTAMP,
        expires_at = CURRENT_TIMESTAMP + INTERVAL '1 hour' * session_record.max_session_hours
    WHERE id = session_record.id;
    
    -- Log the session extension
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    ) VALUES (
        session_record.id, session_record.user_id, 'session_extended',
        JSON_BUILD_OBJECT('extended_at', CURRENT_TIMESTAMP)
    );
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.extend_user_session(p_session_token character varying) OWNER TO dankupfer;

--
-- Name: FUNCTION extend_user_session(p_session_token character varying); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.extend_user_session(p_session_token character varying) IS 'Extend session when user chooses to continue';


--
-- Name: extract_patient_name_from_summary(text); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.extract_patient_name_from_summary(summary text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- Handle "Sessão - Patient Name" format
    IF summary ~* '^sessão\s*-\s*(.+)$' THEN
        RETURN TRIM(REGEXP_REPLACE(summary, '^sessão\s*-\s*', '', 'i'));
    END IF;
    
    -- Handle "Patient Name - Sessão" format
    IF summary ~* '^(.+)\s*-\s*sessão$' THEN
        RETURN TRIM(REGEXP_REPLACE(summary, '\s*-\s*sessão$', '', 'i'));
    END IF;
    
    -- Handle just patient name (if marked as therapy session)
    RETURN TRIM(summary);
END;
$_$;


ALTER FUNCTION public.extract_patient_name_from_summary(summary text) OWNER TO dankupfer;

--
-- Name: FUNCTION extract_patient_name_from_summary(summary text); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.extract_patient_name_from_summary(summary text) IS 'Extract patient name from calendar event summary text';


--
-- Name: get_billing_sessions_count(integer, integer, date, date); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date DEFAULT NULL::date, p_end_date date DEFAULT NULL::date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    session_count INTEGER;
BEGIN
    SELECT COUNT(*)
    INTO session_count
    FROM billable_sessions bs
    WHERE bs.therapist_id = p_therapist_id
        AND bs.patient_id = p_patient_id
        AND bs.counts_for_billing = true
        AND bs.status = 'compareceu'
        AND (p_start_date IS NULL OR bs.date::date >= p_start_date)
        AND (p_end_date IS NULL OR bs.date::date <= p_end_date);
    
    RETURN COALESCE(session_count, 0);
END;
$$;


ALTER FUNCTION public.get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date, p_end_date date) OWNER TO dankupfer;

--
-- Name: FUNCTION get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date, p_end_date date); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.get_billing_sessions_count(p_therapist_id integer, p_patient_id integer, p_start_date date, p_end_date date) IS 'Calculate billable sessions count for a patient within date range';


--
-- Name: get_monthly_billing_summary(character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.get_monthly_billing_summary(therapist_email character varying, summary_year integer DEFAULT EXTRACT(year FROM CURRENT_DATE), summary_month integer DEFAULT EXTRACT(month FROM CURRENT_DATE)) RETURNS TABLE(patient_name character varying, patient_id integer, billing_period_id integer, session_count integer, total_amount numeric, status character varying, has_payment boolean, processed_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.nome as patient_name,
        p.id as patient_id,
        bp.id as billing_period_id,
        bp.session_count,
        bp.total_amount,
        bp.status,
        EXISTS(SELECT 1 FROM monthly_billing_payments pay WHERE pay.billing_period_id = bp.id) as has_payment,
        bp.processed_at
    FROM monthly_billing_periods bp
    JOIN patients p ON bp.patient_id = p.id
    JOIN therapists t ON bp.therapist_id = t.id
    WHERE t.email = therapist_email
    AND bp.billing_year = summary_year
    AND bp.billing_month = summary_month
    AND bp.status != 'void'
    ORDER BY p.nome;
END;
$$;


ALTER FUNCTION public.get_monthly_billing_summary(therapist_email character varying, summary_year integer, summary_month integer) OWNER TO dankupfer;

--
-- Name: FUNCTION get_monthly_billing_summary(therapist_email character varying, summary_year integer, summary_month integer); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.get_monthly_billing_summary(therapist_email character varying, summary_year integer, summary_month integer) IS 'Get billing overview for therapist for specific month';


--
-- Name: get_patient_billing_cycle(integer, date); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.get_patient_billing_cycle(p_patient_id integer, p_date date DEFAULT CURRENT_DATE) RETURNS TABLE(billing_cycle character varying, session_price numeric, effective_from_date date, is_override boolean)
    LANGUAGE plpgsql
    AS $$
DECLARE
    patient_therapist_id INTEGER;
BEGIN
    -- Get the therapist for this patient
    SELECT therapist_id INTO patient_therapist_id FROM patients WHERE id = p_patient_id;
    
    -- First check for patient-specific overrides
    RETURN QUERY
    SELECT 
        pbh.billing_cycle,
        pbh.session_price,
        pbh.effective_from_date,
        true as is_override
    FROM patient_billing_history pbh
    WHERE pbh.patient_id = p_patient_id
        AND pbh.effective_from_date <= p_date
        AND (pbh.effective_until_date IS NULL OR pbh.effective_until_date >= p_date)
    ORDER BY pbh.effective_from_date DESC
    LIMIT 1;
    
    -- If no patient override, use therapist default
    IF NOT FOUND THEN
        RETURN QUERY
        SELECT 
            therapy_cycle.billing_cycle,
            therapy_cycle.default_session_price,
            therapy_cycle.effective_from_date,
            false as is_override
        FROM get_therapist_billing_cycle(patient_therapist_id, p_date) therapy_cycle;
    END IF;
END;
$$;


ALTER FUNCTION public.get_patient_billing_cycle(p_patient_id integer, p_date date) OWNER TO dankupfer;

--
-- Name: FUNCTION get_patient_billing_cycle(p_patient_id integer, p_date date); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.get_patient_billing_cycle(p_patient_id integer, p_date date) IS 'Get billing cycle for patient with override support';


--
-- Name: get_therapist_billing_cycle(integer, date); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.get_therapist_billing_cycle(p_therapist_id integer, p_date date DEFAULT CURRENT_DATE) RETURNS TABLE(billing_cycle character varying, default_session_price numeric, effective_from_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tbh.billing_cycle,
        tbh.default_session_price,
        tbh.effective_from_date
    FROM therapist_billing_history tbh
    WHERE tbh.therapist_id = p_therapist_id
        AND tbh.effective_from_date <= p_date
        AND (tbh.effective_until_date IS NULL OR tbh.effective_until_date >= p_date)
    ORDER BY tbh.effective_from_date DESC
    LIMIT 1;
    
    -- If no history record exists, return the default from therapists table
    IF NOT FOUND THEN
        RETURN QUERY
        SELECT 
            t.billing_cycle,
            t.default_session_price,
            CURRENT_DATE as effective_from_date
        FROM therapists t
        WHERE t.id = p_therapist_id;
    END IF;
END;
$$;


ALTER FUNCTION public.get_therapist_billing_cycle(p_therapist_id integer, p_date date) OWNER TO dankupfer;

--
-- Name: FUNCTION get_therapist_billing_cycle(p_therapist_id integer, p_date date); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.get_therapist_billing_cycle(p_therapist_id integer, p_date date) IS 'Get current billing cycle configuration for therapist';


--
-- Name: get_therapist_setting(integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying DEFAULT NULL::character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    setting_value VARCHAR(255);
BEGIN
    SELECT ts.setting_value
    INTO setting_value
    FROM therapist_settings ts
    WHERE ts.therapist_id = p_therapist_id
        AND ts.setting_key = p_setting_key;
    
    RETURN COALESCE(setting_value, p_default_value);
END;
$$;


ALTER FUNCTION public.get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying) OWNER TO dankupfer;

--
-- Name: FUNCTION get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.get_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_default_value character varying) IS 'Get therapist UI setting with default fallback';


--
-- Name: get_user_practices(integer); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.get_user_practices(p_user_id integer) RETURNS TABLE(therapist_id integer, therapist_name character varying, therapist_email character varying, user_role public.user_role, granted_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id as therapist_id,
        t.nome as therapist_name,
        t.email as therapist_email,
        up.role as user_role,
        up.granted_at
    FROM user_permissions up
    JOIN therapists t ON up.therapist_id = t.id
    WHERE up.user_id = p_user_id
    AND up.is_active = true
    AND (up.expires_at IS NULL OR up.expires_at > CURRENT_TIMESTAMP)
    ORDER BY up.granted_at ASC;
END;
$$;


ALTER FUNCTION public.get_user_practices(p_user_id integer) OWNER TO dankupfer;

--
-- Name: FUNCTION get_user_practices(p_user_id integer); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.get_user_practices(p_user_id integer) IS 'Get all practices user has access to with their roles';


--
-- Name: grant_super_admin(character varying, character varying); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.grant_super_admin(p_user_email character varying, p_granted_by_email character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    target_user_id INTEGER;
    granting_user_id INTEGER;
    super_admin_enabled BOOLEAN;
BEGIN
    -- Check if super admin is enabled
    SELECT get_auth_config('auth_super_admin_enabled')::BOOLEAN INTO super_admin_enabled;
    
    IF NOT super_admin_enabled THEN
        RAISE EXCEPTION 'Super admin role is disabled for security';
    END IF;
    
    -- Get user IDs
    SELECT id INTO target_user_id FROM user_credentials WHERE email = p_user_email;
    SELECT id INTO granting_user_id FROM user_credentials WHERE email = p_granted_by_email;
    
    IF target_user_id IS NULL THEN
        RAISE EXCEPTION 'Target user not found: %', p_user_email;
    END IF;
    
    IF granting_user_id IS NULL THEN
        RAISE EXCEPTION 'Granting user not found: %', p_granted_by_email;
    END IF;
    
    -- Grant super admin to any practice (we'll use therapist_id = 1 as placeholder)
    INSERT INTO user_permissions (
        user_id, therapist_id, role, granted_by, notes
    ) VALUES (
        target_user_id,
        (SELECT MIN(id) FROM therapists), -- Use first therapist as placeholder
        'super_admin',
        granting_user_id,
        'Super admin access granted - can access all practices'
    )
    ON CONFLICT (user_id, therapist_id) DO UPDATE SET
        role = 'super_admin',
        is_active = true,
        granted_by = granting_user_id,
        granted_at = CURRENT_TIMESTAMP,
        notes = EXCLUDED.notes;
    
    -- Log the grant
    INSERT INTO session_activity_log (
        session_id, user_id, activity_type, metadata
    ) VALUES (
        NULL, granting_user_id, 'super_admin_granted',
        JSON_BUILD_OBJECT(
            'target_user', p_user_email,
            'granted_by', p_granted_by_email,
            'granted_at', CURRENT_TIMESTAMP
        )
    );
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.grant_super_admin(p_user_email character varying, p_granted_by_email character varying) OWNER TO dankupfer;

--
-- Name: FUNCTION grant_super_admin(p_user_email character varying, p_granted_by_email character varying); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.grant_super_admin(p_user_email character varying, p_granted_by_email character varying) IS 'Grant super admin access (only when enabled)';


--
-- Name: migrate_existing_therapists_to_auth(); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.migrate_existing_therapists_to_auth() RETURNS TABLE(therapist_id integer, therapist_email character varying, created_user_id integer, migration_status character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    therapist_record RECORD;
    new_user_id_var INTEGER;
    temp_password VARCHAR(255);
    permission_exists BOOLEAN;
BEGIN
    -- Iterate through existing therapists who don't have user credentials yet
    FOR therapist_record IN 
        SELECT t.id, t.email, t.nome 
        FROM therapists t 
        WHERE t.email IS NOT NULL 
        AND NOT EXISTS (
            SELECT 1 FROM user_permissions up 
            JOIN user_credentials uc ON up.user_id = uc.id 
            WHERE up.therapist_id = t.id AND uc.email = t.email
        )
    LOOP
        -- Generate temporary password (they'll need to reset it)
        temp_password := 'temp_' || EXTRACT(EPOCH FROM CURRENT_TIMESTAMP)::TEXT || '_' || RANDOM()::TEXT;
        
        -- Create user credential (or get existing)
        INSERT INTO user_credentials (
            email, password_hash, display_name, is_active, email_verified
        ) VALUES (
            therapist_record.email, 
            temp_password, -- They'll need to set real password via reset flow
            therapist_record.nome,
            true,
            false -- Require email verification
        )
        ON CONFLICT (email) DO UPDATE SET
            display_name = EXCLUDED.display_name
        RETURNING id INTO new_user_id_var;
        
        -- If no new user was created, get existing one
        IF new_user_id_var IS NULL THEN
            SELECT id INTO new_user_id_var 
            FROM user_credentials 
            WHERE email = therapist_record.email;
        END IF;
        
        -- Check if permission already exists using table alias
        SELECT EXISTS(
            SELECT 1 FROM user_permissions up
            WHERE up.user_id = new_user_id_var AND up.therapist_id = therapist_record.id
        ) INTO permission_exists;
        
        -- Grant owner permissions only if they don't exist
        IF NOT permission_exists THEN
            INSERT INTO user_permissions (
                user_id, therapist_id, role, granted_by, notes
            ) VALUES (
                new_user_id_var,
                therapist_record.id,
                'owner',
                new_user_id_var, -- Self-granted during migration
                'Migrated from existing therapist account'
            );
        END IF;
        
        -- Return migration result
        RETURN QUERY SELECT 
            therapist_record.id,
            therapist_record.email,
            new_user_id_var,
            'migrated'::VARCHAR(50);
    END LOOP;
END;
$$;


ALTER FUNCTION public.migrate_existing_therapists_to_auth() OWNER TO dankupfer;

--
-- Name: FUNCTION migrate_existing_therapists_to_auth(); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.migrate_existing_therapists_to_auth() IS 'SAFE migration for existing therapists';


--
-- Name: set_therapist_setting(integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO therapist_settings (therapist_id, setting_key, setting_value, updated_at)
    VALUES (p_therapist_id, p_setting_key, p_setting_value, CURRENT_TIMESTAMP)
    ON CONFLICT (therapist_id, setting_key)
    DO UPDATE SET 
        setting_value = EXCLUDED.setting_value,
        updated_at = CURRENT_TIMESTAMP;
END;
$$;


ALTER FUNCTION public.set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying) OWNER TO dankupfer;

--
-- Name: FUNCTION set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.set_therapist_setting(p_therapist_id integer, p_setting_key character varying, p_setting_value character varying) IS 'Set or update therapist UI setting (upsert)';


--
-- Name: update_billing_period_status(); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.update_billing_period_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        -- Payment added: mark period as paid and prevent voiding
        UPDATE monthly_billing_periods 
        SET 
            status = 'paid',
            can_be_voided = false
        WHERE id = NEW.billing_period_id;
        
    ELSIF TG_OP = 'DELETE' THEN
        -- Payment deleted: check if any payments remain
        IF NOT EXISTS (
            SELECT 1 FROM monthly_billing_payments 
            WHERE billing_period_id = OLD.billing_period_id
        ) THEN
            -- No payments left: allow voiding again
            UPDATE monthly_billing_periods 
            SET 
                status = 'processed',
                can_be_voided = true
            WHERE id = OLD.billing_period_id;
        END IF;
    END IF;
    
    RETURN COALESCE(NEW, OLD);
END;
$$;


ALTER FUNCTION public.update_billing_period_status() OWNER TO dankupfer;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO dankupfer;

--
-- Name: user_has_permission(integer, integer, public.user_role); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role DEFAULT 'viewer'::public.user_role) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    user_role_level INTEGER;
    required_role_level INTEGER;
BEGIN
    -- Define role hierarchy (higher number = more permissions)
    SELECT CASE 
        WHEN up.role = 'super_admin' THEN 4
        WHEN up.role = 'owner' THEN 3
        WHEN up.role = 'manager' THEN 2
        WHEN up.role = 'viewer' THEN 1
        ELSE 0
    END INTO user_role_level
    FROM user_permissions up
    WHERE up.user_id = p_user_id 
    AND up.therapist_id = p_therapist_id
    AND up.is_active = true
    AND (up.expires_at IS NULL OR up.expires_at > CURRENT_TIMESTAMP);
    
    -- If user not found, check for super_admin on any practice
    IF user_role_level IS NULL THEN
        SELECT CASE 
            WHEN up.role = 'super_admin' THEN 4
            ELSE 0
        END INTO user_role_level
        FROM user_permissions up
        WHERE up.user_id = p_user_id 
        AND up.role = 'super_admin'
        AND up.is_active = true
        AND (up.expires_at IS NULL OR up.expires_at > CURRENT_TIMESTAMP)
        LIMIT 1;
    END IF;
    
    -- Get required role level
    required_role_level := CASE 
        WHEN p_required_role = 'super_admin' THEN 4
        WHEN p_required_role = 'owner' THEN 3
        WHEN p_required_role = 'manager' THEN 2
        WHEN p_required_role = 'viewer' THEN 1
        ELSE 0
    END;
    
    RETURN COALESCE(user_role_level, 0) >= required_role_level;
END;
$$;


ALTER FUNCTION public.user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role) OWNER TO dankupfer;

--
-- Name: FUNCTION user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.user_has_permission(p_user_id integer, p_therapist_id integer, p_required_role public.user_role) IS 'Check if user has required role for practice (supports super_admin)';


--
-- Name: void_billing_period(integer, character varying, text); Type: FUNCTION; Schema: public; Owner: dankupfer
--

CREATE FUNCTION public.void_billing_period(period_id integer, voided_by_email character varying, reason text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if period can be voided
    IF NOT can_void_billing_period(period_id) THEN
        RETURN false;
    END IF;
    
    -- Void the period
    UPDATE monthly_billing_periods 
    SET 
        status = 'void',
        can_be_voided = false,
        voided_at = CURRENT_TIMESTAMP,
        voided_by = voided_by_email,
        void_reason = reason
    WHERE id = period_id;
    
    RETURN true;
END;
$$;


ALTER FUNCTION public.void_billing_period(period_id integer, voided_by_email character varying, reason text) OWNER TO dankupfer;

--
-- Name: FUNCTION void_billing_period(period_id integer, voided_by_email character varying, reason text); Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON FUNCTION public.void_billing_period(period_id integer, voided_by_email character varying, reason text) IS 'Safely void a billing period with audit trail (only if no payments exist)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_configuration; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.app_configuration (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.app_configuration OWNER TO dankupfer;

--
-- Name: TABLE app_configuration; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.app_configuration IS 'Global application configuration settings';


--
-- Name: COLUMN app_configuration.key; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.app_configuration.key IS 'Global setting key: calendar_mode, app_version, etc.';


--
-- Name: COLUMN app_configuration.value; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.app_configuration.value IS 'Global setting value stored as string';


--
-- Name: app_configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.app_configuration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.app_configuration_id_seq OWNER TO dankupfer;

--
-- Name: app_configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.app_configuration_id_seq OWNED BY public.app_configuration.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    email character varying(255),
    telefone character varying(20),
    cpf character varying(14),
    nota boolean DEFAULT false,
    preco numeric(10,2),
    therapist_id integer,
    therapy_start_date date,
    lv_notas_billing_start_date date,
    session_price numeric(10,2),
    recurring_pattern character varying(50),
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patients OWNER TO dankupfer;

--
-- Name: TABLE patients; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.patients IS 'Patient records with dual date system for therapy vs billing tracking and CPF support';


--
-- Name: COLUMN patients.cpf; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.patients.cpf IS 'Brazilian CPF (Cadastro de Pessoas Físicas) - format XXX.XXX.XXX-XX';


--
-- Name: COLUMN patients.therapy_start_date; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.patients.therapy_start_date IS 'Historical date when therapy actually began (optional, for context only)';


--
-- Name: COLUMN patients.lv_notas_billing_start_date; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.patients.lv_notas_billing_start_date IS 'Date when LV Notas billing begins (required, affects billing calculations)';


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    google_calendar_event_id character varying(255),
    patient_id integer,
    therapist_id integer,
    status public.session_status DEFAULT 'agendada'::public.session_status,
    billable boolean DEFAULT true,
    billing_period character varying(20),
    session_price numeric(10,2),
    billing_cycle_used character varying(20),
    created_during_onboarding boolean DEFAULT false,
    import_batch_id character varying(255),
    payment_requested boolean DEFAULT false,
    payment_request_date timestamp with time zone,
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    paid_date timestamp with time zone,
    billing_period_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sessions OWNER TO dankupfer;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.sessions IS 'Therapy sessions with billing and payment tracking';


--
-- Name: COLUMN sessions.billable; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.sessions.billable IS 'Whether this session counts toward billing (based on billing start date)';


--
-- Name: COLUMN sessions.created_during_onboarding; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.sessions.created_during_onboarding IS 'Was this session created during the onboarding import process';


--
-- Name: COLUMN sessions.payment_status; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.sessions.payment_status IS 'Current payment status: pending, paid, overdue, etc.';


--
-- Name: billable_sessions; Type: VIEW; Schema: public; Owner: dankupfer
--

CREATE VIEW public.billable_sessions AS
 SELECT s.id,
    s.date,
    s.google_calendar_event_id,
    s.patient_id,
    s.therapist_id,
    s.status,
    s.billable,
    s.billing_period,
    s.session_price,
    s.billing_cycle_used,
    s.created_during_onboarding,
    s.import_batch_id,
    s.payment_requested,
    s.payment_request_date,
    s.payment_status,
    s.paid_date,
    s.billing_period_id,
    s.created_at,
    p.lv_notas_billing_start_date,
        CASE
            WHEN ((s.date)::date >= p.lv_notas_billing_start_date) THEN true
            ELSE false
        END AS counts_for_billing
   FROM (public.sessions s
     JOIN public.patients p ON ((s.patient_id = p.id)))
  WHERE (s.billable = true);


ALTER TABLE public.billable_sessions OWNER TO dankupfer;

--
-- Name: VIEW billable_sessions; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON VIEW public.billable_sessions IS 'Sessions that count for billing based on LV Notas billing start date';


--
-- Name: patient_billing_history; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.patient_billing_history (
    id integer NOT NULL,
    patient_id integer,
    therapist_id integer,
    billing_cycle character varying(20) NOT NULL,
    session_price numeric(10,2),
    effective_from_date date NOT NULL,
    effective_until_date date,
    reason_for_change text,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


ALTER TABLE public.patient_billing_history OWNER TO dankupfer;

--
-- Name: TABLE patient_billing_history; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.patient_billing_history IS 'Patient-specific billing overrides with full history';


--
-- Name: COLUMN patient_billing_history.effective_until_date; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.patient_billing_history.effective_until_date IS 'NULL means this is the current active override';


--
-- Name: therapist_billing_history; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.therapist_billing_history (
    id integer NOT NULL,
    therapist_id integer,
    billing_cycle character varying(20) NOT NULL,
    default_session_price numeric(10,2),
    effective_from_date date NOT NULL,
    effective_until_date date,
    reason_for_change text,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


ALTER TABLE public.therapist_billing_history OWNER TO dankupfer;

--
-- Name: TABLE therapist_billing_history; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.therapist_billing_history IS 'Complete history of billing cycle changes for therapists';


--
-- Name: COLUMN therapist_billing_history.effective_until_date; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.therapist_billing_history.effective_until_date IS 'NULL means this is the current active billing cycle';


--
-- Name: therapists; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.therapists (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    email character varying(255),
    telefone character varying(20),
    google_calendar_id character varying(255),
    billing_cycle character varying(20) DEFAULT 'monthly'::character varying,
    default_session_price numeric(10,2),
    onboarding_completed boolean DEFAULT false,
    onboarding_started_at timestamp with time zone,
    onboarding_completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.therapists OWNER TO dankupfer;

--
-- Name: TABLE therapists; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.therapists IS 'Core therapist accounts with billing and onboarding configuration';


--
-- Name: billing_change_history; Type: VIEW; Schema: public; Owner: dankupfer
--

CREATE VIEW public.billing_change_history AS
 SELECT 'therapist'::text AS change_type,
    tbh.id AS history_id,
    tbh.therapist_id,
    NULL::integer AS patient_id,
    t.nome AS therapist_name,
    NULL::character varying AS patient_name,
    tbh.billing_cycle,
    tbh.default_session_price AS price,
    tbh.effective_from_date,
    tbh.effective_until_date,
    tbh.reason_for_change,
    tbh.created_by,
    tbh.created_at,
    tbh.notes
   FROM (public.therapist_billing_history tbh
     JOIN public.therapists t ON ((tbh.therapist_id = t.id)))
UNION ALL
 SELECT 'patient'::text AS change_type,
    pbh.id AS history_id,
    pbh.therapist_id,
    pbh.patient_id,
    t.nome AS therapist_name,
    p.nome AS patient_name,
    pbh.billing_cycle,
    pbh.session_price AS price,
    pbh.effective_from_date,
    pbh.effective_until_date,
    pbh.reason_for_change,
    pbh.created_by,
    pbh.created_at,
    pbh.notes
   FROM ((public.patient_billing_history pbh
     JOIN public.therapists t ON ((pbh.therapist_id = t.id)))
     JOIN public.patients p ON ((pbh.patient_id = p.id)))
  ORDER BY 13 DESC;


ALTER TABLE public.billing_change_history OWNER TO dankupfer;

--
-- Name: VIEW billing_change_history; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON VIEW public.billing_change_history IS 'Complete history of all billing changes for therapists and patients';


--
-- Name: billing_periods; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.billing_periods (
    id integer NOT NULL,
    therapist_id integer,
    patient_id integer,
    billing_cycle character varying(20) NOT NULL,
    period_start_date date NOT NULL,
    period_end_date date NOT NULL,
    total_sessions integer DEFAULT 0,
    billable_sessions integer DEFAULT 0,
    total_amount numeric(10,2) DEFAULT 0.00,
    invoice_generated boolean DEFAULT false,
    invoice_sent boolean DEFAULT false,
    invoice_paid boolean DEFAULT false,
    invoice_date date,
    payment_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_periods OWNER TO dankupfer;

--
-- Name: TABLE billing_periods; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.billing_periods IS 'Actual billing periods and invoice tracking';


--
-- Name: COLUMN billing_periods.billable_sessions; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.billing_periods.billable_sessions IS 'Sessions that count for billing (after LV Notas start date)';


--
-- Name: billing_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.billing_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billing_periods_id_seq OWNER TO dankupfer;

--
-- Name: billing_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.billing_periods_id_seq OWNED BY public.billing_periods.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.calendar_events (
    id integer NOT NULL,
    event_type public.event_type NOT NULL,
    google_event_id character varying(255) NOT NULL,
    session_date timestamp with time zone NOT NULL,
    email character varying(255),
    date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendar_events OWNER TO dankupfer;

--
-- Name: TABLE calendar_events; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.calendar_events IS 'Log of calendar events for sync tracking';


--
-- Name: calendar_events_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.calendar_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calendar_events_id_seq OWNER TO dankupfer;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.calendar_events_id_seq OWNED BY public.calendar_events.id;


--
-- Name: calendar_webhooks; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.calendar_webhooks (
    id integer NOT NULL,
    channel_id character varying(255) NOT NULL,
    resource_id character varying(255) NOT NULL,
    expiration timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendar_webhooks OWNER TO dankupfer;

--
-- Name: TABLE calendar_webhooks; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.calendar_webhooks IS 'Active Google Calendar webhook subscriptions';


--
-- Name: calendar_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.calendar_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calendar_webhooks_id_seq OWNER TO dankupfer;

--
-- Name: calendar_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.calendar_webhooks_id_seq OWNED BY public.calendar_webhooks.id;


--
-- Name: check_ins; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.check_ins (
    id integer NOT NULL,
    patient_id integer,
    session_id integer,
    session_date timestamp with time zone,
    created_by character varying(255) NOT NULL,
    date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(10) DEFAULT 'compareceu'::character varying
);


ALTER TABLE public.check_ins OWNER TO dankupfer;

--
-- Name: TABLE check_ins; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.check_ins IS 'Patient attendance records';


--
-- Name: check_ins_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.check_ins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.check_ins_id_seq OWNER TO dankupfer;

--
-- Name: check_ins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.check_ins_id_seq OWNED BY public.check_ins.id;


--
-- Name: current_billing_settings; Type: VIEW; Schema: public; Owner: dankupfer
--

CREATE VIEW public.current_billing_settings AS
 SELECT p.id AS patient_id,
    p.nome AS patient_name,
    p.therapist_id,
    t.nome AS therapist_name,
    t.email AS therapist_email,
    t.billing_cycle AS current_billing_cycle,
    COALESCE(p.session_price, t.default_session_price) AS current_session_price,
        CASE
            WHEN (p.session_price IS NOT NULL) THEN true
            ELSE false
        END AS has_patient_override,
    p.lv_notas_billing_start_date,
    ( SELECT count(*) AS count
           FROM public.sessions s
          WHERE ((s.patient_id = p.id) AND (s.billable = true) AND (s.status = 'compareceu'::public.session_status) AND (p.lv_notas_billing_start_date IS NOT NULL) AND ((s.date)::date >= p.lv_notas_billing_start_date))) AS total_billable_sessions
   FROM (public.patients p
     JOIN public.therapists t ON ((p.therapist_id = t.id)));


ALTER TABLE public.current_billing_settings OWNER TO dankupfer;

--
-- Name: VIEW current_billing_settings; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON VIEW public.current_billing_settings IS 'Current billing configuration for all patients with session counts';


--
-- Name: imported_calendar_events; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.imported_calendar_events (
    id integer NOT NULL,
    therapist_id integer,
    google_event_id character varying(255) NOT NULL,
    original_summary character varying(500),
    description text,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    attendees_emails text[],
    is_therapy_session boolean DEFAULT false,
    is_recurring boolean DEFAULT false,
    recurring_rule text,
    linked_patient_id integer,
    matched_patient_name character varying(255),
    processed boolean DEFAULT false,
    import_batch_id character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp with time zone
);


ALTER TABLE public.imported_calendar_events OWNER TO dankupfer;

--
-- Name: TABLE imported_calendar_events; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.imported_calendar_events IS 'Calendar events imported during onboarding for processing';


--
-- Name: imported_calendar_events_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.imported_calendar_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.imported_calendar_events_id_seq OWNER TO dankupfer;

--
-- Name: imported_calendar_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.imported_calendar_events_id_seq OWNED BY public.imported_calendar_events.id;


--
-- Name: monthly_billing_payments; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.monthly_billing_payments (
    id integer NOT NULL,
    billing_period_id integer,
    therapist_id integer,
    patient_id integer,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(50),
    payment_date timestamp with time zone NOT NULL,
    reference_number character varying(255),
    recorded_by character varying(255) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.monthly_billing_payments OWNER TO dankupfer;

--
-- Name: TABLE monthly_billing_payments; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.monthly_billing_payments IS 'Actual payments received for billing periods';


--
-- Name: monthly_billing_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.monthly_billing_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monthly_billing_payments_id_seq OWNER TO dankupfer;

--
-- Name: monthly_billing_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.monthly_billing_payments_id_seq OWNED BY public.monthly_billing_payments.id;


--
-- Name: monthly_billing_periods; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.monthly_billing_periods (
    id integer NOT NULL,
    therapist_id integer,
    patient_id integer,
    billing_year integer NOT NULL,
    billing_month integer NOT NULL,
    session_count integer DEFAULT 0 NOT NULL,
    total_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    session_snapshots jsonb DEFAULT '[]'::jsonb NOT NULL,
    processed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    processed_by character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'processed'::character varying,
    can_be_voided boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    voided_at timestamp with time zone,
    voided_by character varying(255),
    void_reason text
);


ALTER TABLE public.monthly_billing_periods OWNER TO dankupfer;

--
-- Name: TABLE monthly_billing_periods; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.monthly_billing_periods IS 'Monthly billing periods with immutable session snapshots from Google Calendar';


--
-- Name: COLUMN monthly_billing_periods.session_snapshots; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.monthly_billing_periods.session_snapshots IS 'JSON array of session details from Google Calendar at processing time';


--
-- Name: COLUMN monthly_billing_periods.can_be_voided; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.monthly_billing_periods.can_be_voided IS 'False once any payment exists - prevents accidental voiding of paid periods';


--
-- Name: monthly_billing_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.monthly_billing_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monthly_billing_periods_id_seq OWNER TO dankupfer;

--
-- Name: monthly_billing_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.monthly_billing_periods_id_seq OWNED BY public.monthly_billing_periods.id;


--
-- Name: patient_billing_history_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.patient_billing_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patient_billing_history_id_seq OWNER TO dankupfer;

--
-- Name: patient_billing_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.patient_billing_history_id_seq OWNED BY public.patient_billing_history.id;


--
-- Name: patient_matching_candidates; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.patient_matching_candidates (
    id integer NOT NULL,
    therapist_id integer,
    import_batch_id character varying(255) NOT NULL,
    extracted_name character varying(255) NOT NULL,
    name_variations text[],
    email_addresses text[],
    event_count integer DEFAULT 0,
    first_session_date date,
    latest_session_date date,
    suggested_therapy_start_date date,
    suggested_billing_start_date date,
    confidence_score numeric(3,2) DEFAULT 0.0,
    manual_review_needed boolean DEFAULT false,
    created_patient_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.patient_matching_candidates OWNER TO dankupfer;

--
-- Name: TABLE patient_matching_candidates; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.patient_matching_candidates IS 'Smart patient detection and matching from calendar events';


--
-- Name: COLUMN patient_matching_candidates.suggested_therapy_start_date; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.patient_matching_candidates.suggested_therapy_start_date IS 'AI-suggested historical therapy start date based on calendar history';


--
-- Name: COLUMN patient_matching_candidates.suggested_billing_start_date; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.patient_matching_candidates.suggested_billing_start_date IS 'Default LV Notas billing start date (usually today)';


--
-- Name: patient_matching_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.patient_matching_candidates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patient_matching_candidates_id_seq OWNER TO dankupfer;

--
-- Name: patient_matching_candidates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.patient_matching_candidates_id_seq OWNED BY public.patient_matching_candidates.id;


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patients_id_seq OWNER TO dankupfer;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.payment_transactions (
    id integer NOT NULL,
    session_id integer,
    patient_id integer,
    therapist_id integer,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(50),
    payment_date timestamp with time zone NOT NULL,
    reference_number character varying(255),
    notes text,
    created_by character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payment_transactions OWNER TO dankupfer;

--
-- Name: TABLE payment_transactions; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.payment_transactions IS 'Records of actual payments received from patients';


--
-- Name: COLUMN payment_transactions.payment_method; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.payment_transactions.payment_method IS 'PIX, bank transfer, cash, credit card, etc.';


--
-- Name: payment_overview; Type: VIEW; Schema: public; Owner: dankupfer
--

CREATE VIEW public.payment_overview AS
 SELECT s.id AS session_id,
    s.date AS session_date,
    s.session_price,
    s.payment_status,
    s.payment_requested,
    s.payment_request_date,
    s.paid_date,
    p.id AS patient_id,
    p.nome AS patient_name,
    p.telefone AS patient_phone,
    t.id AS therapist_id,
    t.nome AS therapist_name,
    t.email AS therapist_email,
    pt.id AS payment_transaction_id,
    pt.amount AS paid_amount,
    pt.payment_method,
    pt.payment_date,
    pt.reference_number,
    (CURRENT_DATE - (s.date)::date) AS days_since_session,
        CASE
            WHEN (s.payment_request_date IS NOT NULL) THEN (CURRENT_DATE - (s.payment_request_date)::date)
            ELSE NULL::integer
        END AS days_since_request,
        CASE
            WHEN ((s.payment_status)::text = 'paid'::text) THEN 'pago'::text
            WHEN (s.payment_requested = false) THEN 'nao_cobrado'::text
            WHEN ((s.payment_requested = true) AND (s.payment_request_date > (CURRENT_DATE - '7 days'::interval))) THEN 'aguardando_pagamento'::text
            WHEN ((s.payment_requested = true) AND (s.payment_request_date <= (CURRENT_DATE - '7 days'::interval))) THEN 'pendente'::text
            ELSE 'nao_cobrado'::text
        END AS payment_state
   FROM (((public.sessions s
     JOIN public.patients p ON ((s.patient_id = p.id)))
     JOIN public.therapists t ON ((s.therapist_id = t.id)))
     LEFT JOIN public.payment_transactions pt ON ((s.id = pt.session_id)))
  WHERE ((s.status = 'compareceu'::public.session_status) AND ((s.date)::date >= p.lv_notas_billing_start_date));


ALTER TABLE public.payment_overview OWNER TO dankupfer;

--
-- Name: VIEW payment_overview; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON VIEW public.payment_overview IS 'Complete payment status overview with calculated payment states';


--
-- Name: payment_requests; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.payment_requests (
    id integer NOT NULL,
    patient_id integer,
    therapist_id integer,
    session_ids integer[],
    total_amount numeric(10,2) NOT NULL,
    request_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    request_type character varying(20) DEFAULT 'invoice'::character varying,
    whatsapp_sent boolean DEFAULT false,
    whatsapp_message text,
    response_received boolean DEFAULT false,
    response_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payment_requests OWNER TO dankupfer;

--
-- Name: TABLE payment_requests; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.payment_requests IS 'Log of payment communications sent to patients (WhatsApp, email, etc.)';


--
-- Name: COLUMN payment_requests.session_ids; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.payment_requests.session_ids IS 'Array of session IDs included in this payment request';


--
-- Name: COLUMN payment_requests.whatsapp_message; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.payment_requests.whatsapp_message IS 'The actual message content sent via WhatsApp';


--
-- Name: payment_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.payment_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_requests_id_seq OWNER TO dankupfer;

--
-- Name: payment_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.payment_requests_id_seq OWNED BY public.payment_requests.id;


--
-- Name: payment_status_history; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.payment_status_history (
    id integer NOT NULL,
    session_id integer,
    old_status character varying(50),
    new_status character varying(50),
    changed_by character varying(255),
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    reason text,
    payment_transaction_id integer
);


ALTER TABLE public.payment_status_history OWNER TO dankupfer;

--
-- Name: TABLE payment_status_history; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.payment_status_history IS 'Complete audit trail of payment status changes';


--
-- Name: payment_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.payment_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_status_history_id_seq OWNER TO dankupfer;

--
-- Name: payment_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.payment_status_history_id_seq OWNED BY public.payment_status_history.id;


--
-- Name: payment_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.payment_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_transactions_id_seq OWNER TO dankupfer;

--
-- Name: payment_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.payment_transactions_id_seq OWNED BY public.payment_transactions.id;


--
-- Name: practice_invitations; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.practice_invitations (
    id integer NOT NULL,
    therapist_id integer,
    invited_by integer,
    invited_email character varying(255) NOT NULL,
    invited_role public.user_role NOT NULL,
    invitation_token character varying(255) NOT NULL,
    personal_message text,
    permissions_description text,
    status public.invitation_status DEFAULT 'pending'::public.invitation_status,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '7 days'::interval),
    responded_at timestamp with time zone,
    accepted_by integer,
    decline_reason text
);


ALTER TABLE public.practice_invitations OWNER TO dankupfer;

--
-- Name: TABLE practice_invitations; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.practice_invitations IS 'Invitation system for adding users to practices';


--
-- Name: practice_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.practice_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.practice_invitations_id_seq OWNER TO dankupfer;

--
-- Name: practice_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.practice_invitations_id_seq OWNED BY public.practice_invitations.id;


--
-- Name: recurring_session_templates; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.recurring_session_templates (
    id integer NOT NULL,
    therapist_id integer,
    patient_id integer,
    day_of_week integer,
    start_time time without time zone NOT NULL,
    duration_minutes integer DEFAULT 60,
    frequency character varying(20) DEFAULT 'weekly'::character varying,
    effective_from date NOT NULL,
    effective_until date,
    status character varying(20) DEFAULT 'active'::character varying,
    created_from_import boolean DEFAULT false,
    import_batch_id character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.recurring_session_templates OWNER TO dankupfer;

--
-- Name: TABLE recurring_session_templates; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.recurring_session_templates IS 'Detected recurring appointment patterns for automation';


--
-- Name: recurring_session_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.recurring_session_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recurring_session_templates_id_seq OWNER TO dankupfer;

--
-- Name: recurring_session_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.recurring_session_templates_id_seq OWNED BY public.recurring_session_templates.id;


--
-- Name: session_activity_log; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.session_activity_log (
    id integer NOT NULL,
    session_id integer,
    user_id integer,
    activity_type character varying(50) NOT NULL,
    endpoint character varying(255),
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.session_activity_log OWNER TO dankupfer;

--
-- Name: TABLE session_activity_log; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.session_activity_log IS 'Security and activity tracking for sessions';


--
-- Name: session_activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.session_activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.session_activity_log_id_seq OWNER TO dankupfer;

--
-- Name: session_activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.session_activity_log_id_seq OWNED BY public.session_activity_log.id;


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sessions_id_seq OWNER TO dankupfer;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: therapist_billing_history_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.therapist_billing_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapist_billing_history_id_seq OWNER TO dankupfer;

--
-- Name: therapist_billing_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.therapist_billing_history_id_seq OWNED BY public.therapist_billing_history.id;


--
-- Name: therapist_onboarding; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.therapist_onboarding (
    id integer NOT NULL,
    therapist_id integer,
    step character varying(50) NOT NULL,
    completed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    data jsonb,
    notes text
);


ALTER TABLE public.therapist_onboarding OWNER TO dankupfer;

--
-- Name: TABLE therapist_onboarding; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.therapist_onboarding IS 'Step-by-step tracking of therapist onboarding process';


--
-- Name: therapist_onboarding_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.therapist_onboarding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapist_onboarding_id_seq OWNER TO dankupfer;

--
-- Name: therapist_onboarding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.therapist_onboarding_id_seq OWNED BY public.therapist_onboarding.id;


--
-- Name: therapist_onboarding_progress; Type: VIEW; Schema: public; Owner: dankupfer
--

CREATE VIEW public.therapist_onboarding_progress AS
 SELECT t.id AS therapist_id,
    t.email,
    t.onboarding_completed,
    t.onboarding_started_at,
    t.onboarding_completed_at,
    COALESCE(json_agg(json_build_object('step', tog.step, 'completed_at', tog.completed_at, 'data', tog.data, 'notes', tog.notes) ORDER BY tog.completed_at) FILTER (WHERE (tog.step IS NOT NULL)), '[]'::json) AS completed_steps,
        CASE
            WHEN t.onboarding_completed THEN 'completed'::text
            WHEN (count(tog.step) = 0) THEN 'not_started'::text
            ELSE 'in_progress'::text
        END AS status
   FROM (public.therapists t
     LEFT JOIN public.therapist_onboarding tog ON ((t.id = tog.therapist_id)))
  GROUP BY t.id, t.email, t.onboarding_completed, t.onboarding_started_at, t.onboarding_completed_at;


ALTER TABLE public.therapist_onboarding_progress OWNER TO dankupfer;

--
-- Name: VIEW therapist_onboarding_progress; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON VIEW public.therapist_onboarding_progress IS 'Complete onboarding status and progress for each therapist';


--
-- Name: therapist_settings; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.therapist_settings (
    id integer NOT NULL,
    therapist_id integer,
    setting_key character varying(50) NOT NULL,
    setting_value character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.therapist_settings OWNER TO dankupfer;

--
-- Name: TABLE therapist_settings; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.therapist_settings IS 'Stores persistent UI preferences for each therapist';


--
-- Name: COLUMN therapist_settings.setting_key; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.therapist_settings.setting_key IS 'Setting name: payment_mode, view_mode, auto_check_in_mode, etc.';


--
-- Name: COLUMN therapist_settings.setting_value; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.therapist_settings.setting_value IS 'Setting value stored as string (parse as needed)';


--
-- Name: therapist_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.therapist_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapist_settings_id_seq OWNER TO dankupfer;

--
-- Name: therapist_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.therapist_settings_id_seq OWNED BY public.therapist_settings.id;


--
-- Name: therapists_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.therapists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.therapists_id_seq OWNER TO dankupfer;

--
-- Name: therapists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.therapists_id_seq OWNED BY public.therapists.id;


--
-- Name: user_credentials; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.user_credentials (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    google_permissions_granted boolean DEFAULT false,
    google_access_token text,
    google_refresh_token text,
    google_token_expires_at timestamp with time zone,
    google_permissions_granted_at timestamp with time zone,
    is_active boolean DEFAULT true,
    email_verified boolean DEFAULT false,
    email_verification_token character varying(255),
    email_verified_at timestamp with time zone,
    password_reset_token character varying(255),
    password_reset_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_login_at timestamp with time zone
);


ALTER TABLE public.user_credentials OWNER TO dankupfer;

--
-- Name: TABLE user_credentials; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.user_credentials IS 'User authentication with email/password and Google permissions';


--
-- Name: user_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.user_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_credentials_id_seq OWNER TO dankupfer;

--
-- Name: user_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.user_credentials_id_seq OWNED BY public.user_credentials.id;


--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.user_permissions (
    id integer NOT NULL,
    user_id integer,
    therapist_id integer,
    role public.user_role NOT NULL,
    granted_by integer,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    notes text
);


ALTER TABLE public.user_permissions OWNER TO dankupfer;

--
-- Name: TABLE user_permissions; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.user_permissions IS 'Role-based access control for practices';


--
-- Name: user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_permissions_id_seq OWNER TO dankupfer;

--
-- Name: user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.user_permissions_id_seq OWNED BY public.user_permissions.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: dankupfer
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer,
    session_token character varying(255) NOT NULL,
    inactive_timeout_minutes integer DEFAULT 30,
    warning_timeout_minutes integer DEFAULT 2,
    max_session_hours integer DEFAULT 8,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_activity_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    status public.session_status_auth DEFAULT 'active'::public.session_status_auth,
    terminated_at timestamp with time zone,
    termination_reason character varying(100),
    ip_address inet,
    user_agent text,
    device_fingerprint character varying(255)
);


ALTER TABLE public.user_sessions OWNER TO dankupfer;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON TABLE public.user_sessions IS 'Active user sessions with configurable timeouts';


--
-- Name: COLUMN user_sessions.inactive_timeout_minutes; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.user_sessions.inactive_timeout_minutes IS 'Configurable: 10 min prod, 2 min dev';


--
-- Name: COLUMN user_sessions.warning_timeout_minutes; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.user_sessions.warning_timeout_minutes IS 'Configurable: 1 min prod, 10 sec dev';


--
-- Name: COLUMN user_sessions.max_session_hours; Type: COMMENT; Schema: public; Owner: dankupfer
--

COMMENT ON COLUMN public.user_sessions.max_session_hours IS 'Configurable: 8 hrs prod, 1 hr dev';


--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: dankupfer
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_sessions_id_seq OWNER TO dankupfer;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dankupfer
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: app_configuration id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.app_configuration ALTER COLUMN id SET DEFAULT nextval('public.app_configuration_id_seq'::regclass);


--
-- Name: billing_periods id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.billing_periods ALTER COLUMN id SET DEFAULT nextval('public.billing_periods_id_seq'::regclass);


--
-- Name: calendar_events id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.calendar_events ALTER COLUMN id SET DEFAULT nextval('public.calendar_events_id_seq'::regclass);


--
-- Name: calendar_webhooks id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.calendar_webhooks ALTER COLUMN id SET DEFAULT nextval('public.calendar_webhooks_id_seq'::regclass);


--
-- Name: check_ins id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.check_ins ALTER COLUMN id SET DEFAULT nextval('public.check_ins_id_seq'::regclass);


--
-- Name: imported_calendar_events id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.imported_calendar_events ALTER COLUMN id SET DEFAULT nextval('public.imported_calendar_events_id_seq'::regclass);


--
-- Name: monthly_billing_payments id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_payments ALTER COLUMN id SET DEFAULT nextval('public.monthly_billing_payments_id_seq'::regclass);


--
-- Name: monthly_billing_periods id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_periods ALTER COLUMN id SET DEFAULT nextval('public.monthly_billing_periods_id_seq'::regclass);


--
-- Name: patient_billing_history id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_billing_history ALTER COLUMN id SET DEFAULT nextval('public.patient_billing_history_id_seq'::regclass);


--
-- Name: patient_matching_candidates id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_matching_candidates ALTER COLUMN id SET DEFAULT nextval('public.patient_matching_candidates_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: payment_requests id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_requests ALTER COLUMN id SET DEFAULT nextval('public.payment_requests_id_seq'::regclass);


--
-- Name: payment_status_history id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_status_history ALTER COLUMN id SET DEFAULT nextval('public.payment_status_history_id_seq'::regclass);


--
-- Name: payment_transactions id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_transactions ALTER COLUMN id SET DEFAULT nextval('public.payment_transactions_id_seq'::regclass);


--
-- Name: practice_invitations id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.practice_invitations ALTER COLUMN id SET DEFAULT nextval('public.practice_invitations_id_seq'::regclass);


--
-- Name: recurring_session_templates id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.recurring_session_templates ALTER COLUMN id SET DEFAULT nextval('public.recurring_session_templates_id_seq'::regclass);


--
-- Name: session_activity_log id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.session_activity_log ALTER COLUMN id SET DEFAULT nextval('public.session_activity_log_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: therapist_billing_history id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_billing_history ALTER COLUMN id SET DEFAULT nextval('public.therapist_billing_history_id_seq'::regclass);


--
-- Name: therapist_onboarding id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_onboarding ALTER COLUMN id SET DEFAULT nextval('public.therapist_onboarding_id_seq'::regclass);


--
-- Name: therapist_settings id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_settings ALTER COLUMN id SET DEFAULT nextval('public.therapist_settings_id_seq'::regclass);


--
-- Name: therapists id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapists ALTER COLUMN id SET DEFAULT nextval('public.therapists_id_seq'::regclass);


--
-- Name: user_credentials id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_credentials ALTER COLUMN id SET DEFAULT nextval('public.user_credentials_id_seq'::regclass);


--
-- Name: user_permissions id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_permissions ALTER COLUMN id SET DEFAULT nextval('public.user_permissions_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Data for Name: app_configuration; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.app_configuration (id, key, value, description, created_at, updated_at) FROM stdin;
1	calendar_mode	read_only	Calendar integration mode: read_only or read_write	2025-07-20 11:02:08.410259+01	2025-07-20 11:02:08.410259+01
2	app_version	1.0.0	Current application version	2025-07-20 11:02:08.410259+01	2025-07-20 11:02:08.410259+01
3	default_session_duration	60	Default session duration in minutes	2025-07-20 11:02:08.410259+01	2025-07-20 11:02:08.410259+01
4	calendar_sync_enabled	true	Whether calendar synchronization is enabled globally	2025-07-20 11:02:08.410259+01	2025-07-20 11:02:08.410259+01
15	google_permissions_scopes	https://www.googleapis.com/auth/calendar.readonly,email,profile	Google OAuth scopes requested during setup	2025-07-25 15:26:50.584329+01	2025-07-25 18:41:57.52561+01
\.


--
-- Data for Name: billing_periods; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.billing_periods (id, therapist_id, patient_id, billing_cycle, period_start_date, period_end_date, total_sessions, billable_sessions, total_amount, invoice_generated, invoice_sent, invoice_paid, invoice_date, payment_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.calendar_events (id, event_type, google_event_id, session_date, email, date) FROM stdin;
1	new	event_4_1750676400	2025-06-23 12:00:00+01	dnkupfer@gmail.com	2025-06-22 12:00:00+01
2	new	event_4_1751281200	2025-06-30 12:00:00+01	dnkupfer@gmail.com	2025-06-29 12:00:00+01
3	new	event_5_1750676400	2025-06-23 12:00:00+01	dnkupfer@gmail.com	2025-06-22 12:00:00+01
4	new	event_5_1751281200	2025-06-30 12:00:00+01	dnkupfer@gmail.com	2025-06-29 12:00:00+01
5	new	event_6_1750676400	2025-06-23 12:00:00+01	dnkupfer@gmail.com	2025-06-22 12:00:00+01
6	new	event_6_1751281200	2025-06-30 12:00:00+01	dnkupfer@gmail.com	2025-06-29 12:00:00+01
7	new	event_12_1751301000	2025-06-30 17:30:00+01	dnkupfer@gmail.com	2025-06-29 17:30:00+01
8	new	event_13_1751301000	2025-06-30 17:30:00+01	dnkupfer@gmail.com	2025-06-29 17:30:00+01
9	new	event_14_1751301000	2025-06-30 17:30:00+01	dnkupfer@gmail.com	2025-06-29 17:30:00+01
10	new	event_15_1751301000	2025-06-30 17:30:00+01	dnkupfer@gmail.com	2025-06-29 17:30:00+01
11	new	event_19_1750521600	2025-06-21 17:00:00+01	dnkupfer@gmail.com	2025-06-20 17:00:00+01
12	new	event_19_1751126400	2025-06-28 17:00:00+01	dnkupfer@gmail.com	2025-06-27 17:00:00+01
13	new	event_20_1750521600	2025-06-21 17:00:00+01	dnkupfer@gmail.com	2025-06-20 17:00:00+01
14	new	event_20_1751126400	2025-06-28 17:00:00+01	dnkupfer@gmail.com	2025-06-27 17:00:00+01
15	new	event_21_1750521600	2025-06-21 17:00:00+01	dnkupfer@gmail.com	2025-06-20 17:00:00+01
16	new	event_21_1751126400	2025-06-28 17:00:00+01	dnkupfer@gmail.com	2025-06-27 17:00:00+01
17	new	event_22_1750521600	2025-06-21 17:00:00+01	dnkupfer@gmail.com	2025-06-20 17:00:00+01
18	new	event_22_1751126400	2025-06-28 17:00:00+01	dnkupfer@gmail.com	2025-06-27 17:00:00+01
19	new	event_23_1750521600	2025-06-21 17:00:00+01	dnkupfer@gmail.com	2025-06-20 17:00:00+01
20	new	event_23_1751126400	2025-06-28 17:00:00+01	dnkupfer@gmail.com	2025-06-27 17:00:00+01
\.


--
-- Data for Name: calendar_webhooks; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.calendar_webhooks (id, channel_id, resource_id, expiration, created_at) FROM stdin;
\.


--
-- Data for Name: check_ins; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.check_ins (id, patient_id, session_id, session_date, created_by, date, status) FROM stdin;
1	4	13	2025-01-06 12:00:00+00	system	2025-01-06 12:05:00+00	compareceu
2	4	14	2025-01-13 12:00:00+00	system	2025-01-13 12:05:00+00	compareceu
3	4	15	2025-01-20 12:00:00+00	system	2025-01-20 12:05:00+00	compareceu
4	4	16	2025-01-27 12:00:00+00	system	2025-01-27 12:05:00+00	compareceu
5	4	17	2025-02-03 12:00:00+00	system	2025-02-03 12:05:00+00	compareceu
6	4	18	2025-02-10 12:00:00+00	system	2025-02-10 12:05:00+00	compareceu
7	4	19	2025-02-17 12:00:00+00	system	2025-02-17 12:05:00+00	compareceu
8	4	20	2025-02-24 12:00:00+00	system	2025-02-24 12:05:00+00	compareceu
9	4	21	2025-03-03 12:00:00+00	system	2025-03-03 12:05:00+00	compareceu
10	4	22	2025-03-10 12:00:00+00	system	2025-03-10 12:05:00+00	compareceu
11	4	23	2025-03-17 12:00:00+00	system	2025-03-17 12:05:00+00	compareceu
12	4	24	2025-03-24 12:00:00+00	system	2025-03-24 12:05:00+00	compareceu
13	4	25	2025-03-31 12:00:00+01	system	2025-03-31 12:05:00+01	compareceu
14	4	26	2025-04-07 12:00:00+01	system	2025-04-07 12:05:00+01	compareceu
15	4	27	2025-04-14 12:00:00+01	system	2025-04-14 12:05:00+01	compareceu
16	4	28	2025-04-21 12:00:00+01	system	2025-04-21 12:05:00+01	compareceu
17	4	29	2025-04-28 12:00:00+01	system	2025-04-28 12:05:00+01	compareceu
18	4	30	2025-05-05 12:00:00+01	system	2025-05-05 12:05:00+01	compareceu
19	4	31	2025-05-12 12:00:00+01	system	2025-05-12 12:05:00+01	compareceu
20	4	32	2025-05-19 12:00:00+01	system	2025-05-19 12:05:00+01	compareceu
21	4	33	2025-05-26 12:00:00+01	system	2025-05-26 12:05:00+01	compareceu
22	4	34	2025-06-02 12:00:00+01	system	2025-06-02 12:05:00+01	compareceu
23	4	35	2025-06-09 12:00:00+01	system	2025-06-09 12:05:00+01	compareceu
24	4	36	2025-06-16 12:00:00+01	system	2025-06-16 12:05:00+01	compareceu
25	4	37	2025-06-23 12:00:00+01	system	2025-06-23 12:05:00+01	compareceu
26	4	38	2025-06-30 12:00:00+01	system	2025-06-30 12:05:00+01	compareceu
27	5	39	2025-01-06 12:00:00+00	system	2025-01-06 12:05:00+00	compareceu
28	5	40	2025-01-13 12:00:00+00	system	2025-01-13 12:05:00+00	compareceu
29	5	41	2025-01-20 12:00:00+00	system	2025-01-20 12:05:00+00	compareceu
30	5	42	2025-01-27 12:00:00+00	system	2025-01-27 12:05:00+00	compareceu
31	5	43	2025-02-03 12:00:00+00	system	2025-02-03 12:05:00+00	compareceu
32	5	44	2025-02-10 12:00:00+00	system	2025-02-10 12:05:00+00	compareceu
33	5	45	2025-02-17 12:00:00+00	system	2025-02-17 12:05:00+00	compareceu
34	5	46	2025-02-24 12:00:00+00	system	2025-02-24 12:05:00+00	compareceu
35	5	47	2025-03-03 12:00:00+00	system	2025-03-03 12:05:00+00	compareceu
36	5	48	2025-03-10 12:00:00+00	system	2025-03-10 12:05:00+00	compareceu
37	5	49	2025-03-17 12:00:00+00	system	2025-03-17 12:05:00+00	compareceu
38	5	50	2025-03-24 12:00:00+00	system	2025-03-24 12:05:00+00	compareceu
39	5	51	2025-03-31 12:00:00+01	system	2025-03-31 12:05:00+01	compareceu
40	5	52	2025-04-07 12:00:00+01	system	2025-04-07 12:05:00+01	compareceu
41	5	53	2025-04-14 12:00:00+01	system	2025-04-14 12:05:00+01	compareceu
42	5	54	2025-04-21 12:00:00+01	system	2025-04-21 12:05:00+01	compareceu
43	5	55	2025-04-28 12:00:00+01	system	2025-04-28 12:05:00+01	compareceu
44	5	56	2025-05-05 12:00:00+01	system	2025-05-05 12:05:00+01	compareceu
45	5	57	2025-05-12 12:00:00+01	system	2025-05-12 12:05:00+01	compareceu
46	5	58	2025-05-19 12:00:00+01	system	2025-05-19 12:05:00+01	compareceu
47	5	59	2025-05-26 12:00:00+01	system	2025-05-26 12:05:00+01	compareceu
48	5	60	2025-06-02 12:00:00+01	system	2025-06-02 12:05:00+01	compareceu
49	5	61	2025-06-09 12:00:00+01	system	2025-06-09 12:05:00+01	compareceu
50	5	62	2025-06-16 12:00:00+01	system	2025-06-16 12:05:00+01	compareceu
51	5	63	2025-06-23 12:00:00+01	system	2025-06-23 12:05:00+01	compareceu
52	5	64	2025-06-30 12:00:00+01	system	2025-06-30 12:05:00+01	compareceu
53	6	65	2025-01-06 12:00:00+00	system	2025-01-06 12:05:00+00	compareceu
54	6	66	2025-01-13 12:00:00+00	system	2025-01-13 12:05:00+00	compareceu
55	6	67	2025-01-20 12:00:00+00	system	2025-01-20 12:05:00+00	compareceu
56	6	68	2025-01-27 12:00:00+00	system	2025-01-27 12:05:00+00	compareceu
57	6	69	2025-02-03 12:00:00+00	system	2025-02-03 12:05:00+00	compareceu
58	6	70	2025-02-10 12:00:00+00	system	2025-02-10 12:05:00+00	compareceu
59	6	71	2025-02-17 12:00:00+00	system	2025-02-17 12:05:00+00	compareceu
60	6	72	2025-02-24 12:00:00+00	system	2025-02-24 12:05:00+00	compareceu
61	6	73	2025-03-03 12:00:00+00	system	2025-03-03 12:05:00+00	compareceu
62	6	74	2025-03-10 12:00:00+00	system	2025-03-10 12:05:00+00	compareceu
63	6	75	2025-03-17 12:00:00+00	system	2025-03-17 12:05:00+00	compareceu
64	6	76	2025-03-24 12:00:00+00	system	2025-03-24 12:05:00+00	compareceu
65	6	77	2025-03-31 12:00:00+01	system	2025-03-31 12:05:00+01	compareceu
66	6	78	2025-04-07 12:00:00+01	system	2025-04-07 12:05:00+01	compareceu
67	6	79	2025-04-14 12:00:00+01	system	2025-04-14 12:05:00+01	compareceu
68	6	80	2025-04-21 12:00:00+01	system	2025-04-21 12:05:00+01	compareceu
69	6	81	2025-04-28 12:00:00+01	system	2025-04-28 12:05:00+01	compareceu
70	6	82	2025-05-05 12:00:00+01	system	2025-05-05 12:05:00+01	compareceu
71	6	83	2025-05-12 12:00:00+01	system	2025-05-12 12:05:00+01	compareceu
72	6	84	2025-05-19 12:00:00+01	system	2025-05-19 12:05:00+01	compareceu
73	6	85	2025-05-26 12:00:00+01	system	2025-05-26 12:05:00+01	compareceu
74	6	86	2025-06-02 12:00:00+01	system	2025-06-02 12:05:00+01	compareceu
75	6	87	2025-06-09 12:00:00+01	system	2025-06-09 12:05:00+01	compareceu
76	6	88	2025-06-16 12:00:00+01	system	2025-06-16 12:05:00+01	compareceu
77	6	89	2025-06-23 12:00:00+01	system	2025-06-23 12:05:00+01	compareceu
78	6	90	2025-06-30 12:00:00+01	system	2025-06-30 12:05:00+01	compareceu
79	7	91	2025-01-15 14:00:00+00	system	2025-01-15 14:05:00+00	compareceu
80	7	92	2025-01-29 14:00:00+00	system	2025-01-29 14:05:00+00	compareceu
81	7	93	2025-02-12 14:00:00+00	system	2025-02-12 14:05:00+00	compareceu
82	7	94	2025-02-26 14:00:00+00	system	2025-02-26 14:05:00+00	compareceu
83	7	95	2025-03-12 14:00:00+00	system	2025-03-12 14:05:00+00	compareceu
84	7	96	2025-03-26 14:00:00+00	system	2025-03-26 14:05:00+00	compareceu
85	7	97	2025-04-09 14:00:00+01	system	2025-04-09 14:05:00+01	compareceu
86	7	98	2025-04-23 14:00:00+01	system	2025-04-23 14:05:00+01	compareceu
87	7	99	2025-05-07 14:00:00+01	system	2025-05-07 14:05:00+01	compareceu
88	7	100	2025-05-21 14:00:00+01	system	2025-05-21 14:05:00+01	compareceu
89	7	101	2025-06-04 14:00:00+01	system	2025-06-04 14:05:00+01	compareceu
90	7	102	2025-06-18 14:00:00+01	system	2025-06-18 14:05:00+01	compareceu
91	8	103	2025-01-15 14:00:00+00	system	2025-01-15 14:05:00+00	compareceu
92	8	104	2025-01-29 14:00:00+00	system	2025-01-29 14:05:00+00	compareceu
93	8	105	2025-02-12 14:00:00+00	system	2025-02-12 14:05:00+00	compareceu
94	8	106	2025-02-26 14:00:00+00	system	2025-02-26 14:05:00+00	compareceu
95	8	107	2025-03-12 14:00:00+00	system	2025-03-12 14:05:00+00	compareceu
96	8	108	2025-03-26 14:00:00+00	system	2025-03-26 14:05:00+00	compareceu
97	8	109	2025-04-09 14:00:00+01	system	2025-04-09 14:05:00+01	compareceu
98	8	110	2025-04-23 14:00:00+01	system	2025-04-23 14:05:00+01	compareceu
99	8	111	2025-05-07 14:00:00+01	system	2025-05-07 14:05:00+01	compareceu
100	8	112	2025-05-21 14:00:00+01	system	2025-05-21 14:05:00+01	compareceu
101	8	113	2025-06-04 14:00:00+01	system	2025-06-04 14:05:00+01	compareceu
102	8	114	2025-06-18 14:00:00+01	system	2025-06-18 14:05:00+01	compareceu
103	9	115	2025-01-15 14:00:00+00	system	2025-01-15 14:05:00+00	compareceu
104	9	116	2025-01-29 14:00:00+00	system	2025-01-29 14:05:00+00	compareceu
105	9	117	2025-02-12 14:00:00+00	system	2025-02-12 14:05:00+00	compareceu
106	9	118	2025-02-26 14:00:00+00	system	2025-02-26 14:05:00+00	compareceu
107	9	119	2025-03-12 14:00:00+00	system	2025-03-12 14:05:00+00	compareceu
108	9	120	2025-03-26 14:00:00+00	system	2025-03-26 14:05:00+00	compareceu
109	9	121	2025-04-09 14:00:00+01	system	2025-04-09 14:05:00+01	compareceu
110	9	122	2025-04-23 14:00:00+01	system	2025-04-23 14:05:00+01	compareceu
111	9	123	2025-05-07 14:00:00+01	system	2025-05-07 14:05:00+01	compareceu
112	9	124	2025-05-21 14:00:00+01	system	2025-05-21 14:05:00+01	compareceu
113	9	125	2025-06-04 14:00:00+01	system	2025-06-04 14:05:00+01	compareceu
114	9	126	2025-06-18 14:00:00+01	system	2025-06-18 14:05:00+01	compareceu
115	10	127	2025-01-15 14:00:00+00	system	2025-01-15 14:05:00+00	compareceu
116	10	128	2025-01-29 14:00:00+00	system	2025-01-29 14:05:00+00	compareceu
117	10	129	2025-02-12 14:00:00+00	system	2025-02-12 14:05:00+00	compareceu
118	10	130	2025-02-26 14:00:00+00	system	2025-02-26 14:05:00+00	compareceu
119	10	131	2025-03-12 14:00:00+00	system	2025-03-12 14:05:00+00	compareceu
120	10	132	2025-03-26 14:00:00+00	system	2025-03-26 14:05:00+00	compareceu
121	10	133	2025-04-09 14:00:00+01	system	2025-04-09 14:05:00+01	compareceu
122	10	134	2025-04-23 14:00:00+01	system	2025-04-23 14:05:00+01	compareceu
123	10	135	2025-05-07 14:00:00+01	system	2025-05-07 14:05:00+01	compareceu
124	10	136	2025-05-21 14:00:00+01	system	2025-05-21 14:05:00+01	compareceu
125	10	137	2025-06-04 14:00:00+01	system	2025-06-04 14:05:00+01	compareceu
126	10	138	2025-06-18 14:00:00+01	system	2025-06-18 14:05:00+01	compareceu
127	11	139	2025-01-15 14:00:00+00	system	2025-01-15 14:05:00+00	compareceu
128	11	140	2025-01-29 14:00:00+00	system	2025-01-29 14:05:00+00	compareceu
129	11	141	2025-02-12 14:00:00+00	system	2025-02-12 14:05:00+00	compareceu
130	11	142	2025-02-26 14:00:00+00	system	2025-02-26 14:05:00+00	compareceu
131	11	143	2025-03-12 14:00:00+00	system	2025-03-12 14:05:00+00	compareceu
132	11	144	2025-03-26 14:00:00+00	system	2025-03-26 14:05:00+00	compareceu
133	11	145	2025-04-09 14:00:00+01	system	2025-04-09 14:05:00+01	compareceu
134	11	146	2025-04-23 14:00:00+01	system	2025-04-23 14:05:00+01	compareceu
135	11	147	2025-05-07 14:00:00+01	system	2025-05-07 14:05:00+01	compareceu
136	11	148	2025-05-21 14:00:00+01	system	2025-05-21 14:05:00+01	compareceu
137	11	149	2025-06-04 14:00:00+01	system	2025-06-04 14:05:00+01	compareceu
138	11	150	2025-06-18 14:00:00+01	system	2025-06-18 14:05:00+01	compareceu
139	12	151	2025-02-10 17:30:00+00	system	2025-02-10 17:35:00+00	compareceu
140	12	152	2025-03-10 17:30:00+00	system	2025-03-10 17:35:00+00	compareceu
141	12	153	2025-04-07 17:30:00+01	system	2025-04-07 17:35:00+01	compareceu
142	12	154	2025-05-05 17:30:00+01	system	2025-05-05 17:35:00+01	compareceu
143	12	155	2025-06-02 17:30:00+01	system	2025-06-02 17:35:00+01	compareceu
144	12	156	2025-06-30 17:30:00+01	system	2025-06-30 17:35:00+01	compareceu
145	13	157	2025-02-10 17:30:00+00	system	2025-02-10 17:35:00+00	compareceu
146	13	158	2025-03-10 17:30:00+00	system	2025-03-10 17:35:00+00	compareceu
147	13	159	2025-04-07 17:30:00+01	system	2025-04-07 17:35:00+01	compareceu
148	13	160	2025-05-05 17:30:00+01	system	2025-05-05 17:35:00+01	compareceu
149	13	161	2025-06-02 17:30:00+01	system	2025-06-02 17:35:00+01	compareceu
150	13	162	2025-06-30 17:30:00+01	system	2025-06-30 17:35:00+01	compareceu
151	14	163	2025-02-10 17:30:00+00	system	2025-02-10 17:35:00+00	compareceu
152	14	164	2025-03-10 17:30:00+00	system	2025-03-10 17:35:00+00	compareceu
153	14	165	2025-04-07 17:30:00+01	system	2025-04-07 17:35:00+01	compareceu
154	14	166	2025-05-05 17:30:00+01	system	2025-05-05 17:35:00+01	compareceu
155	14	167	2025-06-02 17:30:00+01	system	2025-06-02 17:35:00+01	compareceu
156	14	168	2025-06-30 17:30:00+01	system	2025-06-30 17:35:00+01	compareceu
157	15	169	2025-02-10 17:30:00+00	system	2025-02-10 17:35:00+00	compareceu
158	15	170	2025-03-10 17:30:00+00	system	2025-03-10 17:35:00+00	compareceu
159	15	171	2025-04-07 17:30:00+01	system	2025-04-07 17:35:00+01	compareceu
160	15	172	2025-05-05 17:30:00+01	system	2025-05-05 17:35:00+01	compareceu
161	15	173	2025-06-02 17:30:00+01	system	2025-06-02 17:35:00+01	compareceu
162	15	174	2025-06-30 17:30:00+01	system	2025-06-30 17:35:00+01	compareceu
163	19	175	2025-04-05 17:00:00+01	system	2025-04-05 17:05:00+01	compareceu
164	19	176	2025-04-12 17:00:00+01	system	2025-04-12 17:05:00+01	compareceu
165	19	177	2025-04-19 17:00:00+01	system	2025-04-19 17:05:00+01	compareceu
166	19	178	2025-04-26 17:00:00+01	system	2025-04-26 17:05:00+01	compareceu
167	19	179	2025-05-03 17:00:00+01	system	2025-05-03 17:05:00+01	compareceu
168	19	180	2025-05-10 17:00:00+01	system	2025-05-10 17:05:00+01	compareceu
169	19	181	2025-05-17 17:00:00+01	system	2025-05-17 17:05:00+01	compareceu
170	19	182	2025-05-24 17:00:00+01	system	2025-05-24 17:05:00+01	compareceu
171	19	183	2025-05-31 17:00:00+01	system	2025-05-31 17:05:00+01	compareceu
172	19	184	2025-06-07 17:00:00+01	system	2025-06-07 17:05:00+01	compareceu
173	19	185	2025-06-14 17:00:00+01	system	2025-06-14 17:05:00+01	compareceu
174	19	186	2025-06-21 17:00:00+01	system	2025-06-21 17:05:00+01	compareceu
175	19	187	2025-06-28 17:00:00+01	system	2025-06-28 17:05:00+01	compareceu
176	20	188	2025-04-05 17:00:00+01	system	2025-04-05 17:05:00+01	compareceu
177	20	189	2025-04-12 17:00:00+01	system	2025-04-12 17:05:00+01	compareceu
178	20	190	2025-04-19 17:00:00+01	system	2025-04-19 17:05:00+01	compareceu
179	20	191	2025-04-26 17:00:00+01	system	2025-04-26 17:05:00+01	compareceu
180	20	192	2025-05-03 17:00:00+01	system	2025-05-03 17:05:00+01	compareceu
181	20	193	2025-05-10 17:00:00+01	system	2025-05-10 17:05:00+01	compareceu
182	20	194	2025-05-17 17:00:00+01	system	2025-05-17 17:05:00+01	compareceu
183	20	195	2025-05-24 17:00:00+01	system	2025-05-24 17:05:00+01	compareceu
184	20	196	2025-05-31 17:00:00+01	system	2025-05-31 17:05:00+01	compareceu
185	20	197	2025-06-07 17:00:00+01	system	2025-06-07 17:05:00+01	compareceu
186	20	198	2025-06-14 17:00:00+01	system	2025-06-14 17:05:00+01	compareceu
187	20	199	2025-06-21 17:00:00+01	system	2025-06-21 17:05:00+01	compareceu
188	20	200	2025-06-28 17:00:00+01	system	2025-06-28 17:05:00+01	compareceu
189	21	201	2025-04-05 17:00:00+01	system	2025-04-05 17:05:00+01	compareceu
190	21	202	2025-04-12 17:00:00+01	system	2025-04-12 17:05:00+01	compareceu
191	21	203	2025-04-19 17:00:00+01	system	2025-04-19 17:05:00+01	compareceu
192	21	204	2025-04-26 17:00:00+01	system	2025-04-26 17:05:00+01	compareceu
193	21	205	2025-05-03 17:00:00+01	system	2025-05-03 17:05:00+01	compareceu
194	21	206	2025-05-10 17:00:00+01	system	2025-05-10 17:05:00+01	compareceu
195	21	207	2025-05-17 17:00:00+01	system	2025-05-17 17:05:00+01	compareceu
196	21	208	2025-05-24 17:00:00+01	system	2025-05-24 17:05:00+01	compareceu
197	21	209	2025-05-31 17:00:00+01	system	2025-05-31 17:05:00+01	compareceu
198	21	210	2025-06-07 17:00:00+01	system	2025-06-07 17:05:00+01	compareceu
199	21	211	2025-06-14 17:00:00+01	system	2025-06-14 17:05:00+01	compareceu
200	21	212	2025-06-21 17:00:00+01	system	2025-06-21 17:05:00+01	compareceu
201	21	213	2025-06-28 17:00:00+01	system	2025-06-28 17:05:00+01	compareceu
202	22	214	2025-04-05 17:00:00+01	system	2025-04-05 17:05:00+01	compareceu
203	22	215	2025-04-12 17:00:00+01	system	2025-04-12 17:05:00+01	compareceu
204	22	216	2025-04-19 17:00:00+01	system	2025-04-19 17:05:00+01	compareceu
205	22	217	2025-04-26 17:00:00+01	system	2025-04-26 17:05:00+01	compareceu
206	22	218	2025-05-03 17:00:00+01	system	2025-05-03 17:05:00+01	compareceu
207	22	219	2025-05-10 17:00:00+01	system	2025-05-10 17:05:00+01	compareceu
208	22	220	2025-05-17 17:00:00+01	system	2025-05-17 17:05:00+01	compareceu
209	22	221	2025-05-24 17:00:00+01	system	2025-05-24 17:05:00+01	compareceu
210	22	222	2025-05-31 17:00:00+01	system	2025-05-31 17:05:00+01	compareceu
211	22	223	2025-06-07 17:00:00+01	system	2025-06-07 17:05:00+01	compareceu
212	22	224	2025-06-14 17:00:00+01	system	2025-06-14 17:05:00+01	compareceu
213	22	225	2025-06-21 17:00:00+01	system	2025-06-21 17:05:00+01	compareceu
214	22	226	2025-06-28 17:00:00+01	system	2025-06-28 17:05:00+01	compareceu
215	23	227	2025-04-05 17:00:00+01	system	2025-04-05 17:05:00+01	compareceu
216	23	228	2025-04-12 17:00:00+01	system	2025-04-12 17:05:00+01	compareceu
217	23	229	2025-04-19 17:00:00+01	system	2025-04-19 17:05:00+01	compareceu
218	23	230	2025-04-26 17:00:00+01	system	2025-04-26 17:05:00+01	compareceu
219	23	231	2025-05-03 17:00:00+01	system	2025-05-03 17:05:00+01	compareceu
220	23	232	2025-05-10 17:00:00+01	system	2025-05-10 17:05:00+01	compareceu
221	23	233	2025-05-17 17:00:00+01	system	2025-05-17 17:05:00+01	compareceu
222	23	234	2025-05-24 17:00:00+01	system	2025-05-24 17:05:00+01	compareceu
223	23	235	2025-05-31 17:00:00+01	system	2025-05-31 17:05:00+01	compareceu
224	23	236	2025-06-07 17:00:00+01	system	2025-06-07 17:05:00+01	compareceu
225	23	237	2025-06-14 17:00:00+01	system	2025-06-14 17:05:00+01	compareceu
226	23	238	2025-06-21 17:00:00+01	system	2025-06-21 17:05:00+01	compareceu
227	23	239	2025-06-28 17:00:00+01	system	2025-06-28 17:05:00+01	compareceu
\.


--
-- Data for Name: imported_calendar_events; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.imported_calendar_events (id, therapist_id, google_event_id, original_summary, description, start_time, end_time, attendees_emails, is_therapy_session, is_recurring, recurring_rule, linked_patient_id, matched_patient_name, processed, import_batch_id, created_at, processed_at) FROM stdin;
\.


--
-- Data for Name: monthly_billing_payments; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.monthly_billing_payments (id, billing_period_id, therapist_id, patient_id, amount, payment_method, payment_date, reference_number, recorded_by, notes, created_at, updated_at) FROM stdin;
2	44	2	5	44000.00	pix	2025-07-22 01:00:00+01	\N	dnkupfer@gmail.com	\N	2025-07-22 19:19:55.469273+01	2025-07-22 19:19:55.469273+01
\.


--
-- Data for Name: monthly_billing_periods; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.monthly_billing_periods (id, therapist_id, patient_id, billing_year, billing_month, session_count, total_amount, session_snapshots, processed_at, processed_by, status, can_be_voided, created_at, voided_at, voided_by, void_reason) FROM stdin;
4	2	5	2025	4	3	66000.00	[{"date": "2025-04-01", "time": "14:00", "duration": 60, "patientName": "João Pedro Oliveira", "googleEventId": "foqcfr8ms8im9ps6m5l64h0f4c"}, {"date": "2025-04-15", "time": "14:00", "duration": 60, "patientName": "João Pedro Oliveira", "googleEventId": "fvk0n586fblcmfoeeflch0ncsc"}, {"date": "2025-04-29", "time": "14:00", "duration": 60, "patientName": "João Pedro Oliveira", "googleEventId": "njaertua4hgq8bvadepb8nbcgk"}]	2025-07-20 23:06:38.342073+01	dnkupfer@gmail.com	processed	t	2025-07-20 23:06:38.342073+01	\N	\N	\N
45	2	4	2025	5	4	100000.00	[{"date": "2025-05-05", "time": "10:00", "duration": 60, "patientName": "Maria Silva Santos", "googleEventId": "be525nb938vi65fnfq30oa53ro"}, {"date": "2025-05-12", "time": "10:00", "duration": 60, "patientName": "Maria Silva Santos", "googleEventId": "46ltqavit5frr24ujpeql0ki60"}, {"date": "2025-05-19", "time": "10:00", "duration": 60, "patientName": "Maria Silva Santos", "googleEventId": "u9ur8n0cllq3kfnis3p4nrirf8"}, {"date": "2025-05-26", "time": "10:00", "duration": 60, "patientName": "Maria Silva Santos", "googleEventId": "c0tvh7io6v5t1s39qoioqkg2bo"}]	2025-07-20 23:56:52.144087+01	dnkupfer@gmail.com	processed	t	2025-07-20 23:56:52.144087+01	\N	\N	\N
51	3	24	2025	7	1	30000.00	[{"date": "2025-07-10", "time": "18:00", "duration": 60, "patientName": "ZPK", "googleEventId": "351v2aj02b4r8nkdc5eitlhbp1"}]	2025-07-21 22:41:44.338498+01	mcmkupfer@gmail.com	processed	t	2025-07-21 22:41:44.338498+01	\N	\N	\N
44	2	5	2025	5	2	44000.00	[{"date": "2025-05-13", "time": "14:00", "duration": 60, "patientName": "João Pedro Oliveira", "googleEventId": "t2c2n9e1p4ame76nfqq215nmm8"}, {"date": "2025-05-27", "time": "14:00", "duration": 60, "patientName": "João Pedro Oliveira", "googleEventId": "km8l1frhorhkprgvjj8nput10g"}]	2025-07-20 23:56:38.343009+01	dnkupfer@gmail.com	paid	f	2025-07-20 23:56:38.343009+01	\N	\N	\N
\.


--
-- Data for Name: patient_billing_history; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.patient_billing_history (id, patient_id, therapist_id, billing_cycle, session_price, effective_from_date, effective_until_date, reason_for_change, created_by, created_at, notes) FROM stdin;
\.


--
-- Data for Name: patient_matching_candidates; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.patient_matching_candidates (id, therapist_id, import_batch_id, extracted_name, name_variations, email_addresses, event_count, first_session_date, latest_session_date, suggested_therapy_start_date, suggested_billing_start_date, confidence_score, manual_review_needed, created_patient_id, created_at) FROM stdin;
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.patients (id, nome, email, telefone, cpf, nota, preco, therapist_id, therapy_start_date, lv_notas_billing_start_date, session_price, recurring_pattern, notes, created_at) FROM stdin;
1	Ana Silva	ana.silva@email.com	(11) 98765-4321	\N	f	15000.00	1	2024-01-15	2025-06-20	15000.00	weekly	Paciente regular, sessões às terças-feiras às 14h	2025-07-20 11:02:08.461708+01
2	Carlos Oliveira	carlos.oliveira@email.com	(11) 97654-3210	\N	f	18000.00	1	2024-02-01	2025-06-30	18000.00	weekly	Sessões às quintas-feiras às 16h	2025-07-20 11:02:08.461708+01
3	Maria Santos	maria.santos@email.com	(11) 96543-2109	\N	f	16000.00	1	2024-03-01	2025-07-10	16000.00	bi-weekly	Sessões quinzenais, flexibilidade de horário	2025-07-20 11:02:08.461708+01
7	Carlos Eduardo Lima	carlos.lima@email.com	+5511987001004	\N	f	180.00	2	\N	2025-01-01	\N	\N	\N	2025-01-10 14:00:00+00
8	Fernanda Costa Rodrigues	fernanda.costa@gmail.com	+5511987001005	\N	f	160.00	2	\N	2025-01-01	\N	\N	\N	2025-01-15 19:00:00+00
9	Rafael Santos Almeida	rafael.almeida@email.com	+5511987001006	\N	t	170.00	2	\N	2025-01-01	\N	\N	\N	2025-01-20 16:30:00+00
10	Juliana Pereira Silva	juliana.pereira@outlook.com	+5511987001007	\N	f	150.00	2	\N	2025-01-01	\N	\N	\N	2025-01-25 18:00:00+00
11	Lucas Martins Souza	lucas.martins@gmail.com	+5511987001008	\N	f	180.00	2	\N	2025-01-01	\N	\N	\N	2025-02-01 13:00:00+00
12	Camila Barbosa Santos	camila.barbosa@email.com	+5511987001009	\N	t	160.00	2	\N	2025-02-01	\N	\N	\N	2025-02-05 17:30:00+00
13	Gabriel Henrique Costa	gabriel.costa@gmail.com	+5511987001010	\N	f	170.00	2	\N	2025-02-01	\N	\N	\N	2025-02-10 14:30:00+00
14	Bruna Oliveira Lima	bruna.oliveira@email.com	+5511987001011	\N	f	140.00	2	\N	2025-02-01	\N	\N	\N	2025-02-15 12:30:00+00
15	Thiago Rodrigues Silva	thiago.rodrigues@outlook.com	+5511987001012	\N	t	130.00	2	\N	2025-02-01	\N	\N	\N	2025-02-20 19:30:00+00
17	Pedro Henrique Alves	pedro.alves@email.com	+5511987001014	\N	f	140.00	2	\N	2025-03-01	\N	\N	\N	2025-03-05 20:00:00+00
18	Larissa Costa Martins	larissa.martins@outlook.com	+5511987001015	\N	t	130.00	2	\N	2025-03-01	\N	\N	\N	2025-03-10 15:00:00+00
19	Diego Santos Lima	diego.lima@gmail.com	+5511987001016	\N	f	190.00	2	\N	2025-04-01	\N	\N	\N	2025-04-01 17:00:00+01
20	Natália Ferreira Costa	natalia.ferreira@email.com	+5511987001017	\N	f	160.00	2	\N	2025-04-15	\N	\N	\N	2025-04-15 19:30:00+01
21	Henrique Oliveira Santos	henrique.santos@outlook.com	+5511987001018	\N	t	180.00	2	\N	2025-05-01	\N	\N	\N	2025-05-01 14:30:00+01
22	Beatriz Lima Rodrigues	beatriz.lima@gmail.com	+5511987001019	\N	f	170.00	2	\N	2025-05-15	\N	\N	\N	2025-05-15 18:00:00+01
23	Mateus Costa Almeida	mateus.almeida@email.com	+5511987001020	\N	f	200.00	2	\N	2025-06-01	\N	\N	\N	2025-06-01 20:00:00+01
6	Ana Carolina Ferreira	ana.ferreira@outlook.com	5511987001003	123.456.789-09	t	20000.00	2	\N	2025-01-01	\N	\N	\N	2025-01-05 17:00:00+00
4	Maria Silva Santos	maria.santos@hotmail.com	5511987001001	111.444.777-35	f	25000.00	2	\N	2025-01-01	\N	\N	\N	2024-12-15 12:00:00+00
5	João Pedro Oliveira	joao.oliveira@gmail.com	5511987001002	\N	f	22000.00	2	\N	2025-01-01	\N	\N	\N	2024-12-20 13:30:00+00
16	Amanda Santos Ferreira	amanda.santos@gmail.com	5511987001013	290.460.048-56	f	29900.00	2	\N	2025-03-01	\N	\N	\N	2025-03-01 11:30:00+00
24	ZPK	zpkupfer@uol.com.br	1234567890	\N	f	30000.00	3	\N	2025-01-01	\N	\N	\N	2025-07-21 22:18:56.647696+01
25	Tassio Capuani	tassiocapuani@gmail.com	1234567890	\N	f	30000.00	3	\N	2025-01-01	\N	\N	\N	2025-07-23 09:58:45.221851+01
\.


--
-- Data for Name: payment_requests; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.payment_requests (id, patient_id, therapist_id, session_ids, total_amount, request_date, request_type, whatsapp_sent, whatsapp_message, response_received, response_date, created_at) FROM stdin;
1	4	2	{13,14,15}	6500.00	2025-07-17 00:00:00+01	invoice	t	\N	f	\N	2025-07-20 11:02:08.838078+01
2	5	2	{39,40,41}	5720.00	2025-07-17 00:00:00+01	invoice	t	\N	f	\N	2025-07-20 11:02:08.838078+01
3	7	2	{91,92,93}	2160.00	2025-07-17 00:00:00+01	invoice	t	\N	f	\N	2025-07-20 11:02:08.838078+01
4	6	2	{65,66}	5200.00	2025-07-08 00:00:00+01	invoice	t	\N	f	\N	2025-07-20 11:02:08.844552+01
5	8	2	{103,104}	1920.00	2025-07-08 00:00:00+01	invoice	t	\N	f	\N	2025-07-20 11:02:08.844552+01
\.


--
-- Data for Name: payment_status_history; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.payment_status_history (id, session_id, old_status, new_status, changed_by, changed_at, reason, payment_transaction_id) FROM stdin;
\.


--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.payment_transactions (id, session_id, patient_id, therapist_id, amount, payment_method, payment_date, reference_number, notes, created_by, created_at, updated_at) FROM stdin;
1	1	1	1	15000.00	pix	2025-07-16 14:00:00+01	REF-422711	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
2	2	1	1	15000.00	bank_transfer	2025-07-09 14:00:00+01	REF-122418	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
3	6	2	1	18000.00	pix	2025-07-11 16:00:00+01	REF-258884	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
4	8	3	1	16000.00	pix	2025-07-19 10:00:00+01	REF-086938	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
5	9	3	1	16000.00	pix	2025-07-17 10:00:00+01	REF-461551	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
6	10	3	1	16000.00	pix	2025-07-15 10:00:00+01	REF-906546	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
7	11	3	1	16000.00	pix	2025-07-13 10:00:00+01	REF-822886	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
8	12	3	1	16000.00	bank_transfer	2025-07-11 10:00:00+01	REF-197773	Pagamento automático de teste	system	2025-07-20 11:02:08.477708+01	2025-07-20 11:02:08.477708+01
9	138	10	2	150.00	pix	2025-07-19 00:00:00+01	PIX390148	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
10	150	11	2	180.00	pix	2025-07-19 00:00:00+01	PIX379855	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
11	126	9	2	170.00	pix	2025-07-19 00:00:00+01	PIX318807	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
12	125	9	2	170.00	pix	2025-07-19 00:00:00+01	PIX424036	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
13	149	11	2	180.00	pix	2025-07-19 00:00:00+01	PIX661111	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
14	137	10	2	150.00	pix	2025-07-19 00:00:00+01	PIX055843	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
15	136	10	2	150.00	pix	2025-07-19 00:00:00+01	PIX902395	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
16	148	11	2	180.00	pix	2025-07-19 00:00:00+01	PIX393897	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
17	124	9	2	170.00	pix	2025-07-19 00:00:00+01	PIX652954	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
18	135	10	2	150.00	pix	2025-07-19 00:00:00+01	PIX872234	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
19	123	9	2	170.00	pix	2025-07-19 00:00:00+01	PIX840289	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
20	147	11	2	180.00	pix	2025-07-19 00:00:00+01	PIX008942	\N	system	2025-07-20 11:02:08.850816+01	2025-07-20 11:02:08.850816+01
\.


--
-- Data for Name: practice_invitations; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.practice_invitations (id, therapist_id, invited_by, invited_email, invited_role, invitation_token, personal_message, permissions_description, status, created_at, expires_at, responded_at, accepted_by, decline_reason) FROM stdin;
\.


--
-- Data for Name: recurring_session_templates; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.recurring_session_templates (id, therapist_id, patient_id, day_of_week, start_time, duration_minutes, frequency, effective_from, effective_until, status, created_from_import, import_batch_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session_activity_log; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.session_activity_log (id, session_id, user_id, activity_type, endpoint, ip_address, user_agent, "timestamp", metadata) FROM stdin;
1	1	3	login	\N	::1	curl/8.7.1	2025-07-25 18:54:58.35349+01	{}
2	2	3	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 19:32:25.648909+01	{}
3	3	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 19:50:30.207381+01	{}
4	4	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:09:26.057455+01	{}
5	5	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:20:34.669942+01	{}
6	6	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:22:03.754614+01	{}
7	7	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:23:03.145446+01	{}
8	8	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:25:03.015882+01	{}
9	9	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:25:17.905237+01	{}
10	10	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:28:16.956185+01	{}
11	11	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:30:45.047771+01	{}
12	12	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:31:07.5027+01	{}
13	13	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:31:48.467959+01	{}
14	14	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:38:01.596396+01	{}
15	15	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:38:06.99138+01	{}
16	16	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:39:15.340163+01	{}
17	17	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 20:41:25.758484+01	{}
18	18	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 21:32:59.879781+01	{}
19	19	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 21:34:34.296865+01	{}
20	20	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 21:43:56.585886+01	{}
21	21	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 22:13:42.37261+01	{}
22	21	\N	logout	\N	\N	\N	2025-07-25 22:13:59.489438+01	{"reason": "logout", "terminated_at": "2025-07-25T21:13:59.489Z"}
23	22	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 22:14:04.041441+01	{}
24	23	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-25 22:21:34.891616+01	{}
25	23	4	session_extended	\N	\N	\N	2025-07-25 22:25:57.054242+01	{"extended_at": "2025-07-25T22:25:57.054242+01:00"}
26	23	\N	logout	\N	\N	\N	2025-07-25 22:30:09.920802+01	{"reason": "logout", "terminated_at": "2025-07-25T21:30:09.919Z"}
27	24	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 10:16:53.242005+01	{}
28	25	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 10:17:42.050324+01	{}
29	26	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 10:19:50.143402+01	{}
30	27	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:09:43.878151+01	{}
31	28	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:11:13.225631+01	{}
32	29	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:20:03.998144+01	{}
33	30	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:20:42.169502+01	{}
34	31	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:28:46.715557+01	{}
35	32	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:30:55.004515+01	{}
36	32	\N	logout	\N	\N	\N	2025-07-26 11:31:56.783425+01	{"reason": "logout", "terminated_at": "2025-07-26T10:31:56.783Z"}
37	33	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:32:00.82044+01	{}
38	34	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:32:22.856521+01	{}
39	35	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:43:00.691584+01	{}
40	35	\N	logout	\N	\N	\N	2025-07-26 11:46:28.046069+01	{"reason": "logout", "terminated_at": "2025-07-26T10:46:28.045Z"}
133	86	4	session_extended	\N	\N	\N	2025-07-26 16:11:37.550529+01	{"extended_at": "2025-07-26T16:11:37.550529+01:00"}
41	36	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:46:35.133015+01	{}
42	37	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 11:59:15.015067+01	{}
43	37	\N	logout	\N	\N	\N	2025-07-26 12:01:07.830028+01	{"reason": "logout", "terminated_at": "2025-07-26T11:01:07.829Z"}
44	38	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:01:11.2926+01	{}
45	38	\N	logout	\N	\N	\N	2025-07-26 12:01:34.388287+01	{"reason": "logout", "terminated_at": "2025-07-26T11:01:34.387Z"}
46	39	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:01:37.763195+01	{}
47	39	\N	logout	\N	\N	\N	2025-07-26 12:05:08.439114+01	{"reason": "logout", "terminated_at": "2025-07-26T11:05:08.438Z"}
48	40	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:05:15.46619+01	{}
49	40	4	session_extended	\N	\N	\N	2025-07-26 12:10:01.012416+01	{"extended_at": "2025-07-26T12:10:01.012416+01:00"}
50	40	\N	logout	\N	\N	\N	2025-07-26 12:14:21.389432+01	{"reason": "logout", "terminated_at": "2025-07-26T11:14:21.389Z"}
51	41	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:14:24.493546+01	{}
52	41	\N	logout	\N	\N	\N	2025-07-26 12:14:36.605654+01	{"reason": "logout", "terminated_at": "2025-07-26T11:14:36.605Z"}
53	42	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:14:39.316841+01	{}
54	42	\N	logout	\N	\N	\N	2025-07-26 12:18:18.47427+01	{"reason": "logout", "terminated_at": "2025-07-26T11:18:18.474Z"}
55	43	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:41:34.608799+01	{}
56	43	\N	logout	\N	\N	\N	2025-07-26 12:43:04.178467+01	{"reason": "logout", "terminated_at": "2025-07-26T11:43:04.178Z"}
57	44	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:43:12.845371+01	{}
58	45	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:46:53.083718+01	{}
59	45	\N	logout	\N	\N	\N	2025-07-26 12:47:07.741464+01	{"reason": "logout", "terminated_at": "2025-07-26T11:47:07.741Z"}
60	46	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:47:13.668877+01	{}
61	46	\N	logout	\N	\N	\N	2025-07-26 12:47:30.598265+01	{"reason": "logout", "terminated_at": "2025-07-26T11:47:30.598Z"}
62	47	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:47:33.661828+01	{}
63	48	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:57:58.272037+01	{}
64	48	\N	logout	\N	\N	\N	2025-07-26 12:58:04.241342+01	{"reason": "logout", "terminated_at": "2025-07-26T11:58:04.241Z"}
65	49	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:58:07.402186+01	{}
66	49	\N	logout	\N	\N	\N	2025-07-26 12:59:03.713347+01	{"reason": "logout", "terminated_at": "2025-07-26T11:59:03.713Z"}
67	50	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 12:59:06.533275+01	{}
68	50	\N	logout	\N	\N	\N	2025-07-26 13:02:57.531914+01	{"reason": "logout", "terminated_at": "2025-07-26T12:02:57.531Z"}
69	51	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:03:00.268545+01	{}
70	52	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:41:43.130575+01	{}
71	53	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:47:25.278824+01	{}
72	53	\N	logout	\N	\N	\N	2025-07-26 13:48:44.439303+01	{"reason": "logout", "terminated_at": "2025-07-26T12:48:44.439Z"}
73	54	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:48:47.718886+01	{}
74	54	\N	logout	\N	\N	\N	2025-07-26 13:48:52.516592+01	{"reason": "logout", "terminated_at": "2025-07-26T12:48:52.516Z"}
75	55	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:48:56.471359+01	{}
76	55	\N	logout	\N	\N	\N	2025-07-26 13:49:47.861288+01	{"reason": "logout", "terminated_at": "2025-07-26T12:49:47.861Z"}
77	56	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:49:50.633017+01	{}
78	56	\N	logout	\N	\N	\N	2025-07-26 13:51:12.806883+01	{"reason": "logout", "terminated_at": "2025-07-26T12:51:12.806Z"}
79	57	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:51:15.696391+01	{}
80	57	\N	logout	\N	\N	\N	2025-07-26 13:54:19.063232+01	{"reason": "logout", "terminated_at": "2025-07-26T12:54:19.062Z"}
81	58	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:54:26.006482+01	{}
82	58	\N	logout	\N	\N	\N	2025-07-26 13:54:40.00376+01	{"reason": "logout", "terminated_at": "2025-07-26T12:54:40.003Z"}
83	59	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:54:46.338575+01	{}
84	59	\N	logout	\N	\N	\N	2025-07-26 13:55:01.598091+01	{"reason": "logout", "terminated_at": "2025-07-26T12:55:01.597Z"}
85	60	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:55:06.012128+01	{}
86	60	\N	logout	\N	\N	\N	2025-07-26 13:58:02.344958+01	{"reason": "logout", "terminated_at": "2025-07-26T12:58:02.344Z"}
87	61	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:58:05.25823+01	{}
88	62	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:58:53.184622+01	{}
89	62	\N	logout	\N	\N	\N	2025-07-26 13:59:31.554634+01	{"reason": "logout", "terminated_at": "2025-07-26T12:59:31.554Z"}
90	63	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 13:59:34.920998+01	{}
91	63	\N	logout	\N	\N	\N	2025-07-26 14:00:27.786396+01	{"reason": "logout", "terminated_at": "2025-07-26T13:00:27.786Z"}
92	64	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:00:32.758753+01	{}
93	64	\N	logout	\N	\N	\N	2025-07-26 14:00:57.493052+01	{"reason": "logout", "terminated_at": "2025-07-26T13:00:57.492Z"}
94	65	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:01:04.15594+01	{}
95	65	\N	logout	\N	\N	\N	2025-07-26 14:01:33.459311+01	{"reason": "logout", "terminated_at": "2025-07-26T13:01:33.459Z"}
96	66	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:01:49.949347+01	{}
97	66	\N	logout	\N	\N	\N	2025-07-26 14:02:08.16684+01	{"reason": "logout", "terminated_at": "2025-07-26T13:02:08.166Z"}
98	67	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:02:14.483287+01	{}
99	67	\N	logout	\N	\N	\N	2025-07-26 14:02:22.901352+01	{"reason": "logout", "terminated_at": "2025-07-26T13:02:22.901Z"}
100	68	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:02:31.235021+01	{}
101	68	\N	logout	\N	\N	\N	2025-07-26 14:04:10.81674+01	{"reason": "logout", "terminated_at": "2025-07-26T13:04:10.816Z"}
102	69	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:04:16.02612+01	{}
103	69	\N	logout	\N	\N	\N	2025-07-26 14:05:11.365044+01	{"reason": "logout", "terminated_at": "2025-07-26T13:05:11.364Z"}
104	70	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:05:49.278695+01	{}
105	70	\N	logout	\N	\N	\N	2025-07-26 14:06:10.621447+01	{"reason": "logout", "terminated_at": "2025-07-26T13:06:10.621Z"}
106	71	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:06:13.472442+01	{}
107	71	\N	logout	\N	\N	\N	2025-07-26 14:07:47.771331+01	{"reason": "logout", "terminated_at": "2025-07-26T13:07:47.771Z"}
108	72	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:07:52.262904+01	{}
109	72	\N	logout	\N	\N	\N	2025-07-26 14:07:56.51993+01	{"reason": "logout", "terminated_at": "2025-07-26T13:07:56.519Z"}
110	73	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:07:59.415306+01	{}
111	73	\N	logout	\N	\N	\N	2025-07-26 14:08:24.108938+01	{"reason": "logout", "terminated_at": "2025-07-26T13:08:24.108Z"}
112	74	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:08:28.64822+01	{}
113	75	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:15:08.27087+01	{}
114	75	\N	logout	\N	\N	\N	2025-07-26 14:15:50.111507+01	{"reason": "logout", "terminated_at": "2025-07-26T13:15:50.111Z"}
115	76	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:16:00.224426+01	{}
116	76	\N	logout	\N	\N	\N	2025-07-26 14:18:31.080616+01	{"reason": "logout", "terminated_at": "2025-07-26T13:18:31.080Z"}
117	77	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:18:35.100082+01	{}
118	78	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:33:02.107271+01	{}
119	79	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 14:40:59.307886+01	{}
120	79	4	session_extended	\N	\N	\N	2025-07-26 14:46:11.489244+01	{"extended_at": "2025-07-26T14:46:11.489244+01:00"}
121	80	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 15:11:46.303899+01	{}
122	81	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 15:20:26.194269+01	{}
123	82	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 15:34:00.572321+01	{}
124	82	\N	logout	\N	\N	\N	2025-07-26 15:34:09.000465+01	{"reason": "logout", "terminated_at": "2025-07-26T14:34:09.000Z"}
125	83	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 15:34:13.775902+01	{}
126	83	4	session_extended	\N	\N	\N	2025-07-26 15:39:16.637107+01	{"extended_at": "2025-07-26T15:39:16.637107+01:00"}
127	83	\N	logout	\N	\N	\N	2025-07-26 15:43:20.85218+01	{"reason": "logout", "terminated_at": "2025-07-26T14:43:20.852Z"}
128	84	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 15:43:26.617758+01	{}
129	84	\N	logout	\N	\N	\N	2025-07-26 15:46:59.802515+01	{"reason": "logout", "terminated_at": "2025-07-26T14:46:59.802Z"}
130	85	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 15:47:07.212986+01	{}
131	85	\N	logout	\N	\N	\N	2025-07-26 15:47:12.005683+01	{"reason": "logout", "terminated_at": "2025-07-26T14:47:12.005Z"}
132	86	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 16:06:57.334406+01	{}
134	87	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 19:12:10.254922+01	{}
135	88	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 19:21:03.117569+01	{}
136	89	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 19:22:05.132605+01	{}
137	90	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 19:28:22.441546+01	{}
138	90	4	session_extended	\N	\N	\N	2025-07-26 19:33:05.556883+01	{"extended_at": "2025-07-26T19:33:05.556883+01:00"}
139	90	4	session_extended	\N	\N	\N	2025-07-26 19:37:21.83279+01	{"extended_at": "2025-07-26T19:37:21.83279+01:00"}
140	90	4	session_extended	\N	\N	\N	2025-07-26 19:37:24.487167+01	{"extended_at": "2025-07-26T19:37:24.487167+01:00"}
141	91	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 20:58:56.664357+01	{}
142	92	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 21:08:59.309712+01	{}
143	92	4	session_extended	\N	\N	\N	2025-07-26 21:09:20.629074+01	{"extended_at": "2025-07-26T21:09:20.629074+01:00"}
144	92	4	session_extended	\N	\N	\N	2025-07-26 21:09:23.138969+01	{"extended_at": "2025-07-26T21:09:23.138969+01:00"}
145	92	4	session_extended	\N	\N	\N	2025-07-26 21:09:41.825622+01	{"extended_at": "2025-07-26T21:09:41.825622+01:00"}
146	92	4	session_extended	\N	\N	\N	2025-07-26 21:10:21.774103+01	{"extended_at": "2025-07-26T21:10:21.774103+01:00"}
147	92	4	session_extended	\N	\N	\N	2025-07-26 21:14:36.525757+01	{"extended_at": "2025-07-26T21:14:36.525757+01:00"}
148	92	4	session_extended	\N	\N	\N	2025-07-26 21:15:19.091559+01	{"extended_at": "2025-07-26T21:15:19.091559+01:00"}
149	93	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 21:43:32.708964+01	{}
150	93	4	session_extended	\N	\N	\N	2025-07-26 21:44:19.795059+01	{"extended_at": "2025-07-26T21:44:19.795059+01:00"}
151	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:01.075865+01	{"extended_at": "2025-07-26T21:45:01.075865+01:00"}
152	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:03.909995+01	{"extended_at": "2025-07-26T21:45:03.909995+01:00"}
153	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:06.149836+01	{"extended_at": "2025-07-26T21:45:06.149836+01:00"}
154	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:09.574261+01	{"extended_at": "2025-07-26T21:45:09.574261+01:00"}
155	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:14.178407+01	{"extended_at": "2025-07-26T21:45:14.178407+01:00"}
156	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:40.363629+01	{"extended_at": "2025-07-26T21:45:40.363629+01:00"}
157	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:48.762762+01	{"extended_at": "2025-07-26T21:45:48.762762+01:00"}
158	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:49.626122+01	{"extended_at": "2025-07-26T21:45:49.626122+01:00"}
159	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:50.124368+01	{"extended_at": "2025-07-26T21:45:50.124368+01:00"}
160	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:50.405019+01	{"extended_at": "2025-07-26T21:45:50.405019+01:00"}
161	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:51.181236+01	{"extended_at": "2025-07-26T21:45:51.181236+01:00"}
162	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:51.770843+01	{"extended_at": "2025-07-26T21:45:51.770843+01:00"}
163	93	4	session_extended	\N	\N	\N	2025-07-26 21:45:52.516353+01	{"extended_at": "2025-07-26T21:45:52.516353+01:00"}
164	93	4	session_extended	\N	\N	\N	2025-07-26 21:47:58.624896+01	{"extended_at": "2025-07-26T21:47:58.624896+01:00"}
165	94	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 21:50:53.596523+01	{}
166	94	4	session_extended	\N	\N	\N	2025-07-26 21:51:04.204977+01	{"extended_at": "2025-07-26T21:51:04.204977+01:00"}
167	95	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 21:59:31.385005+01	{}
168	95	4	session_extended	\N	\N	\N	2025-07-26 21:59:33.54145+01	{"extended_at": "2025-07-26T21:59:33.54145+01:00"}
169	95	4	session_extended	\N	\N	\N	2025-07-26 21:59:39.856196+01	{"extended_at": "2025-07-26T21:59:39.856196+01:00"}
170	95	4	session_extended	\N	\N	\N	2025-07-26 21:59:48.980734+01	{"extended_at": "2025-07-26T21:59:48.980734+01:00"}
171	96	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 21:59:56.208731+01	{}
172	96	4	session_extended	\N	\N	\N	2025-07-26 22:00:00.780987+01	{"extended_at": "2025-07-26T22:00:00.780987+01:00"}
173	96	4	session_extended	\N	\N	\N	2025-07-26 22:00:05.413004+01	{"extended_at": "2025-07-26T22:00:05.413004+01:00"}
174	96	4	session_extended	\N	\N	\N	2025-07-26 22:00:06.997633+01	{"extended_at": "2025-07-26T22:00:06.997633+01:00"}
175	96	4	session_extended	\N	\N	\N	2025-07-26 22:00:07.988969+01	{"extended_at": "2025-07-26T22:00:07.988969+01:00"}
176	96	4	session_extended	\N	\N	\N	2025-07-26 22:00:31.871574+01	{"extended_at": "2025-07-26T22:00:31.871574+01:00"}
177	96	4	session_extended	\N	\N	\N	2025-07-26 22:00:59.406833+01	{"extended_at": "2025-07-26T22:00:59.406833+01:00"}
178	96	4	session_extended	\N	\N	\N	2025-07-26 22:01:29.900017+01	{"extended_at": "2025-07-26T22:01:29.900017+01:00"}
179	97	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:02:56.083308+01	{}
180	98	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:05:01.849658+01	{}
181	98	4	session_extended	\N	\N	\N	2025-07-26 22:05:05.120405+01	{"extended_at": "2025-07-26T22:05:05.120405+01:00"}
182	98	4	session_extended	\N	\N	\N	2025-07-26 22:06:07.309182+01	{"extended_at": "2025-07-26T22:06:07.309182+01:00"}
183	99	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:14:25.323121+01	{}
184	99	4	session_extended	\N	\N	\N	2025-07-26 22:15:04.546047+01	{"extended_at": "2025-07-26T22:15:04.546047+01:00"}
185	100	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:16:28.084797+01	{}
186	100	4	session_extended	\N	\N	\N	2025-07-26 22:16:58.459163+01	{"extended_at": "2025-07-26T22:16:58.459163+01:00"}
187	100	4	session_extended	\N	\N	\N	2025-07-26 22:17:13.62093+01	{"extended_at": "2025-07-26T22:17:13.62093+01:00"}
188	100	4	session_extended	\N	\N	\N	2025-07-26 22:17:23.437233+01	{"extended_at": "2025-07-26T22:17:23.437233+01:00"}
189	100	4	session_extended	\N	\N	\N	2025-07-26 22:17:44.514577+01	{"extended_at": "2025-07-26T22:17:44.514577+01:00"}
190	100	\N	logout	\N	\N	\N	2025-07-26 22:18:12.629887+01	{"reason": "logout", "terminated_at": "2025-07-26T21:18:12.629Z"}
191	101	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:18:21.415745+01	{}
192	102	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:19:32.013108+01	{}
193	103	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:30:59.810261+01	{}
194	103	4	session_extended	\N	\N	\N	2025-07-26 22:31:23.696038+01	{"extended_at": "2025-07-26T22:31:23.696038+01:00"}
195	103	4	session_extended	\N	\N	\N	2025-07-26 22:31:32.169973+01	{"extended_at": "2025-07-26T22:31:32.169973+01:00"}
196	103	4	session_extended	\N	\N	\N	2025-07-26 22:31:32.358592+01	{"extended_at": "2025-07-26T22:31:32.358592+01:00"}
197	104	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:32:45.783476+01	{}
198	104	4	session_extended	\N	\N	\N	2025-07-26 22:32:49.789052+01	{"extended_at": "2025-07-26T22:32:49.789052+01:00"}
199	104	4	session_extended	\N	\N	\N	2025-07-26 22:32:50.797076+01	{"extended_at": "2025-07-26T22:32:50.797076+01:00"}
200	104	4	session_extended	\N	\N	\N	2025-07-26 22:33:10.545594+01	{"extended_at": "2025-07-26T22:33:10.545594+01:00"}
201	104	4	session_extended	\N	\N	\N	2025-07-26 22:33:13.774673+01	{"extended_at": "2025-07-26T22:33:13.774673+01:00"}
202	104	4	session_extended	\N	\N	\N	2025-07-26 22:33:14.776695+01	{"extended_at": "2025-07-26T22:33:14.776695+01:00"}
203	104	4	session_extended	\N	\N	\N	2025-07-26 22:34:32.707585+01	{"extended_at": "2025-07-26T22:34:32.707585+01:00"}
204	104	4	session_extended	\N	\N	\N	2025-07-26 22:34:33.879405+01	{"extended_at": "2025-07-26T22:34:33.879405+01:00"}
205	104	4	session_extended	\N	\N	\N	2025-07-26 22:34:39.50083+01	{"extended_at": "2025-07-26T22:34:39.50083+01:00"}
206	104	4	session_extended	\N	\N	\N	2025-07-26 22:35:52.194993+01	{"extended_at": "2025-07-26T22:35:52.194993+01:00"}
207	104	4	session_extended	\N	\N	\N	2025-07-26 22:35:55.926632+01	{"extended_at": "2025-07-26T22:35:55.926632+01:00"}
208	104	4	session_extended	\N	\N	\N	2025-07-26 22:36:51.701239+01	{"extended_at": "2025-07-26T22:36:51.701239+01:00"}
209	104	4	session_extended	\N	\N	\N	2025-07-26 22:37:30.704431+01	{"extended_at": "2025-07-26T22:37:30.704431+01:00"}
210	104	4	session_extended	\N	\N	\N	2025-07-26 22:38:52.934046+01	{"extended_at": "2025-07-26T22:38:52.934046+01:00"}
211	104	4	session_extended	\N	\N	\N	2025-07-26 22:39:30.266704+01	{"extended_at": "2025-07-26T22:39:30.266704+01:00"}
212	105	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:39:36.084725+01	{}
213	105	4	session_extended	\N	\N	\N	2025-07-26 22:40:33.583723+01	{"extended_at": "2025-07-26T22:40:33.583723+01:00"}
214	105	4	session_extended	\N	\N	\N	2025-07-26 22:41:41.748453+01	{"extended_at": "2025-07-26T22:41:41.748453+01:00"}
215	105	4	session_extended	\N	\N	\N	2025-07-26 22:41:42.744922+01	{"extended_at": "2025-07-26T22:41:42.744922+01:00"}
216	105	4	session_extended	\N	\N	\N	2025-07-26 22:43:07.701887+01	{"extended_at": "2025-07-26T22:43:07.701887+01:00"}
217	105	4	session_extended	\N	\N	\N	2025-07-26 22:43:08.964037+01	{"extended_at": "2025-07-26T22:43:08.964037+01:00"}
218	105	4	session_extended	\N	\N	\N	2025-07-26 22:44:43.514138+01	{"extended_at": "2025-07-26T22:44:43.514138+01:00"}
219	105	\N	logout	\N	\N	\N	2025-07-26 22:45:37.704302+01	{"reason": "logout", "terminated_at": "2025-07-26T21:45:37.704Z"}
220	106	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:47:45.128042+01	{}
221	106	4	session_extended	\N	\N	\N	2025-07-26 22:47:45.473786+01	{"extended_at": "2025-07-26T22:47:45.473786+01:00"}
222	107	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:54:05.920497+01	{}
223	108	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 22:57:44.752004+01	{}
224	109	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 23:19:18.197776+01	{}
225	109	\N	logout	\N	\N	\N	2025-07-26 23:28:01.440988+01	{"reason": "logout", "terminated_at": "2025-07-26T22:28:01.440Z"}
226	110	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 23:28:11.411807+01	{}
227	111	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 23:33:04.270275+01	{}
228	112	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 00:06:19.804631+01	{}
229	113	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 00:16:47.376677+01	{}
230	114	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 00:22:00.975528+01	{}
231	115	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 08:37:37.889656+01	{}
232	116	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 08:46:35.108984+01	{}
233	117	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 08:52:04.837699+01	{}
234	118	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 09:03:08.580103+01	{}
235	119	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 09:14:17.482159+01	{}
236	119	\N	logout	\N	\N	\N	2025-07-27 09:20:33.024902+01	{"reason": "logout", "terminated_at": "2025-07-27T08:20:33.024Z"}
237	120	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 09:20:37.458871+01	{}
238	120	\N	logout	\N	\N	\N	2025-07-27 09:23:17.625529+01	{"reason": "logout", "terminated_at": "2025-07-27T08:23:17.625Z"}
239	121	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 09:28:45.268751+01	{}
240	122	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 09:33:21.519975+01	{}
241	123	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 09:44:15.440747+01	{}
242	123	\N	logout	\N	\N	\N	2025-07-27 09:49:10.878566+01	{"reason": "logout", "terminated_at": "2025-07-27T08:49:10.878Z"}
243	124	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 09:49:16.979729+01	{}
244	125	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:00:40.799117+01	{}
245	125	\N	logout	\N	\N	\N	2025-07-27 10:04:00.42385+01	{"reason": "logout", "terminated_at": "2025-07-27T09:04:00.423Z"}
246	126	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:04:39.342074+01	{}
247	127	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:06:34.493788+01	{}
248	128	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:07:55.553266+01	{}
249	129	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:08:53.24983+01	{}
250	130	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:17:19.26329+01	{}
251	131	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:23:40.494632+01	{}
252	132	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:26:50.77671+01	{}
253	133	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:28:07.013092+01	{}
254	133	\N	logout	\N	\N	\N	2025-07-27 10:31:07.467938+01	{"reason": "logout", "terminated_at": "2025-07-27T09:31:07.467Z"}
255	134	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:31:13.962809+01	{}
256	135	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:39:24.521811+01	{}
257	136	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:44:08.894147+01	{}
258	137	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:51:59.034044+01	{}
259	138	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 10:58:04.716316+01	{}
260	138	\N	logout	\N	\N	\N	2025-07-27 11:01:15.353357+01	{"reason": "logout", "terminated_at": "2025-07-27T10:01:15.353Z"}
261	139	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:11:15.97637+01	{}
262	140	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:24:48.369146+01	{}
263	140	\N	logout	\N	\N	\N	2025-07-27 11:26:51.132172+01	{"reason": "logout", "terminated_at": "2025-07-27T10:26:51.131Z"}
264	141	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:27:34.00185+01	{}
265	142	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:32:02.242526+01	{}
266	143	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:39:40.604041+01	{}
267	143	\N	logout	\N	\N	\N	2025-07-27 11:42:37.474515+01	{"reason": "logout", "terminated_at": "2025-07-27T10:42:37.474Z"}
268	144	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:43:39.641957+01	{}
269	144	\N	logout	\N	\N	\N	2025-07-27 11:47:54.978021+01	{"reason": "logout", "terminated_at": "2025-07-27T10:47:54.977Z"}
270	145	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:53:34.860705+01	{}
271	146	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 11:54:56.064577+01	{}
272	146	\N	logout	\N	\N	\N	2025-07-27 12:00:10.469697+01	{"reason": "logout", "terminated_at": "2025-07-27T11:00:10.469Z"}
273	147	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 12:14:52.518529+01	{}
274	148	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:28:06.030768+01	{}
275	148	\N	logout	\N	\N	\N	2025-07-27 13:29:05.558278+01	{"reason": "logout", "terminated_at": "2025-07-27T12:29:05.558Z"}
276	149	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:31:05.121281+01	{}
277	149	\N	logout	\N	\N	\N	2025-07-27 13:32:29.863615+01	{"reason": "logout", "terminated_at": "2025-07-27T12:32:29.863Z"}
278	150	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:33:11.828523+01	{}
279	151	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:36:26.30867+01	{}
280	152	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:42:53.87095+01	{}
281	153	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:44:23.410243+01	{}
282	154	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:48:44.884922+01	{}
283	154	\N	logout	\N	\N	\N	2025-07-27 13:52:52.394752+01	{"reason": "logout", "terminated_at": "2025-07-27T12:52:52.394Z"}
284	155	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:52:58.736876+01	{}
285	156	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 13:54:46.080865+01	{}
286	156	\N	logout	\N	\N	\N	2025-07-27 14:05:16.001721+01	{"reason": "logout", "terminated_at": "2025-07-27T13:05:16.001Z"}
287	157	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:06:15.714731+01	{}
288	158	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:07:22.441413+01	{}
289	159	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:21:19.328039+01	{}
290	159	\N	logout	\N	\N	\N	2025-07-27 14:21:26.812376+01	{"reason": "logout", "terminated_at": "2025-07-27T13:21:26.812Z"}
291	160	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:21:29.8891+01	{}
292	160	\N	logout	\N	\N	\N	2025-07-27 14:22:04.002574+01	{"reason": "logout", "terminated_at": "2025-07-27T13:22:04.002Z"}
293	161	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:22:09.09867+01	{}
294	162	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:22:48.656469+01	{}
295	162	\N	logout	\N	\N	\N	2025-07-27 14:23:07.811619+01	{"reason": "logout", "terminated_at": "2025-07-27T13:23:07.811Z"}
296	163	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:23:11.208693+01	{}
297	163	\N	logout	\N	\N	\N	2025-07-27 14:24:24.748441+01	{"reason": "logout", "terminated_at": "2025-07-27T13:24:24.748Z"}
298	164	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:24:28.39064+01	{}
299	164	\N	logout	\N	\N	\N	2025-07-27 14:24:44.502459+01	{"reason": "logout", "terminated_at": "2025-07-27T13:24:44.502Z"}
300	165	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:24:48.337816+01	{}
301	166	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:32:30.605022+01	{}
302	167	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:37:56.263567+01	{}
303	168	2	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 14:39:40.703008+01	{}
304	169	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 19:57:49.16692+01	{}
305	170	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 19:59:00.532152+01	{}
306	171	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 20:02:45.316439+01	{}
307	172	4	login	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 20:14:19.378429+01	{}
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.sessions (id, date, google_calendar_event_id, patient_id, therapist_id, status, billable, billing_period, session_price, billing_cycle_used, created_during_onboarding, import_batch_id, payment_requested, payment_request_date, payment_status, paid_date, billing_period_id, created_at) FROM stdin;
1	2025-07-15 14:00:00+01	\N	1	1	compareceu	t	\N	15000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
2	2025-07-08 14:00:00+01	\N	1	1	compareceu	t	\N	15000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
3	2025-07-01 14:00:00+01	\N	1	1	compareceu	t	\N	15000.00	\N	f	\N	f	\N	overdue	\N	\N	2025-07-20 11:02:08.461708+01
4	2025-06-24 14:00:00+01	\N	1	1	compareceu	t	\N	15000.00	\N	f	\N	t	\N	pending	\N	\N	2025-07-20 11:02:08.461708+01
5	2025-07-17 16:00:00+01	\N	2	1	compareceu	t	\N	18000.00	\N	f	\N	t	\N	pending	\N	\N	2025-07-20 11:02:08.461708+01
6	2025-07-10 16:00:00+01	\N	2	1	compareceu	t	\N	18000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
7	2025-07-03 16:00:00+01	\N	2	1	compareceu	t	\N	18000.00	\N	f	\N	t	\N	overdue	\N	\N	2025-07-20 11:02:08.461708+01
8	2025-07-18 10:00:00+01	\N	3	1	compareceu	t	\N	16000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
9	2025-07-16 10:00:00+01	\N	3	1	compareceu	t	\N	16000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
10	2025-07-14 10:00:00+01	\N	3	1	compareceu	t	\N	16000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
11	2025-07-12 10:00:00+01	\N	3	1	compareceu	t	\N	16000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
12	2025-07-10 10:00:00+01	\N	3	1	compareceu	t	\N	16000.00	\N	f	\N	t	\N	paid	\N	\N	2025-07-20 11:02:08.461708+01
13	2025-01-06 12:00:00+00	event_4_1736164800	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-05 12:00:00+00
14	2025-01-13 12:00:00+00	event_4_1736769600	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-12 12:00:00+00
15	2025-01-20 12:00:00+00	event_4_1737374400	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-19 12:00:00+00
16	2025-01-27 12:00:00+00	event_4_1737979200	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-26 12:00:00+00
17	2025-02-03 12:00:00+00	event_4_1738584000	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-02 12:00:00+00
18	2025-02-10 12:00:00+00	event_4_1739188800	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-09 12:00:00+00
19	2025-02-17 12:00:00+00	event_4_1739793600	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-16 12:00:00+00
20	2025-02-24 12:00:00+00	event_4_1740398400	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-23 12:00:00+00
21	2025-03-03 12:00:00+00	event_4_1741003200	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-02 12:00:00+00
22	2025-03-10 12:00:00+00	event_4_1741608000	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-09 12:00:00+00
23	2025-03-17 12:00:00+00	event_4_1742212800	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-16 12:00:00+00
24	2025-03-24 12:00:00+00	event_4_1742817600	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-23 12:00:00+00
25	2025-03-31 12:00:00+01	event_4_1743418800	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-30 12:00:00+01
26	2025-04-07 12:00:00+01	event_4_1744023600	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-06 12:00:00+01
27	2025-04-14 12:00:00+01	event_4_1744628400	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-13 12:00:00+01
28	2025-04-21 12:00:00+01	event_4_1745233200	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-20 12:00:00+01
29	2025-04-28 12:00:00+01	event_4_1745838000	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-27 12:00:00+01
30	2025-05-05 12:00:00+01	event_4_1746442800	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-04 12:00:00+01
31	2025-05-12 12:00:00+01	event_4_1747047600	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-11 12:00:00+01
32	2025-05-19 12:00:00+01	event_4_1747652400	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-18 12:00:00+01
33	2025-05-26 12:00:00+01	event_4_1748257200	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-25 12:00:00+01
34	2025-06-02 12:00:00+01	event_4_1748862000	4	2	compareceu	t	\N	250.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-01 12:00:00+01
39	2025-01-06 12:00:00+00	event_5_1736164800	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-05 12:00:00+00
40	2025-01-13 12:00:00+00	event_5_1736769600	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-12 12:00:00+00
41	2025-01-20 12:00:00+00	event_5_1737374400	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-19 12:00:00+00
42	2025-01-27 12:00:00+00	event_5_1737979200	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-26 12:00:00+00
43	2025-02-03 12:00:00+00	event_5_1738584000	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-02 12:00:00+00
44	2025-02-10 12:00:00+00	event_5_1739188800	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-09 12:00:00+00
45	2025-02-17 12:00:00+00	event_5_1739793600	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-16 12:00:00+00
46	2025-02-24 12:00:00+00	event_5_1740398400	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-23 12:00:00+00
47	2025-03-03 12:00:00+00	event_5_1741003200	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-02 12:00:00+00
48	2025-03-10 12:00:00+00	event_5_1741608000	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-09 12:00:00+00
49	2025-03-17 12:00:00+00	event_5_1742212800	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-16 12:00:00+00
50	2025-03-24 12:00:00+00	event_5_1742817600	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-23 12:00:00+00
51	2025-03-31 12:00:00+01	event_5_1743418800	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-30 12:00:00+01
52	2025-04-07 12:00:00+01	event_5_1744023600	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-06 12:00:00+01
53	2025-04-14 12:00:00+01	event_5_1744628400	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-13 12:00:00+01
54	2025-04-21 12:00:00+01	event_5_1745233200	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-20 12:00:00+01
55	2025-04-28 12:00:00+01	event_5_1745838000	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-27 12:00:00+01
56	2025-05-05 12:00:00+01	event_5_1746442800	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-04 12:00:00+01
57	2025-05-12 12:00:00+01	event_5_1747047600	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-11 12:00:00+01
58	2025-05-19 12:00:00+01	event_5_1747652400	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-18 12:00:00+01
59	2025-05-26 12:00:00+01	event_5_1748257200	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-25 12:00:00+01
60	2025-06-02 12:00:00+01	event_5_1748862000	5	2	compareceu	t	\N	220.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-01 12:00:00+01
65	2025-01-06 12:00:00+00	event_6_1736164800	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-05 12:00:00+00
66	2025-01-13 12:00:00+00	event_6_1736769600	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-12 12:00:00+00
67	2025-01-20 12:00:00+00	event_6_1737374400	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-19 12:00:00+00
68	2025-01-27 12:00:00+00	event_6_1737979200	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-26 12:00:00+00
69	2025-02-03 12:00:00+00	event_6_1738584000	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-02 12:00:00+00
70	2025-02-10 12:00:00+00	event_6_1739188800	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-09 12:00:00+00
71	2025-02-17 12:00:00+00	event_6_1739793600	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-16 12:00:00+00
72	2025-02-24 12:00:00+00	event_6_1740398400	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-23 12:00:00+00
73	2025-03-03 12:00:00+00	event_6_1741003200	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-02 12:00:00+00
74	2025-03-10 12:00:00+00	event_6_1741608000	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-09 12:00:00+00
75	2025-03-17 12:00:00+00	event_6_1742212800	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-16 12:00:00+00
76	2025-03-24 12:00:00+00	event_6_1742817600	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-23 12:00:00+00
77	2025-03-31 12:00:00+01	event_6_1743418800	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-30 12:00:00+01
78	2025-04-07 12:00:00+01	event_6_1744023600	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-06 12:00:00+01
79	2025-04-14 12:00:00+01	event_6_1744628400	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-13 12:00:00+01
80	2025-04-21 12:00:00+01	event_6_1745233200	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-20 12:00:00+01
81	2025-04-28 12:00:00+01	event_6_1745838000	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-27 12:00:00+01
82	2025-05-05 12:00:00+01	event_6_1746442800	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-04 12:00:00+01
83	2025-05-12 12:00:00+01	event_6_1747047600	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-11 12:00:00+01
84	2025-05-19 12:00:00+01	event_6_1747652400	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-18 12:00:00+01
85	2025-05-26 12:00:00+01	event_6_1748257200	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-25 12:00:00+01
86	2025-06-02 12:00:00+01	event_6_1748862000	6	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-01 12:00:00+01
91	2025-01-15 14:00:00+00	event_7_1736949600	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-14 14:00:00+00
92	2025-01-29 14:00:00+00	event_7_1738159200	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-28 14:00:00+00
93	2025-02-12 14:00:00+00	event_7_1739368800	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-11 14:00:00+00
94	2025-02-26 14:00:00+00	event_7_1740578400	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-25 14:00:00+00
95	2025-03-12 14:00:00+00	event_7_1741788000	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-11 14:00:00+00
96	2025-03-26 14:00:00+00	event_7_1742997600	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-25 14:00:00+00
97	2025-04-09 14:00:00+01	event_7_1744203600	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-08 14:00:00+01
98	2025-04-23 14:00:00+01	event_7_1745413200	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-22 14:00:00+01
99	2025-05-07 14:00:00+01	event_7_1746622800	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-06 14:00:00+01
100	2025-05-21 14:00:00+01	event_7_1747832400	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-20 14:00:00+01
101	2025-06-04 14:00:00+01	event_7_1749042000	7	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-03 14:00:00+01
103	2025-01-15 14:00:00+00	event_8_1736949600	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-14 14:00:00+00
104	2025-01-29 14:00:00+00	event_8_1738159200	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-28 14:00:00+00
105	2025-02-12 14:00:00+00	event_8_1739368800	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-11 14:00:00+00
106	2025-02-26 14:00:00+00	event_8_1740578400	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-25 14:00:00+00
107	2025-03-12 14:00:00+00	event_8_1741788000	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-11 14:00:00+00
108	2025-03-26 14:00:00+00	event_8_1742997600	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-25 14:00:00+00
109	2025-04-09 14:00:00+01	event_8_1744203600	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-08 14:00:00+01
110	2025-04-23 14:00:00+01	event_8_1745413200	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-22 14:00:00+01
111	2025-05-07 14:00:00+01	event_8_1746622800	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-06 14:00:00+01
112	2025-05-21 14:00:00+01	event_8_1747832400	8	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-20 14:00:00+01
115	2025-01-15 14:00:00+00	event_9_1736949600	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-14 14:00:00+00
116	2025-01-29 14:00:00+00	event_9_1738159200	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-28 14:00:00+00
117	2025-02-12 14:00:00+00	event_9_1739368800	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-11 14:00:00+00
118	2025-02-26 14:00:00+00	event_9_1740578400	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-25 14:00:00+00
119	2025-03-12 14:00:00+00	event_9_1741788000	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-11 14:00:00+00
120	2025-03-26 14:00:00+00	event_9_1742997600	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-25 14:00:00+00
121	2025-04-09 14:00:00+01	event_9_1744203600	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-08 14:00:00+01
122	2025-04-23 14:00:00+01	event_9_1745413200	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-22 14:00:00+01
127	2025-01-15 14:00:00+00	event_10_1736949600	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-14 14:00:00+00
128	2025-01-29 14:00:00+00	event_10_1738159200	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-28 14:00:00+00
129	2025-02-12 14:00:00+00	event_10_1739368800	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-11 14:00:00+00
130	2025-02-26 14:00:00+00	event_10_1740578400	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-25 14:00:00+00
131	2025-03-12 14:00:00+00	event_10_1741788000	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-11 14:00:00+00
132	2025-03-26 14:00:00+00	event_10_1742997600	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-25 14:00:00+00
133	2025-04-09 14:00:00+01	event_10_1744203600	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-08 14:00:00+01
134	2025-04-23 14:00:00+01	event_10_1745413200	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-22 14:00:00+01
139	2025-01-15 14:00:00+00	event_11_1736949600	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-14 14:00:00+00
140	2025-01-29 14:00:00+00	event_11_1738159200	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-01-28 14:00:00+00
141	2025-02-12 14:00:00+00	event_11_1739368800	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-11 14:00:00+00
142	2025-02-26 14:00:00+00	event_11_1740578400	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-25 14:00:00+00
143	2025-03-12 14:00:00+00	event_11_1741788000	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-11 14:00:00+00
144	2025-03-26 14:00:00+00	event_11_1742997600	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-25 14:00:00+00
145	2025-04-09 14:00:00+01	event_11_1744203600	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-08 14:00:00+01
146	2025-04-23 14:00:00+01	event_11_1745413200	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-22 14:00:00+01
151	2025-02-10 17:30:00+00	event_12_1739208600	12	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-09 17:30:00+00
152	2025-03-10 17:30:00+00	event_12_1741627800	12	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-09 17:30:00+00
87	2025-06-09 12:00:00+01	event_6_1749466800	6	2	compareceu	t	\N	200.00	\N	f	\N	t	2025-07-08 00:00:00+01	pending	\N	\N	2025-06-08 12:00:00+01
135	2025-05-07 14:00:00+01	event_10_1746622800	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-05-06 14:00:00+01
136	2025-05-21 14:00:00+01	event_10_1747832400	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-05-20 14:00:00+01
124	2025-05-21 14:00:00+01	event_9_1747832400	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-05-20 14:00:00+01
150	2025-06-18 14:00:00+01	event_11_1750251600	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-06-17 14:00:00+01
138	2025-06-18 14:00:00+01	event_10_1750251600	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-06-17 14:00:00+01
153	2025-04-07 17:30:00+01	event_12_1744043400	12	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-06 17:30:00+01
154	2025-05-05 17:30:00+01	event_12_1746462600	12	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-04 17:30:00+01
155	2025-06-02 17:30:00+01	event_12_1748881800	12	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-01 17:30:00+01
156	2025-06-30 17:30:00+01	event_12_1751301000	12	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-29 17:30:00+01
157	2025-02-10 17:30:00+00	event_13_1739208600	13	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-09 17:30:00+00
158	2025-03-10 17:30:00+00	event_13_1741627800	13	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-09 17:30:00+00
159	2025-04-07 17:30:00+01	event_13_1744043400	13	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-06 17:30:00+01
160	2025-05-05 17:30:00+01	event_13_1746462600	13	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-04 17:30:00+01
161	2025-06-02 17:30:00+01	event_13_1748881800	13	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-01 17:30:00+01
162	2025-06-30 17:30:00+01	event_13_1751301000	13	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-29 17:30:00+01
163	2025-02-10 17:30:00+00	event_14_1739208600	14	2	compareceu	t	\N	140.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-09 17:30:00+00
164	2025-03-10 17:30:00+00	event_14_1741627800	14	2	compareceu	t	\N	140.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-09 17:30:00+00
165	2025-04-07 17:30:00+01	event_14_1744043400	14	2	compareceu	t	\N	140.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-06 17:30:00+01
166	2025-05-05 17:30:00+01	event_14_1746462600	14	2	compareceu	t	\N	140.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-04 17:30:00+01
167	2025-06-02 17:30:00+01	event_14_1748881800	14	2	compareceu	t	\N	140.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-01 17:30:00+01
168	2025-06-30 17:30:00+01	event_14_1751301000	14	2	compareceu	t	\N	140.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-29 17:30:00+01
169	2025-02-10 17:30:00+00	event_15_1739208600	15	2	compareceu	t	\N	130.00	\N	f	\N	f	\N	pending	\N	\N	2025-02-09 17:30:00+00
170	2025-03-10 17:30:00+00	event_15_1741627800	15	2	compareceu	t	\N	130.00	\N	f	\N	f	\N	pending	\N	\N	2025-03-09 17:30:00+00
171	2025-04-07 17:30:00+01	event_15_1744043400	15	2	compareceu	t	\N	130.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-06 17:30:00+01
172	2025-05-05 17:30:00+01	event_15_1746462600	15	2	compareceu	t	\N	130.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-04 17:30:00+01
173	2025-06-02 17:30:00+01	event_15_1748881800	15	2	compareceu	t	\N	130.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-01 17:30:00+01
174	2025-06-30 17:30:00+01	event_15_1751301000	15	2	compareceu	t	\N	130.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-29 17:30:00+01
175	2025-04-05 17:00:00+01	event_19_1743868800	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-04 17:00:00+01
176	2025-04-12 17:00:00+01	event_19_1744473600	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-11 17:00:00+01
177	2025-04-19 17:00:00+01	event_19_1745078400	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-18 17:00:00+01
178	2025-04-26 17:00:00+01	event_19_1745683200	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-25 17:00:00+01
179	2025-05-03 17:00:00+01	event_19_1746288000	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-02 17:00:00+01
180	2025-05-10 17:00:00+01	event_19_1746892800	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-09 17:00:00+01
181	2025-05-17 17:00:00+01	event_19_1747497600	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-16 17:00:00+01
182	2025-05-24 17:00:00+01	event_19_1748102400	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-23 17:00:00+01
183	2025-05-31 17:00:00+01	event_19_1748707200	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-30 17:00:00+01
184	2025-06-07 17:00:00+01	event_19_1749312000	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-06 17:00:00+01
185	2025-06-14 17:00:00+01	event_19_1749916800	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-13 17:00:00+01
186	2025-06-21 17:00:00+01	event_19_1750521600	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-20 17:00:00+01
187	2025-06-28 17:00:00+01	event_19_1751126400	19	2	compareceu	t	\N	190.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-27 17:00:00+01
188	2025-04-05 17:00:00+01	event_20_1743868800	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-04 17:00:00+01
189	2025-04-12 17:00:00+01	event_20_1744473600	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-11 17:00:00+01
190	2025-04-19 17:00:00+01	event_20_1745078400	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-18 17:00:00+01
191	2025-04-26 17:00:00+01	event_20_1745683200	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-25 17:00:00+01
192	2025-05-03 17:00:00+01	event_20_1746288000	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-02 17:00:00+01
193	2025-05-10 17:00:00+01	event_20_1746892800	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-09 17:00:00+01
194	2025-05-17 17:00:00+01	event_20_1747497600	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-16 17:00:00+01
195	2025-05-24 17:00:00+01	event_20_1748102400	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-23 17:00:00+01
196	2025-05-31 17:00:00+01	event_20_1748707200	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-30 17:00:00+01
197	2025-06-07 17:00:00+01	event_20_1749312000	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-06 17:00:00+01
198	2025-06-14 17:00:00+01	event_20_1749916800	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-13 17:00:00+01
199	2025-06-21 17:00:00+01	event_20_1750521600	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-20 17:00:00+01
200	2025-06-28 17:00:00+01	event_20_1751126400	20	2	compareceu	t	\N	160.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-27 17:00:00+01
201	2025-04-05 17:00:00+01	event_21_1743868800	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-04 17:00:00+01
202	2025-04-12 17:00:00+01	event_21_1744473600	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-11 17:00:00+01
203	2025-04-19 17:00:00+01	event_21_1745078400	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-18 17:00:00+01
204	2025-04-26 17:00:00+01	event_21_1745683200	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-25 17:00:00+01
205	2025-05-03 17:00:00+01	event_21_1746288000	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-02 17:00:00+01
206	2025-05-10 17:00:00+01	event_21_1746892800	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-09 17:00:00+01
207	2025-05-17 17:00:00+01	event_21_1747497600	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-16 17:00:00+01
208	2025-05-24 17:00:00+01	event_21_1748102400	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-23 17:00:00+01
209	2025-05-31 17:00:00+01	event_21_1748707200	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-30 17:00:00+01
210	2025-06-07 17:00:00+01	event_21_1749312000	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-06 17:00:00+01
211	2025-06-14 17:00:00+01	event_21_1749916800	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-13 17:00:00+01
212	2025-06-21 17:00:00+01	event_21_1750521600	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-20 17:00:00+01
213	2025-06-28 17:00:00+01	event_21_1751126400	21	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-27 17:00:00+01
214	2025-04-05 17:00:00+01	event_22_1743868800	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-04 17:00:00+01
215	2025-04-12 17:00:00+01	event_22_1744473600	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-11 17:00:00+01
216	2025-04-19 17:00:00+01	event_22_1745078400	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-18 17:00:00+01
217	2025-04-26 17:00:00+01	event_22_1745683200	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-25 17:00:00+01
218	2025-05-03 17:00:00+01	event_22_1746288000	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-02 17:00:00+01
219	2025-05-10 17:00:00+01	event_22_1746892800	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-09 17:00:00+01
220	2025-05-17 17:00:00+01	event_22_1747497600	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-16 17:00:00+01
221	2025-05-24 17:00:00+01	event_22_1748102400	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-23 17:00:00+01
222	2025-05-31 17:00:00+01	event_22_1748707200	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-30 17:00:00+01
223	2025-06-07 17:00:00+01	event_22_1749312000	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-06 17:00:00+01
224	2025-06-14 17:00:00+01	event_22_1749916800	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-13 17:00:00+01
225	2025-06-21 17:00:00+01	event_22_1750521600	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-20 17:00:00+01
226	2025-06-28 17:00:00+01	event_22_1751126400	22	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-27 17:00:00+01
227	2025-04-05 17:00:00+01	event_23_1743868800	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-04 17:00:00+01
228	2025-04-12 17:00:00+01	event_23_1744473600	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-11 17:00:00+01
229	2025-04-19 17:00:00+01	event_23_1745078400	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-18 17:00:00+01
230	2025-04-26 17:00:00+01	event_23_1745683200	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-04-25 17:00:00+01
231	2025-05-03 17:00:00+01	event_23_1746288000	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-02 17:00:00+01
232	2025-05-10 17:00:00+01	event_23_1746892800	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-09 17:00:00+01
233	2025-05-17 17:00:00+01	event_23_1747497600	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-16 17:00:00+01
234	2025-05-24 17:00:00+01	event_23_1748102400	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-23 17:00:00+01
235	2025-05-31 17:00:00+01	event_23_1748707200	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-05-30 17:00:00+01
236	2025-06-07 17:00:00+01	event_23_1749312000	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-06 17:00:00+01
237	2025-06-14 17:00:00+01	event_23_1749916800	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-13 17:00:00+01
238	2025-06-21 17:00:00+01	event_23_1750521600	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-20 17:00:00+01
239	2025-06-28 17:00:00+01	event_23_1751126400	23	2	compareceu	t	\N	200.00	\N	f	\N	f	\N	pending	\N	\N	2025-06-27 17:00:00+01
35	2025-06-09 12:00:00+01	event_4_1749466800	4	2	compareceu	t	\N	250.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-08 12:00:00+01
36	2025-06-16 12:00:00+01	event_4_1750071600	4	2	compareceu	t	\N	250.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-15 12:00:00+01
37	2025-06-23 12:00:00+01	event_4_1750676400	4	2	compareceu	t	\N	250.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-22 12:00:00+01
38	2025-06-30 12:00:00+01	event_4_1751281200	4	2	compareceu	t	\N	250.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-29 12:00:00+01
61	2025-06-09 12:00:00+01	event_5_1749466800	5	2	compareceu	t	\N	220.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-08 12:00:00+01
62	2025-06-16 12:00:00+01	event_5_1750071600	5	2	compareceu	t	\N	220.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-15 12:00:00+01
63	2025-06-23 12:00:00+01	event_5_1750676400	5	2	compareceu	t	\N	220.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-22 12:00:00+01
64	2025-06-30 12:00:00+01	event_5_1751281200	5	2	compareceu	t	\N	220.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-29 12:00:00+01
102	2025-06-18 14:00:00+01	event_7_1750251600	7	2	compareceu	t	\N	180.00	\N	f	\N	t	2025-07-17 00:00:00+01	pending	\N	\N	2025-06-17 14:00:00+01
88	2025-06-16 12:00:00+01	event_6_1750071600	6	2	compareceu	t	\N	200.00	\N	f	\N	t	2025-07-08 00:00:00+01	pending	\N	\N	2025-06-15 12:00:00+01
89	2025-06-23 12:00:00+01	event_6_1750676400	6	2	compareceu	t	\N	200.00	\N	f	\N	t	2025-07-08 00:00:00+01	pending	\N	\N	2025-06-22 12:00:00+01
90	2025-06-30 12:00:00+01	event_6_1751281200	6	2	compareceu	t	\N	200.00	\N	f	\N	t	2025-07-08 00:00:00+01	pending	\N	\N	2025-06-29 12:00:00+01
113	2025-06-04 14:00:00+01	event_8_1749042000	8	2	compareceu	t	\N	160.00	\N	f	\N	t	2025-07-08 00:00:00+01	pending	\N	\N	2025-06-03 14:00:00+01
114	2025-06-18 14:00:00+01	event_8_1750251600	8	2	compareceu	t	\N	160.00	\N	f	\N	t	2025-07-08 00:00:00+01	pending	\N	\N	2025-06-17 14:00:00+01
125	2025-06-04 14:00:00+01	event_9_1749042000	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-06-03 14:00:00+01
123	2025-05-07 14:00:00+01	event_9_1746622800	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-05-06 14:00:00+01
148	2025-05-21 14:00:00+01	event_11_1747832400	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-05-20 14:00:00+01
137	2025-06-04 14:00:00+01	event_10_1749042000	10	2	compareceu	t	\N	150.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-06-03 14:00:00+01
126	2025-06-18 14:00:00+01	event_9_1750251600	9	2	compareceu	t	\N	170.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-06-17 14:00:00+01
147	2025-05-07 14:00:00+01	event_11_1746622800	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-05-06 14:00:00+01
149	2025-06-04 14:00:00+01	event_11_1749042000	11	2	compareceu	t	\N	180.00	\N	f	\N	f	\N	paid	2025-07-19 00:00:00+01	\N	2025-06-03 14:00:00+01
\.


--
-- Data for Name: therapist_billing_history; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.therapist_billing_history (id, therapist_id, billing_cycle, default_session_price, effective_from_date, effective_until_date, reason_for_change, created_by, created_at, notes) FROM stdin;
\.


--
-- Data for Name: therapist_onboarding; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.therapist_onboarding (id, therapist_id, step, completed_at, data, notes) FROM stdin;
1	1	calendar_selected	2025-07-15 11:02:08.472826+01	{"calendar_id": "example_calendar_id", "calendar_name": "Terapia - Dr. Exemplo"}	Google Calendar conectado com sucesso
2	1	events_imported	2025-07-16 11:02:08.472826+01	{"date_range": "last_3_months", "events_count": 120}	Importados 120 eventos dos últimos 3 meses
3	1	patients_created	2025-07-17 11:02:08.472826+01	{"patients_count": 3, "matched_automatically": 3}	Pacientes criados automaticamente
4	1	appointments_linked	2025-07-18 11:02:08.472826+01	{"success_rate": 0.95, "sessions_created": 85}	Sessões vinculadas com 95% de sucesso
5	1	billing_configured	2025-07-19 11:02:08.472826+01	{"billing_cycle": "monthly", "default_price": 150.00}	Configuração de cobrança mensal
6	1	completed	2025-07-20 11:02:08.472826+01	{"completion_date": "2024-07-01"}	Onboarding concluído com sucesso
\.


--
-- Data for Name: therapist_settings; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.therapist_settings (id, therapist_id, setting_key, setting_value, created_at, updated_at) FROM stdin;
1	1	payment_mode	simple	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
2	1	view_mode	card	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
3	1	auto_check_in_mode	false	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
4	1	theme	light	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
5	1	language	pt-BR	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
6	1	notifications_enabled	true	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
7	1	default_session_duration	60	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
8	1	currency_format	BRL	2025-07-20 11:02:08.470697+01	2025-07-20 11:02:08.470697+01
\.


--
-- Data for Name: therapists; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.therapists (id, nome, email, telefone, google_calendar_id, billing_cycle, default_session_price, onboarding_completed, onboarding_started_at, onboarding_completed_at, created_at) FROM stdin;
1	Dr. Exemplo Terapeuta	terapeuta@example.com	(11) 99999-9999	example_calendar_id	monthly	15000.00	t	2025-07-20 11:02:08.459279+01	2025-07-20 11:02:08.459279+01	2025-07-20 11:02:08.459279+01
3	Cristina Kupfer	mcmkupfer@gmail.com	\N	mcmkupfer@gmail.com	monthly	\N	f	\N	\N	2025-07-21 22:18:02.281345+01
4	Daniel Kupfer	daniel@kupfer.co	\N	daniel@kupfer.co	monthly	\N	f	\N	\N	2025-07-22 18:45:28.654066+01
2	Dr. Daniel Kupfer	dnkupfer@gmail.com	+447866750132	6f3842a5e7b8b63095e840cc28684fd52e17ff25ef173e49b2e5219ed676f652@group.calendar.google.com	monthly	180.00	t	\N	\N	2024-12-01 11:00:00+00
\.


--
-- Data for Name: user_credentials; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.user_credentials (id, email, password_hash, display_name, google_permissions_granted, google_access_token, google_refresh_token, google_token_expires_at, google_permissions_granted_at, is_active, email_verified, email_verification_token, email_verified_at, password_reset_token, password_reset_expires_at, created_at, updated_at, last_login_at) FROM stdin;
1	terapeuta@example.com	temp_1753465317.539394_0.7943393369434126	Dr. Exemplo Terapeuta	f	\N	\N	\N	\N	t	f	\N	\N	\N	\N	2025-07-25 18:41:57.539394+01	2025-07-25 18:41:57.539394+01	\N
5	dan@kupfer.co	temp_1753465317.551866_0.6700893590893777	Dan Kupfer (Super Admin)	f	\N	\N	\N	\N	t	t	\N	\N	\N	\N	2025-07-25 18:41:57.551866+01	2025-07-25 18:41:57.551866+01	\N
3	daniel@kupfer.co	$2b$12$74wg6tO2hd9G.bIf/CsB9OPjKHui/7R0ViPoAdt98cKOFpEPz.MmO	Daniel Kupfer	f	\N	\N	\N	\N	t	t	\N	\N	\N	\N	2025-07-25 18:41:57.539394+01	2025-07-25 19:32:25.652631+01	2025-07-25 19:32:25.652631+01
2	mcmkupfer@gmail.com	$2b$12$siI0220duwYOm1Ly4zmHvewcxw6YVlnWBQzLycu4ERFVf/PVWQRXe	Cristina Kupfer	f	\N	\N	\N	\N	t	t	\N	\N	\N	\N	2025-07-25 18:41:57.539394+01	2025-07-27 14:39:40.704719+01	2025-07-27 14:39:40.704719+01
4	dnkupfer@gmail.com	$2b$12$GO1isTjyHjURCge3561Or.T8FKxfFLG50WkHrFDekKkuLedj.Y2Mi	Dr. Daniel Kupfer	f	\N	\N	\N	\N	t	t	\N	\N	\N	\N	2025-07-25 18:41:57.539394+01	2025-07-27 20:14:19.381074+01	2025-07-27 20:14:19.381074+01
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.user_permissions (id, user_id, therapist_id, role, granted_by, granted_at, expires_at, is_active, notes) FROM stdin;
1	1	1	owner	1	2025-07-25 18:41:57.539394+01	\N	t	Migrated from existing therapist account
2	2	3	owner	2	2025-07-25 18:41:57.539394+01	\N	t	Migrated from existing therapist account
3	3	4	owner	3	2025-07-25 18:41:57.539394+01	\N	t	Migrated from existing therapist account
4	4	2	owner	4	2025-07-25 18:41:57.539394+01	\N	t	Migrated from existing therapist account
5	5	1	super_admin	5	2025-07-25 18:41:57.551866+01	\N	t	Initial super admin setup for system owner
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: dankupfer
--

COPY public.user_sessions (id, user_id, session_token, inactive_timeout_minutes, warning_timeout_minutes, max_session_hours, created_at, last_activity_at, expires_at, status, terminated_at, termination_reason, ip_address, user_agent, device_fingerprint) FROM stdin;
2	3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInNlc3Npb25JZCI6MiwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NjgzNDUsImV4cCI6MTc1MzQ3MTk0NX0.iSgnLaLEidW5AwxpWUe5I9QV64zoXEgh5214o-ZOkMU	\N	\N	\N	2025-07-25 19:32:25.622701+01	2025-07-25 19:32:25.622701+01	2025-07-26 03:32:25.622+01	expired	2025-07-25 19:32:47.419506+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
1	3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInNlc3Npb25JZCI6MSwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NjYwOTgsImV4cCI6MTc1MzQ2OTY5OH0.-AIPYc0VR9sC_Vmqzz23ctEs3tBx7Pr5HGI0vXwNv-I	2	1	\N	2025-07-25 18:54:58.331473+01	2025-07-25 18:54:58.331473+01	2025-07-25 18:56:58.331473+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	curl/8.7.1	\N
3	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MywidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0Njk0MzAsImV4cCI6MTc1MzQ3MzAzMH0.R8keE_BD6vYDZUsuNMPRvgiLLdnqdJ9KP0CQVJriXtU	\N	\N	\N	2025-07-25 19:50:30.201913+01	2025-07-25 19:50:30.201913+01	2025-07-26 03:50:30.201+01	expired	2025-07-25 19:50:30.266873+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
4	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NCwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NzA1NjYsImV4cCI6MTc1MzQ3NDE2Nn0.26gBoJ3JDIzl2OKJAB9wisUYKKl9YCxRZfw2BZjm3-w	\N	\N	\N	2025-07-25 20:09:26.046299+01	2025-07-25 20:09:26.046299+01	2025-07-26 04:09:26.046+01	expired	2025-07-25 20:09:26.119878+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
5	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NSwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NzEyMzQsImV4cCI6MTc1MzQ3NDgzNH0.lhnDRdah7cc3dADr8sFESeYTHjXHmlyMhT5BmQYqk9E	\N	\N	\N	2025-07-25 20:20:34.658796+01	2025-07-25 20:20:34.658796+01	2025-07-26 04:20:34.658+01	expired	2025-07-25 20:20:44.122393+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
6	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NiwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NzEzMjMsImV4cCI6MTc1MzQ3NDkyM30.pwj1XYf16TajbEbzpfmUvd7wjdXeMRgXUdfWccFQ6EY	\N	\N	\N	2025-07-25 20:22:03.750222+01	2025-07-25 20:22:03.750222+01	2025-07-26 04:22:03.75+01	expired	2025-07-25 20:22:33.779761+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
7	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NywidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NzEzODMsImV4cCI6MTc1MzQ3NDk4M30.tR62XMdjIypYU7FseKYDW_kavmi_4J6Z9JzVbP5iXhI	\N	\N	\N	2025-07-25 20:23:03.141514+01	2025-07-25 20:23:03.141514+01	2025-07-26 04:23:03.141+01	expired	2025-07-25 20:23:05.676026+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
8	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OCwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NzE1MDMsImV4cCI6MTc1MzQ3NTEwM30.-MBG9oC87RBOiq_xcjY8-DyqXBoEuDDA3N-ygYMljko	\N	\N	\N	2025-07-25 20:25:03.010884+01	2025-07-25 20:25:03.010884+01	2025-07-26 04:25:03.01+01	expired	2025-07-25 20:25:04.613309+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
9	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OSwidHlwZSI6InNlc3Npb24iLCJpYXQiOjE3NTM0NzE1MTcsImV4cCI6MTc1MzQ3NTExN30.wIxttp6_MPrXxQL3HQJyN9a9OnMeoI4Afs4iUBC-ukI	\N	\N	\N	2025-07-25 20:25:17.900355+01	2025-07-25 20:25:17.900355+01	2025-07-26 04:25:17.9+01	expired	2025-07-25 20:25:33.102384+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
10	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcxNjk2LCJleHAiOjE3NTM0NzUyOTZ9.V7CdhJvwSTwKPgzShBZiVK7DjrQQ6KYs0GficKMQg_w	\N	\N	\N	2025-07-25 20:28:16.941393+01	2025-07-25 20:28:16.941393+01	2025-07-26 04:28:16.941+01	expired	2025-07-25 20:28:18.698617+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
11	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcxODQ1LCJleHAiOjE3NTM0NzU0NDV9.TuqUHZQQU0K7vrndrw4-stdk303kkVMfImzGip5bwew	\N	\N	\N	2025-07-25 20:30:45.038003+01	2025-07-25 20:30:45.038003+01	2025-07-26 04:30:45.037+01	expired	2025-07-25 20:30:46.174585+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
12	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcxODY3LCJleHAiOjE3NTM0NzU0Njd9.4RJ1pYsK-krMXQbVOUOqoGo5as4LFR430v1wu5V4bPU	\N	\N	\N	2025-07-25 20:31:07.4928+01	2025-07-25 20:31:07.4928+01	2025-07-26 04:31:07.492+01	expired	2025-07-25 20:31:37.520036+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
13	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcxOTA4LCJleHAiOjE3NTM0NzU1MDh9.fBmjLFc9e3GMMl3Ziu4UVGQQvIqeK7Td6iX7gVffF7s	\N	\N	\N	2025-07-25 20:31:48.46417+01	2025-07-25 20:31:48.46417+01	2025-07-26 04:31:48.464+01	expired	2025-07-25 20:31:55.342783+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
14	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcyMjgxLCJleHAiOjE3NTM0NzU4ODF9.1Hgd4ZHogMHOZS8Fk4hg4S6ixU5zvaAC-RJjYwWtE2U	\N	\N	\N	2025-07-25 20:38:01.583565+01	2025-07-25 20:38:01.583565+01	2025-07-26 04:38:01.583+01	expired	2025-07-25 20:38:02.877624+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
15	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcyMjg2LCJleHAiOjE3NTM0NzU4ODZ9.gySdMxuyzfp5SLJqm0UDRO2JhgOwyWvfFRzAWgrFbeg	\N	\N	\N	2025-07-25 20:38:06.986965+01	2025-07-25 20:38:06.986965+01	2025-07-26 04:38:06.986+01	expired	2025-07-25 20:38:12.04954+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
16	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcyMzU1LCJleHAiOjE3NTM0NzU5NTV9.A-2y-piI5XboFevX5n9oxNDkHmpCfUT4yuRZbipdll4	\N	\N	\N	2025-07-25 20:39:15.334981+01	2025-07-25 20:39:15.334981+01	2025-07-26 04:39:15.334+01	expired	2025-07-25 20:39:17.095088+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
17	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDcyNDg1LCJleHAiOjE3NTM0NzYwODV9.TlFka-iBI7FRodNbBxGlhVTfc9dpKN6Mdm71K9TZq2Y	\N	\N	\N	2025-07-25 20:41:25.750336+01	2025-07-25 20:41:25.750336+01	2025-07-26 04:41:25.75+01	expired	2025-07-25 20:42:38.28893+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
18	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDc1NTc5LCJleHAiOjE3NTM0NzkxNzl9.IKoactkWekjr4wxJeK_tmnN728KLWXiZw7QuKF4BVj4	\N	\N	\N	2025-07-25 21:32:59.868975+01	2025-07-25 21:32:59.868975+01	2025-07-26 05:32:59.868+01	expired	2025-07-25 21:34:18.802195+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
30	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI1MjQyLCJleHAiOjE3NTM1Mjg4NDJ9.dxhtyXgJbbwUPhd12eXUX0M5RF8EBKYvwTSCqEGBwY8	5	1	8	2025-07-26 11:20:42.163036+01	2025-07-26 11:20:42.163036+01	2025-07-26 19:20:42.162+01	expired	2025-07-26 11:26:12.131951+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
19	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDc1Njc0LCJleHAiOjE3NTM0NzkyNzR9.UGGaZfThnLypNHuP7U3uR1iicH3vC5jSBy7rhD9nCyI	\N	\N	\N	2025-07-25 21:34:34.292055+01	2025-07-25 21:34:34.292055+01	2025-07-26 05:34:34.291+01	expired	2025-07-25 21:35:05.190154+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
32	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI1ODU0LCJleHAiOjE3NTM1Mjk0NTR9.qhuP-ya7gVSfrOeo-T6VMXLdR8BWYVdcn5OGk0dQY1w	5	1	8	2025-07-26 11:30:54.99776+01	2025-07-26 11:30:54.99776+01	2025-07-26 19:30:54.997+01	terminated	2025-07-26 11:31:56.781498+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
20	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDc2MjM2LCJleHAiOjE3NTM0Nzk4MzZ9.BOC9HnFxmvmIChPF1kuwIIGOMv_S4YDENQHikBf49Tk	\N	\N	\N	2025-07-25 21:43:56.580899+01	2025-07-25 21:43:56.580899+01	2025-07-26 05:43:56.58+01	expired	2025-07-25 21:44:26.606257+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
90	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTU0NTAyLCJleHAiOjE3NTM1NTgxMDJ9.yogp9Hb6VuASkigW4hnc9psuHUVlowdG9MnkIV-SVSg	5	1	8	2025-07-26 19:28:22.438359+01	2025-07-26 19:37:24.487167+01	2025-07-27 03:37:24.487167+01	expired	2025-07-26 19:42:30.181847+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
21	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDc4MDIyLCJleHAiOjE3NTM0ODE2MjJ9.R9396TPJDRrdyPd797lQE8Sfx7YJhrCEDR953sBm5H8	5	1	8	2025-07-25 22:13:42.364063+01	2025-07-25 22:13:42.364063+01	2025-07-26 06:13:42.363+01	terminated	2025-07-25 22:13:59.488647+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
103	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTAzLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NTQ1OSwiZXhwIjoxNzUzNTY5MDU5fQ.vJyrL-wTuTiyJoURLoj7ZqN4hv0-Trie1PVl7WfTvHo	1	1	8	2025-07-26 22:30:59.79973+01	2025-07-26 22:31:32.358592+01	2025-07-27 06:31:32.358592+01	expired	2025-07-26 22:32:32.654192+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
34	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI1OTQyLCJleHAiOjE3NTM1Mjk1NDJ9.dosXP85MCasNmF-f2IaEJsu2ppB6GbT_thY0NXSRXUo	5	1	8	2025-07-26 11:32:22.851508+01	2025-07-26 11:32:22.851508+01	2025-07-26 19:32:22.851+01	expired	2025-07-26 11:37:22.994116+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
22	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDc4MDQ0LCJleHAiOjE3NTM0ODE2NDR9.-g5SYKQMhyR7s_xdqZkLaFDG1R0HODWkWJUda40L5GU	5	1	8	2025-07-25 22:14:04.038474+01	2025-07-25 22:14:04.038474+01	2025-07-26 06:14:04.038+01	expired	2025-07-25 22:19:24.278559+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
33	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI1OTIwLCJleHAiOjE3NTM1Mjk1MjB9.A3_C77U0oAsUKg-tw9ly_dJHtpCOh_4SIdcsc_H9su4	2	1	8	2025-07-26 11:32:00.817415+01	2025-07-26 11:32:00.817415+01	2025-07-26 11:34:00.817415+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
91	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTU5OTM2LCJleHAiOjE3NTM1NjM1MzZ9.XYwJdHhFWRJ5vJoV9iI5-Y4W9DrPf4rPD7MYzN3C_Co	1	1	8	2025-07-26 20:58:56.638725+01	2025-07-26 20:58:56.638725+01	2025-07-26 20:59:56.638725+01	expired	2025-07-26 21:03:56.695084+01	max_time_exceeded	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
35	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI2NTgwLCJleHAiOjE3NTM1MzAxODB9.DkIUj9r31wktSy-cL_mDHAMkdNm0NzRrxiNLmHcnzEE	5	1	8	2025-07-26 11:43:00.685753+01	2025-07-26 11:43:00.685753+01	2025-07-26 19:43:00.685+01	terminated	2025-07-26 11:46:28.043316+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
23	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNDc4NDk0LCJleHAiOjE3NTM0ODIwOTR9.kfW-811n8EZ8w_D4sh66uDhfHOWbTPDLhXfi5oJOCEM	5	1	8	2025-07-25 22:21:34.88459+01	2025-07-25 22:25:57.054242+01	2025-07-26 06:25:57.054242+01	terminated	2025-07-25 22:30:09.913959+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
99	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTY0NDY1LCJleHAiOjE3NTM1NjgwNjV9.WLoAnaR1bBwPb_p3By8E7xf6mI5r_V2C56QKcDbkCN8	1	1	8	2025-07-26 22:14:25.307469+01	2025-07-26 22:15:04.546047+01	2025-07-27 06:15:04.546047+01	expired	2025-07-26 22:16:10.552336+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
25	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTIxNDYyLCJleHAiOjE3NTM1MjUwNjJ9.imYtuD1kTCeNgDZWJeJDgrTGcLdObHwu8OEAgsWKWhU	2	1	8	2025-07-26 10:17:42.042845+01	2025-07-26 10:17:42.042845+01	2025-07-26 10:19:42.042845+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
28	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI0NjczLCJleHAiOjE3NTM1MjgyNzN9.lCxINFpquyqpZIFFPE7jLFT2OLADNz0wIbT4dymEzww	5	1	8	2025-07-26 11:11:13.214094+01	2025-07-26 11:11:13.214094+01	2025-07-26 19:11:13.213+01	expired	2025-07-26 11:18:48.749349+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
36	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI2Nzk1LCJleHAiOjE3NTM1MzAzOTV9.93IsWAc3ZwBR9slk3yaAX8DoWGUvNs_PsbhV7qn2g7Y	5	1	8	2025-07-26 11:46:35.128708+01	2025-07-26 11:46:35.128708+01	2025-07-26 19:46:35.128+01	expired	2025-07-26 11:52:12.276504+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
37	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI3NTU1LCJleHAiOjE3NTM1MzExNTV9.UMVHUXCEWeXdADeFkfMc3B97bvApLfcdAKwr3fUmORQ	5	1	8	2025-07-26 11:59:15.002937+01	2025-07-26 11:59:15.002937+01	2025-07-26 19:59:15.002+01	terminated	2025-07-26 12:01:07.825056+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
64	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0ODMyLCJleHAiOjE3NTM1Mzg0MzJ9.FGbsyP6nSgsQD-1H7oHIJjqD0avyWi89SWEAhFiKFbk	5	1	8	2025-07-26 14:00:32.75557+01	2025-07-26 14:00:32.75557+01	2025-07-26 22:00:32.755+01	terminated	2025-07-26 14:00:57.488942+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
132	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTMyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwODQxMCwiZXhwIjoxNzUzNjEyMDEwfQ.arbDVNkDStA_y4dqI_l0dIlDs-1l1gANmd4LlSfQzS8	2	1	8	2025-07-27 10:26:50.768355+01	2025-07-27 10:26:50.768355+01	2025-07-27 18:26:50.768+01	expired	2025-07-27 10:28:51.076027+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
38	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI3NjcxLCJleHAiOjE3NTM1MzEyNzF9.lR9evCqH-wk57B4DiDAp_68N78HN8g7g5gf8WMfyrqU	5	1	8	2025-07-26 12:01:11.286839+01	2025-07-26 12:01:11.286839+01	2025-07-26 20:01:11.286+01	terminated	2025-07-26 12:01:34.38686+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
39	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI3Njk3LCJleHAiOjE3NTM1MzEyOTd9.TaGkHuXvZuU9Z6q0oBVyMxhwCPExjtzgt1Ap4oA3_VE	5	1	8	2025-07-26 12:01:37.759071+01	2025-07-26 12:01:37.759071+01	2025-07-26 20:01:37.758+01	terminated	2025-07-26 12:05:08.435487+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
65	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0ODY0LCJleHAiOjE3NTM1Mzg0NjR9.rRSuFdyr7pqOxxyFAp_8ic5_rC9Z2xkCCBekXP6f-ME	5	1	8	2025-07-26 14:01:04.152744+01	2025-07-26 14:01:04.152744+01	2025-07-26 22:01:04.152+01	terminated	2025-07-26 14:01:33.458105+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
72	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1MjcyLCJleHAiOjE3NTM1Mzg4NzJ9.xmSSFTM7RdClRSnmcOtkCv6hS8JOOLnqNzU-sOfovUg	5	1	8	2025-07-26 14:07:52.2598+01	2025-07-26 14:07:52.2598+01	2025-07-26 22:07:52.259+01	terminated	2025-07-26 14:07:56.518764+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
40	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI3OTE1LCJleHAiOjE3NTM1MzE1MTV9.BmukR5bSuqvKd8x0BKcJJX6kajBYXRnFP6pUVCXe1G8	5	1	8	2025-07-26 12:05:15.46386+01	2025-07-26 12:10:01.012416+01	2025-07-26 20:10:01.012416+01	terminated	2025-07-26 12:14:21.386225+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
73	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1Mjc5LCJleHAiOjE3NTM1Mzg4Nzl9.Wl5PGfUHhy_eteyu1UKs-7WMrPBjGPDt7gf7Hc9MLdE	5	1	8	2025-07-26 14:07:59.412447+01	2025-07-26 14:07:59.412447+01	2025-07-26 22:07:59.412+01	terminated	2025-07-26 14:08:24.10698+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
79	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM3MjU5LCJleHAiOjE3NTM1NDA4NTl9.UFdmVbTH6axmED7eZcklnol4ha8LAycxzuc4pWwEWzw	5	1	8	2025-07-26 14:40:59.298228+01	2025-07-26 14:46:11.489244+01	2025-07-26 22:46:11.489244+01	expired	2025-07-26 14:51:53.686406+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
86	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTQyNDE3LCJleHAiOjE3NTM1NDYwMTd9.IhcEpic5Hze7tgy3ZeXHZbb1pT-o1_3PCBEjZMbwS44	5	1	8	2025-07-26 16:06:57.305843+01	2025-07-26 16:11:37.550529+01	2025-07-27 00:11:37.550529+01	expired	2025-07-26 16:16:53.801236+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
92	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTYwNTM5LCJleHAiOjE3NTM1NjQxMzl9.dWUq4h2ysp2XCAFReSB9t6dUQ9wCot0MJnGeZ2cy5B4	5	1	8	2025-07-26 21:08:59.295013+01	2025-07-26 21:15:19.091559+01	2025-07-27 05:15:19.091559+01	expired	2025-07-26 21:20:43.639221+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
109	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTA5LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2ODM1OCwiZXhwIjoxNzUzNTcxOTU4fQ.BSWuj9Km2pKtOsPJ7x9ciGQpqxAbUj8Yg8c8TDQBhAo	2	1	8	2025-07-26 23:19:18.188659+01	2025-07-26 23:27:23.237878+01	2025-07-27 07:19:18.188+01	terminated	2025-07-26 23:28:01.439751+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
100	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTAwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NDU4OCwiZXhwIjoxNzUzNTY4MTg4fQ.rx_nk8swCgObWVJrggwrdQFN3Q7TiJmhNoIhPki6KiQ	1	1	8	2025-07-26 22:16:28.075625+01	2025-07-26 22:17:44.514577+01	2025-07-27 06:17:44.514577+01	terminated	2025-07-26 22:18:12.629089+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
104	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTA0LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NTU2NSwiZXhwIjoxNzUzNTY5MTY1fQ.lY-uXrgEtQQy3Mf84hO-PD5cNvJtIEIcSaqJyM7j22w	2	1	8	2025-07-26 22:32:45.780401+01	2025-07-26 22:39:30.266704+01	2025-07-27 06:39:30.266704+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
29	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI1MjAzLCJleHAiOjE3NTM1Mjg4MDN9.6J71zY7PtKrXN-aZCx9R4ineXMXVot52hBD8OoxGkZ0	2	1	8	2025-07-26 11:20:03.993999+01	2025-07-26 11:20:03.993999+01	2025-07-26 11:22:03.993999+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
112	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTEyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU3MTE3OSwiZXhwIjoxNzUzNTc0Nzc5fQ.zmHfuKsE3gnvd7Jtmg-IIIC03gBavXyRipsw8oaOWTs	2	1	8	2025-07-27 00:06:19.780866+01	2025-07-27 00:11:18.383243+01	2025-07-27 08:06:19.78+01	expired	2025-07-27 00:16:39.057799+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
41	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI4NDY0LCJleHAiOjE3NTM1MzIwNjR9.zZzfG86UxfX7p7gdqZniyVcutc3UkS4l0rHlLJ6Qayw	5	1	8	2025-07-26 12:14:24.486923+01	2025-07-26 12:14:24.486923+01	2025-07-26 20:14:24.486+01	terminated	2025-07-26 12:14:36.604417+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
42	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI4NDc5LCJleHAiOjE3NTM1MzIwNzl9.sq9uLElzECNkli67bh8Bj3obgMwH4vUn0S3xc88b4mQ	5	1	8	2025-07-26 12:14:39.314391+01	2025-07-26 12:14:39.314391+01	2025-07-26 20:14:39.314+01	terminated	2025-07-26 12:18:18.473049+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
43	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMwMDk0LCJleHAiOjE3NTM1MzM2OTR9.3z78xrFbaI6sqF8G5pB9Qr9TQrGMTECCae4lUfzI3Gc	5	1	8	2025-07-26 12:41:34.575076+01	2025-07-26 12:41:34.575076+01	2025-07-26 20:41:34.574+01	terminated	2025-07-26 12:43:04.174023+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
66	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0OTA5LCJleHAiOjE3NTM1Mzg1MDl9.3N8z1W9a3abEwdQF2oTLTFYmqmRUwKscriMoHv3cl6c	5	1	8	2025-07-26 14:01:49.944557+01	2025-07-26 14:01:49.944557+01	2025-07-26 22:01:49.944+01	terminated	2025-07-26 14:02:08.165853+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
110	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTEwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2ODg5MSwiZXhwIjoxNzUzNTcyNDkxfQ.cQXtLkJl7YcLk4t2eH1sT22I-GoC64pbe4G6cQ9teJ8	2	1	8	2025-07-26 23:28:11.403281+01	2025-07-26 23:28:11.403281+01	2025-07-27 07:28:11.403+01	expired	2025-07-26 23:30:11.789645+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
44	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMwMTkyLCJleHAiOjE3NTM1MzM3OTJ9.smYL8edorx9iFEHN7Nsm7bhAFdg-p7hmCNXvMJ_ICjE	2	1	8	2025-07-26 12:43:12.842942+01	2025-07-26 12:43:12.842942+01	2025-07-26 12:45:12.842942+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
74	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1MzA4LCJleHAiOjE3NTM1Mzg5MDh9.0ztHo1qII5dwEfAog8OeHQqtS4wo47Wa1yr77ss37-c	5	1	8	2025-07-26 14:08:28.642817+01	2025-07-26 14:08:28.642817+01	2025-07-26 22:08:28.642+01	expired	2025-07-26 14:13:53.755665+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
93	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTYyNjEyLCJleHAiOjE3NTM1NjYyMTJ9.QJ0zqNwE9lpNUo6dgbkK7SHtprVV3R_rBVsLybycVLY	2	1	8	2025-07-26 21:43:32.687624+01	2025-07-26 21:47:58.624896+01	2025-07-26 21:49:58.624896+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
61	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0Njg1LCJleHAiOjE3NTM1MzgyODV9.4ICwPU_GjwCOcyUslRzV5ufsaUKBLhJfgsWe2KPutAs	2	1	8	2025-07-26 13:58:05.255127+01	2025-07-26 13:58:05.255127+01	2025-07-26 14:00:05.255127+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
80	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM5MTA2LCJleHAiOjE3NTM1NDI3MDZ9.IkrwTngAzRKyRlGyBwdqxjAtqmw0uBulzR8OYFC7qfo	5	1	8	2025-07-26 15:11:46.291021+01	2025-07-26 15:11:46.291021+01	2025-07-26 23:11:46.29+01	expired	2025-07-26 15:16:53.744396+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
87	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTUzNTMwLCJleHAiOjE3NTM1NTcxMzB9.c-73JwAG6STbEv5QJ0EncxzlW8rT2qMsqS_3vRfWJY4	5	1	8	2025-07-26 19:12:10.225529+01	2025-07-26 19:12:10.225529+01	2025-07-27 03:12:10.225+01	expired	2025-07-26 19:17:25.207006+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
118	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTE4LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwMzM4OCwiZXhwIjoxNzUzNjA2OTg4fQ.njS154sQAZeacz6q0CAXSJLTv-tYzqUNEiDAVWtbAz8	2	1	8	2025-07-27 09:03:08.570524+01	2025-07-27 09:10:21.215707+01	2025-07-27 17:03:08.57+01	expired	2025-07-27 09:12:22.462379+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
123	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTIzLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNTg1NSwiZXhwIjoxNzUzNjA5NDU1fQ.Ev-1hxDMyxI722fpOfO3t79edBCzjkjFGz81SXgRkBk	2	1	8	2025-07-27 09:44:15.43323+01	2025-07-27 09:49:10.872149+01	2025-07-27 17:44:15.432+01	terminated	2025-07-27 09:49:10.87783+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
113	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTEzLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU3MTgwNywiZXhwIjoxNzUzNTc1NDA3fQ.6EKyp3t-qujJIUXaGQFVeGLFthkpScWKlgj__cEX8gU	2	1	8	2025-07-27 00:16:47.371703+01	2025-07-27 00:21:50.264908+01	2025-07-27 08:16:47.371+01	expired	2025-07-27 00:23:51.702503+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
124	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTI0LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNjE1NiwiZXhwIjoxNzUzNjA5NzU2fQ.FlQvkXJaLgehL35dl1XuyX8IaKVv7qyjl676MOJb-f8	2	1	8	2025-07-27 09:49:16.976411+01	2025-07-27 09:49:16.976411+01	2025-07-27 17:49:16.976+01	expired	2025-07-27 09:51:17.019272+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
101	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTAxLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NDcwMSwiZXhwIjoxNzUzNTY4MzAxfQ.e4WfV4_ATJabb6MhcfUqJvnbq-2XXC1jsEWr0V4ozwY	1	1	8	2025-07-26 22:18:21.40927+01	2025-07-26 22:18:21.40927+01	2025-07-27 06:18:21.408+01	expired	2025-07-26 22:19:25.599147+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
129	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTI5LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNzMzMywiZXhwIjoxNzUzNjEwOTMzfQ.MudcHosV6E6RXz3QQo-KcN0S229EtbAoIswDRh2r0Dg	2	1	8	2025-07-27 10:08:53.240471+01	2025-07-27 10:09:13.09394+01	2025-07-27 18:08:53.239+01	expired	2025-07-27 10:11:14.502313+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
45	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMwNDEzLCJleHAiOjE3NTM1MzQwMTN9.NdX9WIy7VwrRVi24tpRya5KNRgj76C_SHv0X43vhpfM	5	1	8	2025-07-26 12:46:53.077889+01	2025-07-26 12:46:53.077889+01	2025-07-26 20:46:53.077+01	terminated	2025-07-26 12:47:07.740474+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
130	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTMwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNzgzOSwiZXhwIjoxNzUzNjExNDM5fQ.cUqs-g6olTmjHU5hoBBToQ42fcGSHDPRbUja7xX262M	2	1	8	2025-07-27 10:17:19.256754+01	2025-07-27 10:23:18.904587+01	2025-07-27 18:17:19.256+01	expired	2025-07-27 10:25:19.548677+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
102	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTAyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NDc3MiwiZXhwIjoxNzUzNTY4MzcyfQ.tLPt0n5ct65cQh_lmzHlCyy3wD_DLZSk-pLapWfEN1U	1	1	8	2025-07-26 22:19:32.000322+01	2025-07-26 22:19:32.000322+01	2025-07-27 06:19:32+01	expired	2025-07-26 22:20:32.710556+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
46	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMwNDMzLCJleHAiOjE3NTM1MzQwMzN9.7oDTfHl1oO9G3R4cLSRsf0J2yYuJnhGk0cEb9tDu80g	5	1	8	2025-07-26 12:47:13.666113+01	2025-07-26 12:47:13.666113+01	2025-07-26 20:47:13.665+01	terminated	2025-07-26 12:47:30.597386+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
67	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0OTM0LCJleHAiOjE3NTM1Mzg1MzR9.E1f8EOqivHcLkIC3u2xMsF-djOqrJsdgaLnCiVD3_n8	5	1	8	2025-07-26 14:02:14.480155+01	2025-07-26 14:02:14.480155+01	2025-07-26 22:02:14.48+01	terminated	2025-07-26 14:02:22.900617+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
47	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMwNDUzLCJleHAiOjE3NTM1MzQwNTN9.BcoZbTOY9POglLPVc7e0OCvDABrFbXMrTo2pxRo2CMQ	5	1	8	2025-07-26 12:47:33.659627+01	2025-07-26 12:47:33.659627+01	2025-07-26 20:47:33.659+01	expired	2025-07-26 12:52:54.586281+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
68	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0OTUxLCJleHAiOjE3NTM1Mzg1NTF9.obIe468WMXl6h0MvAsDd6aHG0hcrwfUdCHBAgvd7hO4	5	1	8	2025-07-26 14:02:31.232438+01	2025-07-26 14:02:31.232438+01	2025-07-26 22:02:31.232+01	terminated	2025-07-26 14:04:10.812919+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
94	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTYzMDUzLCJleHAiOjE3NTM1NjY2NTN9.JO5bZNNmZG9Sdc4m3jkoJWmkLZpdrSGWLahY6HpPfSM	5	1	8	2025-07-26 21:50:53.588848+01	2025-07-26 21:51:04.204977+01	2025-07-27 05:51:04.204977+01	expired	2025-07-26 21:56:31.755094+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
133	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTMzLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwODQ4NywiZXhwIjoxNzUzNjEyMDg3fQ.jZOtQStj5hj7kIaEqXLATc2nkpG3L8sFGsvPEjMoA88	2	1	8	2025-07-27 10:28:06.998905+01	2025-07-27 10:31:05.480358+01	2025-07-27 18:28:06.998+01	terminated	2025-07-27 10:31:07.462494+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
75	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1NzA4LCJleHAiOjE3NTM1MzkzMDh9.JS-GV_C3NTCp-3MAhFrQJ7cpU1jvLQOy9mTV8_FqGlo	5	1	8	2025-07-26 14:15:08.263365+01	2025-07-26 14:15:08.263365+01	2025-07-26 22:15:08.263+01	terminated	2025-07-26 14:15:50.110316+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
81	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM5NjI2LCJleHAiOjE3NTM1NDMyMjZ9.YUpqU4WXp_Smm-cudyA8RbvmkQLAqX1EcZZqRMn1uSE	5	1	8	2025-07-26 15:20:26.188794+01	2025-07-26 15:20:26.188794+01	2025-07-26 23:20:26.188+01	expired	2025-07-26 15:25:53.783831+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
119	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTE5LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNDA1NywiZXhwIjoxNzUzNjA3NjU3fQ.r8a0UTlcJEjmwUMjihc96HQPJOjXmEvA8-oQkTT9h3c	2	1	8	2025-07-27 09:14:17.477955+01	2025-07-27 09:20:29.196177+01	2025-07-27 17:14:17.477+01	terminated	2025-07-27 09:20:32.992132+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
105	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTA1LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NTk3NiwiZXhwIjoxNzUzNTY5NTc2fQ.S3tkILIj8UJrZIU7has8y_bq-00Oi80UCofTNcMIH-8	2	1	8	2025-07-26 22:39:36.075958+01	2025-07-26 22:44:43.514138+01	2025-07-27 06:44:43.514138+01	terminated	2025-07-26 22:45:37.702065+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
88	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTU0MDYzLCJleHAiOjE3NTM1NTc2NjN9.riwfsKSaqzIEU5vXWLL21TSoY2yKw2RYC7b7NCXQF0I	2	1	8	2025-07-26 19:21:03.091283+01	2025-07-26 19:21:03.091283+01	2025-07-26 19:23:03.091283+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
125	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTI1LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNjg0MCwiZXhwIjoxNzUzNjEwNDQwfQ.Qu7627UlUeQuNBvJzU-k7OgJ9tTyEAU8RQbFAhGf6jQ	2	1	8	2025-07-27 10:00:40.793897+01	2025-07-27 10:02:00.944558+01	2025-07-27 18:00:40.793+01	terminated	2025-07-27 10:04:00.42227+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
111	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTExLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2OTE4NCwiZXhwIjoxNzUzNTcyNzg0fQ.cgNHrWEzNQCTjUtmGe4jducje-5O7DkcrrjoTZjyYkY	2	1	8	2025-07-26 23:33:04.264208+01	2025-07-26 23:43:33.023119+01	2025-07-27 07:33:04.264+01	expired	2025-07-27 00:06:34.605883+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
114	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTE0LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU3MjEyMCwiZXhwIjoxNzUzNTc1NzIwfQ.lj8f4-vb8GMr8eht0pzyGkkCECam_uWwyYcLbZl_79M	2	1	8	2025-07-27 00:22:00.971112+01	2025-07-27 00:25:54.127767+01	2025-07-27 08:22:00.97+01	expired	2025-07-27 08:38:02.134839+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
48	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMxMDc4LCJleHAiOjE3NTM1MzQ2Nzh9.P43NBIPeBRTs5IggjkoCju6d47VydcnNN3-Mnpe6-k4	5	1	8	2025-07-26 12:57:58.264593+01	2025-07-26 12:57:58.264593+01	2025-07-26 20:57:58.264+01	terminated	2025-07-26 12:58:04.239549+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
49	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NDksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMxMDg3LCJleHAiOjE3NTM1MzQ2ODd9.BCqx80SF51Qr1DChW4tCwbvVd7Eu5Y48ARSLKxUKWGk	5	1	8	2025-07-26 12:58:07.399888+01	2025-07-26 12:58:07.399888+01	2025-07-26 20:58:07.399+01	terminated	2025-07-26 12:59:03.712093+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
50	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMxMTQ2LCJleHAiOjE3NTM1MzQ3NDZ9.-zPuKeFkOFR82QmMRE1-97Qmm249FgluiN8_jqLNVRo	5	1	8	2025-07-26 12:59:06.529133+01	2025-07-26 12:59:06.529133+01	2025-07-26 20:59:06.529+01	terminated	2025-07-26 13:02:57.487749+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
69	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1MDU2LCJleHAiOjE3NTM1Mzg2NTZ9.EcFRdL1RS4eOOwhvE1V43Uvq1Rn_bs-ANPEEp3rNODQ	5	1	8	2025-07-26 14:04:16.022992+01	2025-07-26 14:04:16.022992+01	2025-07-26 22:04:16.022+01	terminated	2025-07-26 14:05:11.361755+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
51	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMxMzgwLCJleHAiOjE3NTM1MzQ5ODB9.uj2KxFnOyGwBfr0lYlV7m98r1SMFSombdQ-vJvd2qOo	5	1	8	2025-07-26 13:03:00.266354+01	2025-07-26 13:03:00.266354+01	2025-07-26 21:03:00.266+01	expired	2025-07-26 13:28:12.623913+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
52	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTMzNzAzLCJleHAiOjE3NTM1MzczMDN9.5E3spS3PUNq_dGg08Wsxrj00DR-XQIjpYpYMFPtkCRE	5	1	8	2025-07-26 13:41:43.122935+01	2025-07-26 13:41:43.122935+01	2025-07-26 21:41:43.122+01	expired	2025-07-26 13:47:21.797302+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
76	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1NzYwLCJleHAiOjE3NTM1MzkzNjB9.SboH70Trea8kYGGsGftl50BiWOhYskoif9IoDH2sX4Q	5	1	8	2025-07-26 14:16:00.220415+01	2025-07-26 14:16:00.220415+01	2025-07-26 22:16:00.22+01	terminated	2025-07-26 14:18:31.079506+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
53	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0MDQ1LCJleHAiOjE3NTM1Mzc2NDV9.BPux-98THy0d6su8dfV-fxmDeudf3HsjyERV3mFl8gw	5	1	8	2025-07-26 13:47:25.275591+01	2025-07-26 13:47:25.275591+01	2025-07-26 21:47:25.275+01	terminated	2025-07-26 13:48:44.437469+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
106	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTA2LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NjQ2NSwiZXhwIjoxNzUzNTcwMDY1fQ.fA1EYFl5s8zcvUr-jOrdXyDjsK5-MQl86AuKL4rY2r4	2	1	8	2025-07-26 22:47:45.119171+01	2025-07-26 22:47:45.473786+01	2025-07-27 06:47:45.473786+01	expired	2025-07-26 22:49:45.632878+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
82	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTQwNDQwLCJleHAiOjE3NTM1NDQwNDB9.a0bQdHuf75rK-q70n-x1A-JfB8CxnWpj0DLk_mWckU0	5	1	8	2025-07-26 15:34:00.562973+01	2025-07-26 15:34:00.562973+01	2025-07-26 23:34:00.562+01	terminated	2025-07-26 15:34:08.999462+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
95	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTYzNTcxLCJleHAiOjE3NTM1NjcxNzF9.J9qjCD565JzrlqtZ5540UmwgbogxSM6QVkExKSUEj1g	2	1	8	2025-07-26 21:59:31.374303+01	2025-07-26 21:59:48.980734+01	2025-07-26 22:01:48.980734+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
120	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTIwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNDQzNywiZXhwIjoxNzUzNjA4MDM3fQ.duulLPlMVDQke2mant8hQL-YaQ0xJpvATM3roLsfnb8	2	1	8	2025-07-27 09:20:37.455941+01	2025-07-27 09:23:11.354134+01	2025-07-27 17:20:37.455+01	terminated	2025-07-27 09:23:17.624491+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
83	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTQwNDUzLCJleHAiOjE3NTM1NDQwNTN9.qF1UpBkOYM1pVPqrGHuEpGXOd9ZX9Ayec67m1dDln5s	5	1	8	2025-07-26 15:34:13.772195+01	2025-07-26 15:39:16.637107+01	2025-07-26 23:39:16.637107+01	terminated	2025-07-26 15:43:20.850348+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
89	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTU0MTI1LCJleHAiOjE3NTM1NTc3MjV9.RKz3U3B57dCqBMQjvPJnjXdn5kV1PK8wq_Omv52iGr0	5	1	8	2025-07-26 19:22:05.125545+01	2025-07-26 19:22:05.125545+01	2025-07-27 03:22:05.125+01	expired	2025-07-26 19:27:30.202384+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
126	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTI2LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNzA3OSwiZXhwIjoxNzUzNjEwNjc5fQ.nVUJJ6cUAizfXlfNnmXKybN1LfnM6PrS50f96LpSK0E	2	1	8	2025-07-27 10:04:39.33486+01	2025-07-27 10:06:04.7206+01	2025-07-27 18:04:39.334+01	expired	2025-07-27 10:08:04.733371+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
96	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTYzNTk2LCJleHAiOjE3NTM1NjcxOTZ9.butA66_r3A_0WK2n9yAj4LWsC3QCjIKhMkz1UJT6hOY	1	1	8	2025-07-26 21:59:56.205633+01	2025-07-26 22:01:29.900017+01	2025-07-27 06:01:29.900017+01	expired	2025-07-26 22:02:34.546027+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
115	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTE1LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwMTg1NywiZXhwIjoxNzUzNjA1NDU3fQ.KpPk5wC4TXAhV3QVxEveaX75kARDHrayCPEsKDP0MI8	2	1	8	2025-07-27 08:37:37.880564+01	2025-07-27 08:44:15.367064+01	2025-07-27 16:37:37.88+01	expired	2025-07-27 08:46:19.392689+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
54	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0MTI3LCJleHAiOjE3NTM1Mzc3Mjd9.ikSo7xXKx7U3Fccjc-QR37TMDmyFGCWOh1SkDQLVYgY	5	1	8	2025-07-26 13:48:47.716192+01	2025-07-26 13:48:47.716192+01	2025-07-26 21:48:47.716+01	terminated	2025-07-26 13:48:52.505953+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
107	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTA3LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2Njg0NSwiZXhwIjoxNzUzNTcwNDQ1fQ.HcjYggxK8A-cS2z7ELprZO_O_3RnGlNppXvKLTEiIM0	2	1	8	2025-07-26 22:54:05.883549+01	2025-07-26 22:57:35.314269+01	2025-07-27 06:54:05.883+01	expired	2025-07-26 23:03:54.16323+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
143	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQzLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMjc4MCwiZXhwIjoxNzUzNjE2MzgwfQ.jWOXMqkT-SylKm5tpPCSzsE4XcP6GQEw33lbkVe-Sto	2	1	8	2025-07-27 11:39:40.599901+01	2025-07-27 11:42:32.969812+01	2025-07-27 19:39:40.599+01	terminated	2025-07-27 11:42:37.473441+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
55	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0MTM2LCJleHAiOjE3NTM1Mzc3MzZ9.f2SxIDnYdO1vTQQPRnBBABRHrg2DrwcK6nriY3pCaqk	5	1	8	2025-07-26 13:48:56.468582+01	2025-07-26 13:48:56.468582+01	2025-07-26 21:48:56.468+01	terminated	2025-07-26 13:49:47.859709+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
56	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0MTkwLCJleHAiOjE3NTM1Mzc3OTB9.kIz6c_5BdSXdtimF2JsTFPM41plpyDoFQlVcQFeplmI	5	1	8	2025-07-26 13:49:50.624769+01	2025-07-26 13:49:50.624769+01	2025-07-26 21:49:50.624+01	terminated	2025-07-26 13:51:12.805758+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
70	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1MTQ5LCJleHAiOjE3NTM1Mzg3NDl9.1084u4dtAat5zXDADat-hof3cDduf9TgNhj-46ZlvU0	5	1	8	2025-07-26 14:05:49.272594+01	2025-07-26 14:05:49.272594+01	2025-07-26 22:05:49.272+01	terminated	2025-07-26 14:06:10.62026+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
57	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0Mjc1LCJleHAiOjE3NTM1Mzc4NzV9.WB3kciyFujxwokb57sMTY5b_COqsJPxjyH9kbKzv37g	5	1	8	2025-07-26 13:51:15.69057+01	2025-07-26 13:51:15.69057+01	2025-07-26 21:51:15.69+01	terminated	2025-07-26 13:54:19.06168+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
58	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0NDY2LCJleHAiOjE3NTM1MzgwNjZ9.Xpc2-BdsDu0f81HokXt5vepP0YVfZt39azDuz-VoZ_o	5	1	8	2025-07-26 13:54:26.002575+01	2025-07-26 13:54:26.002575+01	2025-07-26 21:54:26.002+01	terminated	2025-07-26 13:54:40.002668+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
77	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1OTE1LCJleHAiOjE3NTM1Mzk1MTV9._JUSRyu5uXqBx4dvSjHO_gZqwVOrpWwMxdXFAMRqn4A	5	1	8	2025-07-26 14:18:35.095662+01	2025-07-26 14:18:35.095662+01	2025-07-26 22:18:35.095+01	expired	2025-07-26 14:23:36.70793+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
59	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NTksInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0NDg2LCJleHAiOjE3NTM1MzgwODZ9.-sSWU9LhiKsJhctf8hMVf0UPfBJKPvvdhHNMZAbYP2s	5	1	8	2025-07-26 13:54:46.335615+01	2025-07-26 13:54:46.335615+01	2025-07-26 21:54:46.335+01	terminated	2025-07-26 13:55:01.596471+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
60	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjAsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0NTA2LCJleHAiOjE3NTM1MzgxMDZ9.8PT84A-nM_KjLCPY1iQIsU16cQajQdmRQWiWt0rz4wo	5	1	8	2025-07-26 13:55:06.010137+01	2025-07-26 13:55:06.010137+01	2025-07-26 21:55:06.01+01	terminated	2025-07-26 13:58:02.341001+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
116	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTE2LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwMjM5NSwiZXhwIjoxNzUzNjA1OTk1fQ.IeTFLU4FwLF5NC6TJKVx7HUL8gBfI6Po65gUJ0VMHTs	2	1	8	2025-07-27 08:46:35.10517+01	2025-07-27 08:46:54.031942+01	2025-07-27 16:46:35.104+01	expired	2025-07-27 08:49:01.48345+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
97	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTYzNzc2LCJleHAiOjE3NTM1NjczNzZ9.CYqS8LKbbkGqIjnFPG9nezgkf0LAe04T7_jXijUZEeg	1	1	8	2025-07-26 22:02:56.077187+01	2025-07-26 22:02:56.077187+01	2025-07-27 06:02:56.077+01	expired	2025-07-26 22:03:56.670696+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
84	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTQxMDA2LCJleHAiOjE3NTM1NDQ2MDZ9.4CSqJG6qoy9GzbRDW7wgfo5nsULyUYFM7VQMddjRezw	5	1	8	2025-07-26 15:43:26.614422+01	2025-07-26 15:43:26.614422+01	2025-07-26 23:43:26.614+01	terminated	2025-07-26 15:46:59.800061+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
121	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTIxLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNDkyNSwiZXhwIjoxNzUzNjA4NTI1fQ.9_kh7iX82pu1mMJ6GofXV_N7a1ZhH88LCYHlDKJQbaA	2	1	8	2025-07-27 09:28:45.262388+01	2025-07-27 09:31:11.883359+01	2025-07-27 17:28:45.262+01	expired	2025-07-27 09:33:13.769377+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
127	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTI3LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNzE5NCwiZXhwIjoxNzUzNjEwNzk0fQ.wtrwJcNRHwcJ7Zh1hUgbjht_bx9x-zkQOpl3HH3Ve60	2	1	8	2025-07-27 10:06:34.488827+01	2025-07-27 10:06:34.488827+01	2025-07-27 18:06:34.488+01	expired	2025-07-27 10:08:59.665379+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
31	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MzEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI1NzI2LCJleHAiOjE3NTM1MjkzMjZ9.uNSAIKIRV8iDAzPfYw944zPFROehKssW_O5aoi2sCpA	2	1	8	2025-07-26 11:28:46.710426+01	2025-07-26 11:28:46.710426+01	2025-07-26 11:30:46.710426+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
24	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjQsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTIxNDEzLCJleHAiOjE3NTM1MjUwMTN9.JR9fqDHtizBWcZoC2c411iV5YsFSDPSO6xjIFzcBMQI	2	1	8	2025-07-26 10:16:53.22154+01	2025-07-26 10:16:53.22154+01	2025-07-26 10:18:53.22154+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
62	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjIsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0NzMzLCJleHAiOjE3NTM1MzgzMzN9.5V6_dD4qdtB5rkJLCQKRb-XhGEE7rizkjB0B6V4pKGA	5	1	8	2025-07-26 13:58:53.157982+01	2025-07-26 13:58:53.157982+01	2025-07-26 21:58:53.157+01	terminated	2025-07-26 13:59:31.55327+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
63	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NjMsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM0Nzc0LCJleHAiOjE3NTM1MzgzNzR9.Rw7-UxizzAsTHbX79tqFkC7kUYvSA-R5d-auLlv1-eQ	5	1	8	2025-07-26 13:59:34.917504+01	2025-07-26 13:59:34.917504+01	2025-07-26 21:59:34.917+01	terminated	2025-07-26 14:00:27.784467+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
131	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTMxLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwODIyMCwiZXhwIjoxNzUzNjExODIwfQ.5Y542NHwFFFpHc6mHx9FD029Od_hCdJIn8uWMIgYn9U	2	1	8	2025-07-27 10:23:40.417759+01	2025-07-27 10:23:42.784726+01	2025-07-27 18:23:40.417+01	expired	2025-07-27 10:25:45.957803+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
134	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTM0LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwODY3MywiZXhwIjoxNzUzNjEyMjczfQ.uYmWDuOwuby7MUlFk4No7w4xlfTz1RTToOkwr3ki-UI	2	1	8	2025-07-27 10:31:13.95985+01	2025-07-27 10:31:34.057778+01	2025-07-27 18:31:13.959+01	expired	2025-07-27 10:37:52.183982+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
71	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzEsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM1MTczLCJleHAiOjE3NTM1Mzg3NzN9.Gi-DFS2w3XlgdjVb49TSH_82DqsSZOMHS6NMuj27jc0	5	1	8	2025-07-26 14:06:13.469935+01	2025-07-26 14:06:13.469935+01	2025-07-26 22:06:13.469+01	terminated	2025-07-26 14:07:47.770177+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
135	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTM1LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwOTE2NCwiZXhwIjoxNzUzNjEyNzY0fQ.3KJgDXVQGiNyh6lThtvpG0sthY5xH7tPek8lo3hW62o	2	1	8	2025-07-27 10:39:24.513784+01	2025-07-27 10:39:47.421789+01	2025-07-27 18:39:24.513+01	expired	2025-07-27 10:41:51.113109+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
163	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTYzLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMjU5MSwiZXhwIjoxNzUzNjI2MTkxfQ.fbprYdIEoN8Lva5dDx30aUeMMAP1CdSHR7VUaDqXmyY	2	1	8	2025-07-27 14:23:11.204839+01	2025-07-27 14:24:17.434458+01	2025-07-27 22:23:11.204+01	terminated	2025-07-27 14:24:24.747591+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
78	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6NzgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTM2NzgyLCJleHAiOjE3NTM1NDAzODJ9.aGmrgQJOzMsxTLpm5kpRiL077dlVa-O1cLX0JR4IB40	5	1	8	2025-07-26 14:33:02.093806+01	2025-07-26 14:33:02.093806+01	2025-07-26 22:33:02.093+01	expired	2025-07-26 14:39:07.050211+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
85	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6ODUsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTQxMjI3LCJleHAiOjE3NTM1NDQ4Mjd9.yHUmMd0tNzn5tCrMWQ4Em_dRX5bmFL6-FZInVFeHG1c	5	1	8	2025-07-26 15:47:07.207622+01	2025-07-26 15:47:07.207622+01	2025-07-26 23:47:07.207+01	terminated	2025-07-26 15:47:12.005094+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
136	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTM2LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwOTQ0OCwiZXhwIjoxNzUzNjEzMDQ4fQ.vLdBBTxq9rO03HbYuX0iWD3b8rk606RqiimMgSkR0ZI	2	1	8	2025-07-27 10:44:08.888668+01	2025-07-27 10:47:57.958142+01	2025-07-27 18:44:08.888+01	expired	2025-07-27 10:49:58.860014+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
98	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6OTgsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTYzOTAxLCJleHAiOjE3NTM1Njc1MDF9.KuJIdZ9jLnWr24zAdTngpxE7IDtPmKkTH-BSUMR_Hx0	1	1	8	2025-07-26 22:05:01.845611+01	2025-07-26 22:06:07.309182+01	2025-07-27 06:06:07.309182+01	expired	2025-07-26 22:07:24.709588+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
108	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTA4LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzU2NzA2NCwiZXhwIjoxNzUzNTcwNjY0fQ.gGQZ6JXtnR-kce36H24hmKhti3ZeZcFvdR_Y-EsLAww	2	1	8	2025-07-26 22:57:44.747032+01	2025-07-26 23:05:02.862487+01	2025-07-27 06:57:44.746+01	expired	2025-07-26 23:07:31.56862+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
137	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTM3LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwOTkxOSwiZXhwIjoxNzUzNjEzNTE5fQ.GoMArHj5Sb1s9eEEnGDFh4yQoeFCyjNErTrBGicfKYI	2	1	8	2025-07-27 10:51:59.02636+01	2025-07-27 10:53:14.729643+01	2025-07-27 18:51:59.026+01	expired	2025-07-27 10:55:17.054757+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
26	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjYsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTIxNTkwLCJleHAiOjE3NTM1MjUxOTB9.WjO_x0pd1WsmkaEgmAjWijKYUfdiCEZlsVYwOioQxBI	2	1	8	2025-07-26 10:19:50.137069+01	2025-07-26 10:19:50.137069+01	2025-07-26 10:21:50.137069+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
27	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MjcsInR5cGUiOiJzZXNzaW9uIiwiaWF0IjoxNzUzNTI0NTgzLCJleHAiOjE3NTM1MjgxODN9.hBKuvXz67cjfdn-Z8aotuMvX9o2vtlwERAsfdVjwF8o	2	1	8	2025-07-26 11:09:43.866371+01	2025-07-26 11:09:43.866371+01	2025-07-26 11:11:43.866371+01	expired	2025-07-26 22:58:54.164938+01	automatic_cleanup	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
117	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTE3LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwMjcyNCwiZXhwIjoxNzUzNjA2MzI0fQ.DaK_z2_vTiLdKIvLQRmPleoMsKoCJEck1GdTdcnzwrM	2	1	8	2025-07-27 08:52:04.833638+01	2025-07-27 08:54:58.299181+01	2025-07-27 16:52:04.833+01	expired	2025-07-27 08:57:01.482931+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
122	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTIyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNTIwMSwiZXhwIjoxNzUzNjA4ODAxfQ.7TouZ1h-SWNEBbzW3eeKDhrbThwT8x_SbRM3u2NtyeY	2	1	8	2025-07-27 09:33:21.516756+01	2025-07-27 09:41:06.2804+01	2025-07-27 17:33:21.516+01	expired	2025-07-27 09:43:08.483267+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
128	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTI4LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYwNzI3NSwiZXhwIjoxNzUzNjEwODc1fQ.1kNOSrePx8OPG7iibnuoKNRcpBZhVhqDhNDY5njUSQk	2	1	8	2025-07-27 10:07:55.544552+01	2025-07-27 10:07:55.544552+01	2025-07-27 18:07:55.544+01	expired	2025-07-27 10:09:57.690589+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
138	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTM4LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMDI4NCwiZXhwIjoxNzUzNjEzODg0fQ.uSxytVedF-FSzKNlbBYtlcsERzWwx5VwTJEg5PV5HcM	2	1	8	2025-07-27 10:58:04.708611+01	2025-07-27 11:00:53.872451+01	2025-07-27 18:58:04.708+01	terminated	2025-07-27 11:01:15.352236+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
172	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTcyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzY0MzY1OSwiZXhwIjoxNzUzNjQ3MjU5fQ.oj2GQf55dsy918VhLF-5ZV3Bnn94Q12xTDmBqh0rpq0	30	2	8	2025-07-27 20:14:19.372521+01	2025-07-27 20:21:07.286407+01	2025-07-28 04:14:19.372+01	active	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
144	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQ0LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMzAxOSwiZXhwIjoxNzUzNjE2NjE5fQ.TuVSWUvIBJGjfiR2yp25rQDKOm3Mn8EWDYq-JShU0B8	2	1	8	2025-07-27 11:43:39.638026+01	2025-07-27 11:47:16.707448+01	2025-07-27 19:43:39.637+01	terminated	2025-07-27 11:47:54.97673+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
149	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTQ5LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxOTQ2NSwiZXhwIjoxNzUzNjIzMDY1fQ.0r78Eas_9osvfl5f46hNJGZjjJhGnWZXL4VCr0clKPs	2	1	8	2025-07-27 13:31:05.112+01	2025-07-27 13:32:29.849323+01	2025-07-27 21:31:05.111+01	terminated	2025-07-27 13:32:29.8626+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
154	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTU0LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMDUyNCwiZXhwIjoxNzUzNjI0MTI0fQ.grmcBMmiPQfP2vV6bFOWYx5nVnY2tav9nqgnzqJF9jo	2	1	8	2025-07-27 13:48:44.881868+01	2025-07-27 13:51:02.558685+01	2025-07-27 21:48:44.881+01	terminated	2025-07-27 13:52:52.392386+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
158	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTU4LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMTY0MiwiZXhwIjoxNzUzNjI1MjQyfQ.p-2TRlUpbdLv-qLriRuxWw6TRhB40fRnxOJlx4X0Z8Q	2	1	8	2025-07-27 14:07:22.435186+01	2025-07-27 14:17:58.977741+01	2025-07-27 22:07:22.435+01	expired	2025-07-27 14:19:59.58902+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
164	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTY0LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMjY2OCwiZXhwIjoxNzUzNjI2MjY4fQ.VJw5U0dGwy8ZRcuytgAABTBCoc5MdP-BpmXBl2MlU5M	2	1	8	2025-07-27 14:24:28.384466+01	2025-07-27 14:24:38.54503+01	2025-07-27 22:24:28.384+01	terminated	2025-07-27 14:24:44.501282+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
165	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTY1LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMjY4OCwiZXhwIjoxNzUzNjI2Mjg4fQ.xUM822O1C1c_E7V_-F5PlmPpQ3KnnWOrWuZQBwHJzbI	2	1	8	2025-07-27 14:24:48.333744+01	2025-07-27 14:26:24.114621+01	2025-07-27 22:24:48.333+01	expired	2025-07-27 14:28:28.729345+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
155	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTU1LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMDc3OCwiZXhwIjoxNzUzNjI0Mzc4fQ.rGZ08R83oS0OJAsuHm13rrQPBnrsP2sQgD-KiSj83uo	2	1	8	2025-07-27 13:52:58.733568+01	2025-07-27 13:52:58.733568+01	2025-07-27 21:52:58.733+01	expired	2025-07-27 14:02:16.294588+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
157	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTU3LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMTU3NSwiZXhwIjoxNzUzNjI1MTc1fQ.y-DWoY1myxG-jHgUwXZ8Sal7V6i_XWNw-LBoFIsVWrQ	2	1	8	2025-07-27 14:06:15.711398+01	2025-07-27 14:06:15.711398+01	2025-07-27 22:06:15.711+01	expired	2025-07-27 14:11:47.520935+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
145	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQ1LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMzYxNCwiZXhwIjoxNzUzNjE3MjE0fQ.JHsDSynGfgMQsdUYuCCs1pJyaEdk1N03x1RQlazOY30	2	1	8	2025-07-27 11:53:34.855412+01	2025-07-27 11:53:34.855412+01	2025-07-27 19:53:34.855+01	expired	2025-07-27 11:55:35.123619+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
166	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTY2LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMzE1MCwiZXhwIjoxNzUzNjI2NzUwfQ.g6eYR2BkhgE_l6rdpiEKIDK8MtFZei-pMIkQa534ioU	2	1	8	2025-07-27 14:32:30.597958+01	2025-07-27 14:33:59.227145+01	2025-07-27 22:32:30.597+01	expired	2025-07-27 14:36:04.74955+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
150	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTUwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxOTU5MSwiZXhwIjoxNzUzNjIzMTkxfQ.ALqzY8g82EUIaReOtLkuNvfvdLFzibFwE4uB88E83vM	2	1	8	2025-07-27 13:33:11.822935+01	2025-07-27 13:36:08.245175+01	2025-07-27 21:33:11.822+01	expired	2025-07-27 13:38:09.579684+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
169	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTY5LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzY0MjY2OSwiZXhwIjoxNzUzNjQ2MjY5fQ.R24dXoyAm-fpzNwYrqS9NkyepvuuIHS-ZLvU5owNRuc	30	2	8	2025-07-27 19:57:49.147306+01	2025-07-27 19:58:46.396126+01	2025-07-28 03:57:49.147+01	active	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
139	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTM5LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMTA3NSwiZXhwIjoxNzUzNjE0Njc1fQ.OIFUEjYor8G4Roiu84iPtY2tXi42WFZoj2so5G5RhoE	2	1	8	2025-07-27 11:11:15.968114+01	2025-07-27 11:19:42.364084+01	2025-07-27 19:11:15.967+01	expired	2025-07-27 11:24:54.501275+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
140	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMTg4OCwiZXhwIjoxNzUzNjE1NDg4fQ.BBwAOk_8G6Mdbb-XXoX8bEeHCvTSBPIHDR9dxWgQSwA	2	1	8	2025-07-27 11:24:48.3574+01	2025-07-27 11:26:50.374369+01	2025-07-27 19:24:48.357+01	terminated	2025-07-27 11:26:51.129786+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
156	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTU2LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMDg4NiwiZXhwIjoxNzUzNjI0NDg2fQ.517NznDaqWkpzdc3Oz_tcFZTLMzwiHM4gIl1O7UJzcU	2	1	8	2025-07-27 13:54:46.07612+01	2025-07-27 14:03:16.312719+01	2025-07-27 21:54:46.075+01	terminated	2025-07-27 14:05:15.999754+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
159	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTU5LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMjQ3OSwiZXhwIjoxNzUzNjI2MDc5fQ.MGhHfEnXEwqpBtQd7Pd42-8Vld-Z4uoYNAbTktsphLY	2	1	8	2025-07-27 14:21:19.321847+01	2025-07-27 14:21:19.321847+01	2025-07-27 22:21:19.321+01	terminated	2025-07-27 14:21:26.8114+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
146	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQ2LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMzY5NiwiZXhwIjoxNzUzNjE3Mjk2fQ.osHw7W05IqoTDAr6CwiHFeaQNUr87-vdeoweGfyvM0c	2	1	8	2025-07-27 11:54:56.054801+01	2025-07-27 12:00:07.921271+01	2025-07-27 19:54:56.054+01	terminated	2025-07-27 12:00:10.468769+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
160	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTYwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMjQ4OSwiZXhwIjoxNzUzNjI2MDg5fQ.SFISAyd2rlKE79uXPwv1w-ICX0RkneNqKnyCHq0XNB0	2	1	8	2025-07-27 14:21:29.884764+01	2025-07-27 14:21:56.007229+01	2025-07-27 22:21:29.884+01	terminated	2025-07-27 14:22:04.001615+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
151	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTUxLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxOTc4NiwiZXhwIjoxNzUzNjIzMzg2fQ.2auIJfuODvzugRR3arcOz2H-xpHzaCrJjPtTsnGOXbs	2	1	8	2025-07-27 13:36:26.303568+01	2025-07-27 13:38:05.900397+01	2025-07-27 21:36:26.303+01	expired	2025-07-27 13:40:06.412514+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
167	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTY3LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMzQ3NiwiZXhwIjoxNzUzNjI3MDc2fQ.ltUh_VbGfi2I06e8H_DNyZH4mMAbTzyFslWPFjixwP4	30	2	8	2025-07-27 14:37:56.256065+01	2025-07-27 14:39:33.431622+01	2025-07-27 22:37:56.255+01	expired	2025-07-27 19:58:15.843983+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
170	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTcwLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzY0Mjc0MCwiZXhwIjoxNzUzNjQ2MzQwfQ.7YsEqGnKHLOMxiNwrELXiFE6ZZTK09dRIIdFU7W2Axw	30	2	8	2025-07-27 19:59:00.526962+01	2025-07-27 20:02:41.593491+01	2025-07-28 03:59:00.526+01	active	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
141	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQxLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMjA1MywiZXhwIjoxNzUzNjE1NjUzfQ.mfZjvvNOpntQmmXGHlGfr7VH23NEDQLk352iG_qxqg0	2	1	8	2025-07-27 11:27:33.996653+01	2025-07-27 11:27:33.996653+01	2025-07-27 19:27:33.996+01	expired	2025-07-27 11:29:38.117458+01	inactivity_timeout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
147	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQ3LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxNDg5MiwiZXhwIjoxNzUzNjE4NDkyfQ.UdUMxNoUpdpUz5Ud7HLv5Mfe2OJHl7DpArFONG3sR5w	2	1	8	2025-07-27 12:14:52.508984+01	2025-07-27 12:15:55.065306+01	2025-07-27 20:14:52.508+01	terminated	2025-07-27 13:27:48.104752+01	password_reset	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
161	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTYxLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMjUyOSwiZXhwIjoxNzUzNjI2MTI5fQ.uxn62AsTOlV0oHK3UOiUOIFJR6CSfaKOtg5K-CALhxU	2	1	8	2025-07-27 14:22:09.094184+01	2025-07-27 14:22:26.944862+01	2025-07-27 22:22:09.094+01	expired	2025-07-27 14:24:44.497367+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
152	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTUyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMDE3MywiZXhwIjoxNzUzNjIzNzczfQ.7euDFFGeyWuibWwhy48THRtBQBd4Dl2LBjL7FLt-5Jg	2	1	8	2025-07-27 13:42:53.865573+01	2025-07-27 13:42:53.865573+01	2025-07-27 21:42:53.865+01	terminated	2025-07-27 13:43:36.157882+01	password_reset	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
168	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTY4LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMzU4MCwiZXhwIjoxNzUzNjI3MTgwfQ.gJoG0cCw9Q5aZZASGDDIAQEzEGX6oo3lidUiynzHCRM	30	2	8	2025-07-27 14:39:40.696981+01	2025-07-27 14:39:40.696981+01	2025-07-27 22:39:40.696+01	expired	2025-07-27 19:58:15.843983+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
171	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTcxLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzY0Mjk2NSwiZXhwIjoxNzUzNjQ2NTY1fQ.nAksfdMZnOomEYCRWMjISCjcPt3u9Ce3y8TrDxp2sN0	30	2	8	2025-07-27 20:02:45.309017+01	2025-07-27 20:02:45.309017+01	2025-07-28 04:02:45.308+01	active	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
142	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxMjMyMiwiZXhwIjoxNzUzNjE1OTIyfQ.0c9_Wg9imtRwwheXzhBq3YdUvEXpUT1n1EnaSaPMx60	2	1	8	2025-07-27 11:32:02.235746+01	2025-07-27 11:39:41.512702+01	2025-07-27 19:32:02.235+01	expired	2025-07-27 11:41:41.652207+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
162	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTYyLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMjU2OCwiZXhwIjoxNzUzNjI2MTY4fQ.yjOpMJqS2o5DNbvNE0i2pQibpEc3MBPPKwYRrLDF4Go	2	1	8	2025-07-27 14:22:48.652791+01	2025-07-27 14:23:07.795625+01	2025-07-27 22:22:48.652+01	terminated	2025-07-27 14:23:07.810316+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
148	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInNlc3Npb25JZCI6MTQ4LCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYxOTI4NiwiZXhwIjoxNzUzNjIyODg2fQ.ToTQ9xspsmdxsY0xbqbqh62vzYH27Mzhvfxwlsl7zbs	2	1	8	2025-07-27 13:28:06.021414+01	2025-07-27 13:29:05.541911+01	2025-07-27 21:28:06.02+01	terminated	2025-07-27 13:29:05.557079+01	logout	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
153	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInNlc3Npb25JZCI6MTUzLCJ0eXBlIjoic2Vzc2lvbiIsImlhdCI6MTc1MzYyMDI2MywiZXhwIjoxNzUzNjIzODYzfQ.a2696eqo2Yps7k-Iv8MSb96mDXFsVqSkTYIFSGqhV8g	2	1	8	2025-07-27 13:44:23.407032+01	2025-07-27 13:44:48.810435+01	2025-07-27 21:44:23.406+01	expired	2025-07-27 13:48:39.339196+01	automatic_expiry	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	\N
\.


--
-- Name: app_configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.app_configuration_id_seq', 125, true);


--
-- Name: billing_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.billing_periods_id_seq', 1, false);


--
-- Name: calendar_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.calendar_events_id_seq', 20, true);


--
-- Name: calendar_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.calendar_webhooks_id_seq', 1, false);


--
-- Name: check_ins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.check_ins_id_seq', 227, true);


--
-- Name: imported_calendar_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.imported_calendar_events_id_seq', 1, false);


--
-- Name: monthly_billing_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.monthly_billing_payments_id_seq', 4, true);


--
-- Name: monthly_billing_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.monthly_billing_periods_id_seq', 58, true);


--
-- Name: patient_billing_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.patient_billing_history_id_seq', 1, false);


--
-- Name: patient_matching_candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.patient_matching_candidates_id_seq', 1, false);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.patients_id_seq', 25, true);


--
-- Name: payment_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.payment_requests_id_seq', 5, true);


--
-- Name: payment_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.payment_status_history_id_seq', 1, false);


--
-- Name: payment_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.payment_transactions_id_seq', 20, true);


--
-- Name: practice_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.practice_invitations_id_seq', 1, false);


--
-- Name: recurring_session_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.recurring_session_templates_id_seq', 1, false);


--
-- Name: session_activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.session_activity_log_id_seq', 307, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.sessions_id_seq', 239, true);


--
-- Name: therapist_billing_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.therapist_billing_history_id_seq', 1, false);


--
-- Name: therapist_onboarding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.therapist_onboarding_id_seq', 6, true);


--
-- Name: therapist_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.therapist_settings_id_seq', 8, true);


--
-- Name: therapists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.therapists_id_seq', 4, true);


--
-- Name: user_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.user_credentials_id_seq', 5, true);


--
-- Name: user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.user_permissions_id_seq', 5, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dankupfer
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 172, true);


--
-- Name: app_configuration app_configuration_key_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.app_configuration
    ADD CONSTRAINT app_configuration_key_key UNIQUE (key);


--
-- Name: app_configuration app_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.app_configuration
    ADD CONSTRAINT app_configuration_pkey PRIMARY KEY (id);


--
-- Name: billing_periods billing_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_pkey PRIMARY KEY (id);


--
-- Name: billing_periods billing_periods_therapist_id_patient_id_period_start_date_p_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_therapist_id_patient_id_period_start_date_p_key UNIQUE (therapist_id, patient_id, period_start_date, period_end_date);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: calendar_webhooks calendar_webhooks_channel_id_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.calendar_webhooks
    ADD CONSTRAINT calendar_webhooks_channel_id_key UNIQUE (channel_id);


--
-- Name: calendar_webhooks calendar_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.calendar_webhooks
    ADD CONSTRAINT calendar_webhooks_pkey PRIMARY KEY (id);


--
-- Name: check_ins check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_pkey PRIMARY KEY (id);


--
-- Name: imported_calendar_events imported_calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.imported_calendar_events
    ADD CONSTRAINT imported_calendar_events_pkey PRIMARY KEY (id);


--
-- Name: monthly_billing_payments monthly_billing_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_pkey PRIMARY KEY (id);


--
-- Name: monthly_billing_periods monthly_billing_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_pkey PRIMARY KEY (id);


--
-- Name: monthly_billing_periods monthly_billing_periods_therapist_id_patient_id_billing_yea_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_therapist_id_patient_id_billing_yea_key UNIQUE (therapist_id, patient_id, billing_year, billing_month);


--
-- Name: patient_billing_history patient_billing_history_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_billing_history
    ADD CONSTRAINT patient_billing_history_pkey PRIMARY KEY (id);


--
-- Name: patient_matching_candidates patient_matching_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_matching_candidates
    ADD CONSTRAINT patient_matching_candidates_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payment_requests payment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_pkey PRIMARY KEY (id);


--
-- Name: payment_status_history payment_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: practice_invitations practice_invitations_invitation_token_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_invitation_token_key UNIQUE (invitation_token);


--
-- Name: practice_invitations practice_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_pkey PRIMARY KEY (id);


--
-- Name: recurring_session_templates recurring_session_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.recurring_session_templates
    ADD CONSTRAINT recurring_session_templates_pkey PRIMARY KEY (id);


--
-- Name: session_activity_log session_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.session_activity_log
    ADD CONSTRAINT session_activity_log_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: therapist_billing_history therapist_billing_history_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_billing_history
    ADD CONSTRAINT therapist_billing_history_pkey PRIMARY KEY (id);


--
-- Name: therapist_onboarding therapist_onboarding_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_onboarding
    ADD CONSTRAINT therapist_onboarding_pkey PRIMARY KEY (id);


--
-- Name: therapist_onboarding therapist_onboarding_therapist_id_step_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_onboarding
    ADD CONSTRAINT therapist_onboarding_therapist_id_step_key UNIQUE (therapist_id, step);


--
-- Name: therapist_settings therapist_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_settings
    ADD CONSTRAINT therapist_settings_pkey PRIMARY KEY (id);


--
-- Name: therapist_settings therapist_settings_therapist_id_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_settings
    ADD CONSTRAINT therapist_settings_therapist_id_setting_key_key UNIQUE (therapist_id, setting_key);


--
-- Name: therapists therapists_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapists
    ADD CONSTRAINT therapists_pkey PRIMARY KEY (id);


--
-- Name: user_credentials user_credentials_email_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_email_key UNIQUE (email);


--
-- Name: user_credentials user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_user_id_therapist_id_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_therapist_id_key UNIQUE (user_id, therapist_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_key UNIQUE (session_token);


--
-- Name: idx_app_configuration_key; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_app_configuration_key ON public.app_configuration USING btree (key);


--
-- Name: idx_billing_periods_patient_dates; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_billing_periods_patient_dates ON public.billing_periods USING btree (patient_id, period_start_date, period_end_date);


--
-- Name: idx_billing_periods_therapist_dates; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_billing_periods_therapist_dates ON public.billing_periods USING btree (therapist_id, period_start_date, period_end_date);


--
-- Name: idx_imported_events_google_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_imported_events_google_id ON public.imported_calendar_events USING btree (google_event_id);


--
-- Name: idx_imported_events_therapist_batch; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_imported_events_therapist_batch ON public.imported_calendar_events USING btree (therapist_id, import_batch_id);


--
-- Name: idx_imported_events_therapy_sessions; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_imported_events_therapy_sessions ON public.imported_calendar_events USING btree (therapist_id, is_therapy_session);


--
-- Name: idx_matching_candidates_name; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_matching_candidates_name ON public.patient_matching_candidates USING btree (extracted_name);


--
-- Name: idx_matching_candidates_therapist_batch; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_matching_candidates_therapist_batch ON public.patient_matching_candidates USING btree (therapist_id, import_batch_id);


--
-- Name: idx_monthly_billing_payments_billing_period; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_monthly_billing_payments_billing_period ON public.monthly_billing_payments USING btree (billing_period_id);


--
-- Name: idx_monthly_billing_payments_payment_date; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_monthly_billing_payments_payment_date ON public.monthly_billing_payments USING btree (payment_date);


--
-- Name: idx_monthly_billing_payments_therapist; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_monthly_billing_payments_therapist ON public.monthly_billing_payments USING btree (therapist_id);


--
-- Name: idx_monthly_billing_periods_month; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_monthly_billing_periods_month ON public.monthly_billing_periods USING btree (billing_year, billing_month);


--
-- Name: idx_monthly_billing_periods_patient; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_monthly_billing_periods_patient ON public.monthly_billing_periods USING btree (patient_id);


--
-- Name: idx_monthly_billing_periods_status; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_monthly_billing_periods_status ON public.monthly_billing_periods USING btree (therapist_id, status);


--
-- Name: idx_monthly_billing_periods_therapist; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_monthly_billing_periods_therapist ON public.monthly_billing_periods USING btree (therapist_id);


--
-- Name: idx_patient_billing_history_dates; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_patient_billing_history_dates ON public.patient_billing_history USING btree (patient_id, effective_from_date, effective_until_date);


--
-- Name: idx_patients_cpf; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE UNIQUE INDEX idx_patients_cpf ON public.patients USING btree (cpf) WHERE (cpf IS NOT NULL);


--
-- Name: idx_patients_email; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_patients_email ON public.patients USING btree (email);


--
-- Name: idx_patients_therapist_billing; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_patients_therapist_billing ON public.patients USING btree (therapist_id, lv_notas_billing_start_date);


--
-- Name: idx_patients_therapist_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_patients_therapist_id ON public.patients USING btree (therapist_id);


--
-- Name: idx_payment_requests_patient_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_requests_patient_id ON public.payment_requests USING btree (patient_id);


--
-- Name: idx_payment_requests_request_date; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_requests_request_date ON public.payment_requests USING btree (request_date);


--
-- Name: idx_payment_requests_therapist_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_requests_therapist_id ON public.payment_requests USING btree (therapist_id);


--
-- Name: idx_payment_status_history_session_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_status_history_session_id ON public.payment_status_history USING btree (session_id);


--
-- Name: idx_payment_transactions_patient_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_transactions_patient_id ON public.payment_transactions USING btree (patient_id);


--
-- Name: idx_payment_transactions_payment_date; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_transactions_payment_date ON public.payment_transactions USING btree (payment_date);


--
-- Name: idx_payment_transactions_session_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_transactions_session_id ON public.payment_transactions USING btree (session_id);


--
-- Name: idx_payment_transactions_therapist_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_payment_transactions_therapist_id ON public.payment_transactions USING btree (therapist_id);


--
-- Name: idx_practice_invitations_email; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_practice_invitations_email ON public.practice_invitations USING btree (invited_email);


--
-- Name: idx_practice_invitations_status; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_practice_invitations_status ON public.practice_invitations USING btree (status, expires_at);


--
-- Name: idx_practice_invitations_therapist; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_practice_invitations_therapist ON public.practice_invitations USING btree (therapist_id);


--
-- Name: idx_practice_invitations_token; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_practice_invitations_token ON public.practice_invitations USING btree (invitation_token);


--
-- Name: idx_recurring_templates_schedule; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_recurring_templates_schedule ON public.recurring_session_templates USING btree (day_of_week, start_time);


--
-- Name: idx_recurring_templates_status; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_recurring_templates_status ON public.recurring_session_templates USING btree (therapist_id, status);


--
-- Name: idx_recurring_templates_therapist_patient; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_recurring_templates_therapist_patient ON public.recurring_session_templates USING btree (therapist_id, patient_id);


--
-- Name: idx_session_activity_log_activity_type; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_session_activity_log_activity_type ON public.session_activity_log USING btree (activity_type);


--
-- Name: idx_session_activity_log_session; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_session_activity_log_session ON public.session_activity_log USING btree (session_id);


--
-- Name: idx_session_activity_log_timestamp; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_session_activity_log_timestamp ON public.session_activity_log USING btree ("timestamp");


--
-- Name: idx_session_activity_log_user; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_session_activity_log_user ON public.session_activity_log USING btree (user_id);


--
-- Name: idx_sessions_billable; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_sessions_billable ON public.sessions USING btree (therapist_id, billable, date);


--
-- Name: idx_sessions_billing_period; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_sessions_billing_period ON public.sessions USING btree (therapist_id, billing_period);


--
-- Name: idx_sessions_billing_period_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_sessions_billing_period_id ON public.sessions USING btree (billing_period_id);


--
-- Name: idx_sessions_patient_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_sessions_patient_id ON public.sessions USING btree (patient_id);


--
-- Name: idx_sessions_payment_requested; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_sessions_payment_requested ON public.sessions USING btree (therapist_id, payment_requested, payment_request_date);


--
-- Name: idx_sessions_payment_status; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_sessions_payment_status ON public.sessions USING btree (therapist_id, payment_status);


--
-- Name: idx_sessions_therapist_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_sessions_therapist_id ON public.sessions USING btree (therapist_id);


--
-- Name: idx_therapist_billing_history_dates; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_therapist_billing_history_dates ON public.therapist_billing_history USING btree (therapist_id, effective_from_date, effective_until_date);


--
-- Name: idx_therapist_settings_therapist_key; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_therapist_settings_therapist_key ON public.therapist_settings USING btree (therapist_id, setting_key);


--
-- Name: idx_therapists_email; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_therapists_email ON public.therapists USING btree (email);


--
-- Name: idx_user_credentials_active; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_credentials_active ON public.user_credentials USING btree (is_active);


--
-- Name: idx_user_credentials_email; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_credentials_email ON public.user_credentials USING btree (email);


--
-- Name: idx_user_credentials_password_reset; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_credentials_password_reset ON public.user_credentials USING btree (password_reset_token);


--
-- Name: idx_user_credentials_verification; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_credentials_verification ON public.user_credentials USING btree (email_verification_token);


--
-- Name: idx_user_permissions_active; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_permissions_active ON public.user_permissions USING btree (user_id, is_active);


--
-- Name: idx_user_permissions_role; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_permissions_role ON public.user_permissions USING btree (therapist_id, role, is_active);


--
-- Name: idx_user_permissions_therapist_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_permissions_therapist_id ON public.user_permissions USING btree (therapist_id);


--
-- Name: idx_user_permissions_user_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_permissions_user_id ON public.user_permissions USING btree (user_id);


--
-- Name: idx_user_sessions_active; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_sessions_active ON public.user_sessions USING btree (user_id, status);


--
-- Name: idx_user_sessions_activity; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_sessions_activity ON public.user_sessions USING btree (last_activity_at);


--
-- Name: idx_user_sessions_expires; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_sessions_expires ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_token; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_sessions_token ON public.user_sessions USING btree (session_token);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: dankupfer
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: monthly_billing_payments trigger_update_billing_status_on_payment_delete; Type: TRIGGER; Schema: public; Owner: dankupfer
--

CREATE TRIGGER trigger_update_billing_status_on_payment_delete AFTER DELETE ON public.monthly_billing_payments FOR EACH ROW EXECUTE FUNCTION public.update_billing_period_status();


--
-- Name: monthly_billing_payments trigger_update_billing_status_on_payment_insert; Type: TRIGGER; Schema: public; Owner: dankupfer
--

CREATE TRIGGER trigger_update_billing_status_on_payment_insert AFTER INSERT ON public.monthly_billing_payments FOR EACH ROW EXECUTE FUNCTION public.update_billing_period_status();


--
-- Name: user_credentials update_user_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: dankupfer
--

CREATE TRIGGER update_user_credentials_updated_at BEFORE UPDATE ON public.user_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: billing_periods billing_periods_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: billing_periods billing_periods_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.billing_periods
    ADD CONSTRAINT billing_periods_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: check_ins check_ins_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: check_ins check_ins_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: imported_calendar_events imported_calendar_events_linked_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.imported_calendar_events
    ADD CONSTRAINT imported_calendar_events_linked_patient_id_fkey FOREIGN KEY (linked_patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: imported_calendar_events imported_calendar_events_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.imported_calendar_events
    ADD CONSTRAINT imported_calendar_events_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_payments monthly_billing_payments_billing_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_billing_period_id_fkey FOREIGN KEY (billing_period_id) REFERENCES public.monthly_billing_periods(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_payments monthly_billing_payments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_payments monthly_billing_payments_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_payments
    ADD CONSTRAINT monthly_billing_payments_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_periods monthly_billing_periods_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: monthly_billing_periods monthly_billing_periods_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.monthly_billing_periods
    ADD CONSTRAINT monthly_billing_periods_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: patient_billing_history patient_billing_history_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_billing_history
    ADD CONSTRAINT patient_billing_history_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: patient_billing_history patient_billing_history_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_billing_history
    ADD CONSTRAINT patient_billing_history_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: patient_matching_candidates patient_matching_candidates_created_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_matching_candidates
    ADD CONSTRAINT patient_matching_candidates_created_patient_id_fkey FOREIGN KEY (created_patient_id) REFERENCES public.patients(id) ON DELETE SET NULL;


--
-- Name: patient_matching_candidates patient_matching_candidates_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patient_matching_candidates
    ADD CONSTRAINT patient_matching_candidates_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: patients patients_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: payment_requests payment_requests_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: payment_requests payment_requests_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: payment_status_history payment_status_history_payment_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_payment_transaction_id_fkey FOREIGN KEY (payment_transaction_id) REFERENCES public.payment_transactions(id) ON DELETE SET NULL;


--
-- Name: payment_status_history payment_status_history_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: practice_invitations practice_invitations_accepted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_accepted_by_fkey FOREIGN KEY (accepted_by) REFERENCES public.user_credentials(id) ON DELETE SET NULL;


--
-- Name: practice_invitations practice_invitations_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- Name: practice_invitations practice_invitations_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.practice_invitations
    ADD CONSTRAINT practice_invitations_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: recurring_session_templates recurring_session_templates_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.recurring_session_templates
    ADD CONSTRAINT recurring_session_templates_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: recurring_session_templates recurring_session_templates_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.recurring_session_templates
    ADD CONSTRAINT recurring_session_templates_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: session_activity_log session_activity_log_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.session_activity_log
    ADD CONSTRAINT session_activity_log_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.user_sessions(id) ON DELETE CASCADE;


--
-- Name: session_activity_log session_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.session_activity_log
    ADD CONSTRAINT session_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: therapist_billing_history therapist_billing_history_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_billing_history
    ADD CONSTRAINT therapist_billing_history_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: therapist_onboarding therapist_onboarding_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_onboarding
    ADD CONSTRAINT therapist_onboarding_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: therapist_settings therapist_settings_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.therapist_settings
    ADD CONSTRAINT therapist_settings_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.user_credentials(id) ON DELETE SET NULL;


--
-- Name: user_permissions user_permissions_therapist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_therapist_id_fkey FOREIGN KEY (therapist_id) REFERENCES public.therapists(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dankupfer
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_credentials(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

